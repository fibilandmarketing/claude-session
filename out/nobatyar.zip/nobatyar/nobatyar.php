<?php
/**
 * Plugin Name: نوبت‌یار — ربات ثبت نوبت NSIA
 * Description: صف متقاضیان، پایش خودکار باز شدن نوبت (زاهدان/مشهد) در ivsf.nsia.gov.af، ثبت خودکار فرم و بایگانی تیکت.
 * Version: 1.3.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Nobatyar
 * Text Domain: nobatyar
 */

defined( 'ABSPATH' ) || exit;

define( 'NBY_VERSION', '1.3.0' );
define( 'NBY_FILE', __FILE__ );
define( 'NBY_DIR', plugin_dir_path( __FILE__ ) );
define( 'NBY_URL', plugin_dir_url( __FILE__ ) );

require_once NBY_DIR . 'includes/class-nby-jalali.php';
require_once NBY_DIR . 'includes/class-nby-settings.php';
require_once NBY_DIR . 'includes/class-nby-fields.php';
require_once NBY_DIR . 'includes/class-nby-storage.php';
require_once NBY_DIR . 'includes/class-nby-db.php';
require_once NBY_DIR . 'includes/class-nby-client.php';
require_once NBY_DIR . 'includes/class-nby-notify.php';
require_once NBY_DIR . 'includes/class-nby-runner.php';
require_once NBY_DIR . 'includes/class-nby-import.php';
require_once NBY_DIR . 'includes/class-nby-activity.php';
require_once NBY_DIR . 'includes/class-nby-auth.php';
require_once NBY_DIR . 'includes/class-nby-api.php';
require_once NBY_DIR . 'includes/class-nby-panel.php';
require_once NBY_DIR . 'includes/class-nby-admin.php';

register_activation_hook( __FILE__, array( 'NBY_DB', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'NBY_Runner', 'deactivate' ) );

add_action( 'plugins_loaded', function () {
	NBY_DB::maybe_upgrade();
	NBY_Runner::init();
	NBY_Auth::init();
	NBY_API::init();
	NBY_Panel::init();
	if ( is_admin() ) {
		NBY_Admin::init();
	}
	if ( defined( 'WP_CLI' ) && WP_CLI ) {
		WP_CLI::add_command( 'nobatyar tick', function () {
			$r = NBY_Runner::tick( 'cli' );
			WP_CLI::log( wp_json_encode( $r, JSON_UNESCAPED_UNICODE ) );
		} );
	}
} );
