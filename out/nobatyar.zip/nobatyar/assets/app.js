/* نوبت‌یار — panel app (front-end /nobatyar and wp-admin embed). No build step. */
( function () {
	'use strict';

	var C = window.NBY_APP;
	var root = document.getElementById( 'nby-root' );
	if ( ! C || ! root ) {
		return;
	}
	var S = { me: C.me, csrf: C.csrf, status: null, poll: null, ticks: [], flash: null, view: '' };
	var CAN = function ( cap ) { return !! ( S.me && S.me.caps && S.me.caps.indexOf( cap ) !== -1 ); };

	/* ================================================================ utils */

	function esc( s ) {
		return String( s === null || s === undefined ? '' : s ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}
	function fa( n ) { return Number( n || 0 ).toLocaleString( 'fa-IR' ); }
	function $( sel, el ) { return ( el || document ).querySelector( sel ); }
	function $$( sel, el ) { return Array.prototype.slice.call( ( el || document ).querySelectorAll( sel ) ); }
	function initial( name ) { name = String( name || '' ).trim(); return name ? name.charAt( 0 ) : '؟'; }

	var I = {
		mark: '<path d="M4 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2a2.2 2.2 0 0 0 0 4.4V16a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-1.6a2.2 2.2 0 0 0 0-4.4z"/><path d="m9.2 12.2 1.9 1.9 3.9-4.2"/>',
		grid: '<rect x="3.5" y="3.5" width="7" height="7" rx="2"/><rect x="13.5" y="3.5" width="7" height="7" rx="2"/><rect x="3.5" y="13.5" width="7" height="7" rx="2"/><rect x="13.5" y="13.5" width="7" height="7" rx="2"/>',
		users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.6 3.3-5.5 6.5-5.5s5.9 1.9 6.5 5.5"/><path d="M15.5 4.8a3.5 3.5 0 0 1 0 6.4M18 14.8c2 .7 3.2 2.4 3.5 5.2"/>',
		userPlus: '<circle cx="10" cy="8" r="3.5"/><path d="M3.5 20c.6-3.6 3.3-5.5 6.5-5.5 1.6 0 3 .4 4.2 1.3"/><path d="M18.5 14v6M15.5 17h6"/>',
		ticket: '<path d="M4 7.5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2a2.5 2.5 0 0 0 0 5v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2a2.5 2.5 0 0 0 0-5z"/><path d="M14.5 6v12" stroke-dasharray="1.5 2.5"/>',
		pulse: '<path d="M3 12h4l2.5-6 4 12 2.5-6H21"/>',
		upload: '<path d="M12 15V4M7.5 8.5 12 4l4.5 4.5"/><path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
		download: '<path d="M12 4v11M7.5 10.5 12 15l4.5-4.5"/><path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
		power: '<path d="M12 3.5v8"/><path d="M6.6 6.6a7.5 7.5 0 1 0 10.8 0"/>',
		play: '<path d="M8 5.5v13l10-6.5z"/>',
		pause: '<path d="M8.5 5.5v13M15.5 5.5v13"/>',
		bolt: '<path d="M13 3 5.5 13.5H12L11 21l7.5-10.5H12z"/>',
		plug: '<path d="M9 3.5v4M15 3.5v4M6.5 7.5h11v3a5.5 5.5 0 0 1-11 0z"/><path d="M12 16v4.5"/>',
		search: '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
		edit: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
		trash: '<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13"/>',
		printer: '<path d="M7 9V3.5h10V9"/><rect x="3.5" y="9" width="17" height="8" rx="2"/><path d="M7 14h10v6.5H7z"/>',
		logout: '<path d="M10 4.5H6a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h4"/><path d="M15 16.5 19.5 12 15 7.5M19.5 12H9"/>',
		check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
		x: '<path d="M6 6l12 12M18 6 6 18"/>',
		alert: '<path d="M12 4 2.8 19.5h18.4z"/><path d="M12 10v4.5M12 17.2v.3"/>',
		info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.8v.2"/>',
		clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
		file: '<path d="M6 3.5h8l4 4V20a.5.5 0 0 1-.5.5h-11A.5.5 0 0 1 6 20z"/><path d="M14 3.5V8h4"/>',
		image: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="m20.5 16-5-5-8.5 8.5"/>',
		undo: '<path d="M15 7.5 19.5 12 15 16.5"/><path d="M19.5 12H9a4.5 4.5 0 0 0 0 9h2"/>',
		plus: '<path d="M12 5v14M5 12h14"/>',
		back: '<path d="M5 12h14M13 6l6 6-6 6"/>',
		eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
		eyeOff: '<path d="M4 4l16 16"/><path d="M10.6 5.6A9.6 9.6 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a17 17 0 0 1-3 3.8M6.6 6.7C4 8.4 2.5 12 2.5 12S6 18.5 12 18.5c1.5 0 2.9-.4 4.1-1"/>',
		refresh: '<path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3"/><path d="M19.5 4.5v4h-4"/>',
		external: '<path d="M14 4.5h5.5V10M19.5 4.5 11 13"/><path d="M18 14v4.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H10"/>',
		flag: '<path d="M5.5 21V4.5M5.5 4.5h11l-2.5 4 2.5 4h-11"/>',
		inbox: '<path d="M3.5 13.5 6 5.5h12l2.5 8V18a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 18z"/><path d="M3.5 13.5H9a3 3 0 0 0 6 0h5.5"/>',
		lock: '<rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/>',
		wifiOff: '<path d="M4 4l16 16"/><path d="M8.5 16.2a5 5 0 0 1 7 0M5.2 12.8a9.6 9.6 0 0 1 4-2.3M14.6 10.5a9.6 9.6 0 0 1 4.2 2.3M2 9.3a14 14 0 0 1 3.6-2.4M11 5.6a14 14 0 0 1 11 3.7"/><path d="M12 19.5v.01"/>',
		calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/><path d="M8 14h.01M12 14h.01M16 14h.01M8 17.2h.01M12 17.2h.01"/>',
		key: '<circle cx="8" cy="15.5" r="4"/><path d="m11 12.5 8.5-8.5M16.5 7l2.5 2.5M14 9.5l2 2"/>',
		idcard: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="9" cy="11" r="2.2"/><path d="M5.8 16c.5-1.6 1.7-2.4 3.2-2.4s2.7.8 3.2 2.4M14.5 10h4M14.5 13.5h3"/>',
		chevR: '<path d="m9 6 6 6-6 6"/>',
		chevL: '<path d="m15 6-6 6 6 6"/>'
	};
	function ic( n, cls ) {
		return '<svg' + ( cls ? ' class="' + cls + '"' : '' ) + ' viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ( I[ n ] || '' ) + '</svg>';
	}

	/* ================================================================ api (multi-transport) */

	// Same-origin transports: /wp-json/ → ?rest_route= → admin-ajax.php. Built from the address
	// the user actually opened, so www / non-www and http / https mismatches can't break requests.
	var TR = { list: [], idx: 0, fails: 0 };
	( function () {
		var list = ( C.transports || [] ).filter( function ( t ) { return C.mode === 'panel' || t.id !== 'ajax'; } );
		TR.list = list.map( function ( t ) { return { id: t.id, base: location.origin + t.base }; } );
		if ( ! TR.list.length ) { TR.list = [ { id: 'rest', base: C.api } ]; }
		try {
			var saved = localStorage.getItem( 'nby_tr' );
			TR.list.forEach( function ( t, i ) { if ( t.id === saved ) { TR.idx = i; } } );
		} catch ( e ) {}
	}() );

	function qstr( query ) {
		if ( ! query ) { return ''; }
		return Object.keys( query ).filter( function ( k ) { return query[ k ] !== '' && query[ k ] !== undefined && query[ k ] !== null; } )
			.map( function ( k ) { return encodeURIComponent( k ) + '=' + encodeURIComponent( query[ k ] ); } ).join( '&' );
	}
	function buildUrl( t, path, query ) {
		var q = qstr( query );
		if ( t.id === 'rest' ) {
			return t.base + path + ( q ? ( t.base.indexOf( '?' ) === -1 ? '?' : '&' ) + q : '' );
		}
		return t.base + encodeURIComponent( path ) + ( q ? '&' + q : '' );
	}

	var LONG = /^(tick|probe|import|citizens\/\d+\/action)$/;

	function attempt( t, path, opts, method ) {
		var headers = { 'Accept': 'application/json' };
		if ( C.mode === 'wp' && C.nonce ) { headers[ 'X-WP-Nonce' ] = C.nonce; }
		if ( S.csrf ) { headers[ 'X-NBY-CSRF' ] = S.csrf; }
		var body = opts.body;
		if ( body && ! ( body instanceof FormData ) ) {
			headers[ 'Content-Type' ] = 'application/json';
			body = JSON.stringify( body );
		}
		var query = Object.assign( {}, opts.query || {} );
		if ( method === 'GET' ) { query._ = Date.now(); } // defeat CDN / proxy caches
		var ctl = window.AbortController ? new AbortController() : null;
		var isTry = opts.body instanceof FormData && opts.body.get && opts.body.get( 'do' ) === 'try';
		var ms = opts.timeout || ( LONG.test( path ) || isTry ? 180000 : 30000 );
		var timer = ctl ? setTimeout( function () { ctl.abort(); }, ms ) : null;
		return fetch( buildUrl( t, path, query ), { method: method, headers: headers, body: body, credentials: 'same-origin', cache: 'no-store', signal: ctl ? ctl.signal : undefined } )
			.then( function ( r ) {
				return r.text().then( function ( txt ) {
					clearTimeout( timer );
					var j = null;
					try { j = txt ? JSON.parse( txt ) : null; } catch ( e ) {}
					var ours = j && ( r.ok || ( j.code && /^(nby_|rest_cookie_invalid_nonce)/.test( j.code ) ) );
					if ( ours ) { return { status: r.status, ok: r.ok, json: j }; }
					var snippet = ( txt || '' ).replace( /<[^>]+>/g, ' ' ).replace( /\s+/g, ' ' ).trim().slice( 0, 90 );
					throw { kind: 'blocked', detail: 'HTTP ' + r.status + ( j && j.code ? ' ' + j.code : ( snippet ? ' — ' + snippet : '' ) ) };
				} );
			}, function ( e ) {
				clearTimeout( timer );
				var to = e && e.name === 'AbortError';
				throw { kind: to ? 'timeout' : 'net', detail: to ? 'no response after ' + Math.round( ms / 1000 ) + 's' : ( ( e && e.message ) || 'network error' ) };
			} );
	}

	function api( path, opts ) {
		opts = opts || {};
		var method = opts.method || ( opts.body ? 'POST' : 'GET' );
		if ( method !== 'GET' && S.csrf ) {
			// also as a parameter: some proxies / VPNs strip custom headers
			if ( opts.body instanceof FormData ) {
				if ( ! opts.body.has( '_nbycsrf' ) ) { opts.body.append( '_nbycsrf', S.csrf ); }
			} else {
				opts.body = Object.assign( { _nbycsrf: S.csrf }, opts.body || {} );
			}
		}
		var order = [ TR.idx ];
		TR.list.forEach( function ( t, i ) { if ( i !== TR.idx ) { order.push( i ); } } );
		var tried = [];
		function next( i ) {
			if ( i >= order.length ) {
				var err = new Error( 'ارتباط با سرور برقرار نشد.' );
				err.net = true;
				err.tried = tried;
				TR.fails++;
				if ( ! opts.quiet || TR.fails >= 2 ) { netDiag( tried ); }
				return Promise.reject( err );
			}
			var t = TR.list[ order[ i ] ];
			return attempt( t, path, opts, method ).then( function ( res ) {
				TR.fails = 0;
				if ( order[ i ] !== TR.idx ) {
					TR.idx = order[ i ];
					try { localStorage.setItem( 'nby_tr', t.id ); } catch ( e ) {}
				}
				closeNetDiag();
				if ( ! res.ok ) {
					var er = new Error( ( res.json && res.json.message ) || ( 'خطای سرور (' + res.status + ')' ) );
					er.status = res.status;
					if ( res.status === 401 && C.mode === 'panel' && path !== 'login' && path !== 'me' ) {
						S.me = null;
						stopPoll();
						renderLogin( 'نشست شما تمام شد؛ دوباره وارد شوید.' );
					}
					throw er;
				}
				return res.json;
			}, function ( fail ) {
				tried.push( { via: t.id, kind: fail.kind, detail: fail.detail } );
				// A timed-out write may still be running on the server: never replay it elsewhere.
				if ( fail.kind === 'timeout' && method !== 'GET' ) {
					var te = new Error( 'سرور در زمان مقرر جواب نداد؛ ممکن است کار انجام شده باشد. صفحه را تازه کنید و نتیجه را بررسی کنید.' );
					te.net = true;
					return Promise.reject( te );
				}
				return next( i + 1 );
			} );
		}
		return next( 0 );
	}

	function rawUrl( kind, id, extra ) {
		var q = {};
		if ( C.mode === 'wp' && C.nonce ) { q._wpnonce = C.nonce; }
		( extra || '' ).split( '&' ).forEach( function ( kv ) { if ( kv ) { var p = kv.split( '=' ); q[ p[ 0 ] ] = p[ 1 ] || ''; } } );
		return buildUrl( TR.list[ TR.idx ], 'raw/' + kind + '/' + ( id || 0 ), q );
	}

	/* ---------- connection diagnostics ---------- */
	var diagEl = null;
	function closeNetDiag() { if ( diagEl ) { diagEl.remove(); diagEl = null; } }
	function netDiag( tried ) {
		if ( diagEl ) { return; }
		var kinds = tried.map( function ( x ) { return x.kind; } );
		var offline = navigator.onLine === false;
		var allNet = kinds.length && kinds.every( function ( k ) { return k === 'net'; } );
		var blocked = kinds.indexOf( 'blocked' ) !== -1;
		var title, text;
		if ( offline ) {
			title = 'اینترنت دستگاه شما قطع است';
			text = 'اتصال اینترنت را بررسی کنید و بعد «تلاش دوباره» را بزنید.';
		} else if ( allNet ) {
			title = 'مرورگر شما به سرور پنل وصل نمی‌شود';
			text = 'این مشکل تقریباً همیشه از VPN / فیلترشکن، پراکسی، یا فایروال و آنتی‌ویروس روی دستگاه یا شبکه شماست. آن را خاموش کنید (یا این سایت را در آن استثنا کنید) و «تلاش دوباره» را بزنید. اگر با اینترنت دیگری (مثلاً اینترنت گوشی) درست شد، مشکل از شبکه فعلی است.';
		} else if ( blocked ) {
			title = 'درخواست‌ها توسط یک فایروال مسدود شد';
			text = 'سرور یا یک فایروال/CDN بین شما و سایت جلوی درخواست را گرفت. اگر VPN یا پراکسی روشن است خاموش کنید. اگر مشکل ماند، «کپی گزارش» را بزنید و برای مدیر سایت بفرستید.';
		} else {
			title = 'سرور در زمان مقرر جواب نداد';
			text = 'سرور شلوغ است یا اتصال شما ضعیف است. چند لحظه بعد دوباره امتحان کنید.';
		}
		var report = 'Nobatyar connection report\n' + new Date().toISOString() + '\n' + location.href.split( '#' )[ 0 ] + '\nonline=' + navigator.onLine + '\n' + navigator.userAgent + '\n' +
			tried.map( function ( x ) { return '- ' + x.via + ': ' + x.kind + ' — ' + x.detail; } ).join( '\n' );
		diagEl = document.createElement( 'div' );
		diagEl.className = 'nby-netdiag';
		diagEl.setAttribute( 'role', 'alertdialog' );
		diagEl.innerHTML = '<div class="nby-netdiag-box"><span class="nby-netdiag-ico">' + ic( offline || allNet ? 'wifiOff' : 'alert' ) + '</span><h3>' + esc( title ) + '</h3><p>' + esc( text ) + '</p>' +
			'<details><summary>جزئیات فنی</summary><pre dir="ltr">' + esc( report ) + '</pre></details>' +
			'<div class="nby-actions"><button class="nby-btn is-primary" data-diag="retry">' + ic( 'refresh' ) + 'تلاش دوباره</button><button class="nby-btn" data-diag="copy">کپی گزارش</button><button class="nby-btn is-quiet" data-diag="close">بستن</button></div></div>';
		( document.querySelector( '.nby-app' ) || document.body ).appendChild( diagEl );
		diagEl.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '[data-diag]' );
			if ( ! b ) { return; }
			var a = b.getAttribute( 'data-diag' );
			if ( a === 'retry' ) { location.reload(); }
			if ( a === 'close' ) { closeNetDiag(); }
			if ( a === 'copy' ) {
				( navigator.clipboard ? navigator.clipboard.writeText( report ) : Promise.reject() ).then( function () { b.textContent = 'کپی شد'; }, function () { b.textContent = 'کپی نشد؛ متن جزئیات را دستی کپی کنید'; } );
			}
		} );
	}

	/* ================================================================ toast & dialog */

	var toastWrap;
	function toast( msg, tone ) {
		if ( ! toastWrap ) {
			toastWrap = document.createElement( 'div' );
			toastWrap.className = 'nby-toasts';
			toastWrap.setAttribute( 'role', 'status' );
			( document.querySelector( '.nby-app' ) || document.body ).appendChild( toastWrap );
		}
		tone = tone || 'ok';
		var icon = { ok: 'check', warn: 'alert', bad: 'alert', info: 'info' }[ tone ] || 'info';
		var t = document.createElement( 'div' );
		t.className = 'nby-toast is-' + tone;
		t.innerHTML = ic( icon ) + '<p>' + esc( msg ) + '</p><button class="nby-btn is-quiet is-icon is-sm" aria-label="بستن">' + ic( 'x' ) + '</button>';
		var kill = function () { t.classList.add( 'is-leaving' ); setTimeout( function () { t.remove(); }, 260 ); };
		t.querySelector( 'button' ).onclick = kill;
		toastWrap.appendChild( t );
		setTimeout( kill, tone === 'ok' ? 4500 : 8000 );
	}

	function ask( title, text, okLabel, danger ) {
		return new Promise( function ( resolve ) {
			var d = document.createElement( 'dialog' );
			d.className = 'nby-dialog';
			d.innerHTML = '<div class="nby-dialog-body"><h3>' + esc( title ) + '</h3><p>' + esc( text ) + '</p></div><div class="nby-dialog-foot"><button class="nby-btn ' + ( danger ? 'is-danger' : 'is-primary' ) + '" data-ok>' + esc( okLabel || 'تأیید' ) + '</button><button class="nby-btn is-quiet" data-no>انصراف</button></div>';
			( document.querySelector( '.nby-app' ) || document.body ).appendChild( d );
			var done = function ( v ) { d.close(); d.remove(); resolve( v ); };
			d.querySelector( '[data-ok]' ).onclick = function () { done( true ); };
			d.querySelector( '[data-no]' ).onclick = function () { done( false ); };
			d.addEventListener( 'cancel', function ( e ) { e.preventDefault(); done( false ); } );
			if ( d.showModal ) { d.showModal(); } else { resolve( window.confirm( title + '\n' + text ) ); d.remove(); }
			d.querySelector( danger ? '[data-no]' : '[data-ok]' ).focus();
		} );
	}

	function busy( btn, on ) {
		if ( ! btn ) { return; }
		btn.classList.toggle( 'is-busy', on );
		btn.disabled = on;
	}

	/* ================================================================ router */

	function route() {
		var h = ( location.hash || '' ).replace( /^#\/?/, '' );
		var parts = h.split( '?' );
		var q = {};
		( parts[ 1 ] || '' ).split( '&' ).forEach( function ( kv ) {
			if ( ! kv ) { return; }
			var p = kv.split( '=' );
			q[ decodeURIComponent( p[ 0 ] ) ] = decodeURIComponent( ( p[ 1 ] || '' ).replace( /\+/g, ' ' ) );
		} );
		var segs = parts[ 0 ].split( '/' ).filter( Boolean );
		return { segs: segs, q: q, path: segs[ 0 ] || 'dashboard' };
	}
	function hashFor( path, q ) {
		var s = Object.keys( q || {} ).filter( function ( k ) { return q[ k ] !== '' && q[ k ] !== undefined && q[ k ] !== null && ! ( k === 'paged' && +q[ k ] === 1 ); } )
			.map( function ( k ) { return encodeURIComponent( k ) + '=' + encodeURIComponent( q[ k ] ); } ).join( '&' );
		return '#/' + path + ( s ? '?' + s : '' );
	}

	var NAV = [
		[ 'dashboard', 'داشبورد', 'grid' ],
		[ 'applicants', 'متقاضیان', 'users' ],
		[ 'applicants/new', 'افزودن متقاضی', 'userPlus' ],
		[ 'tickets', 'نوبت‌ها', 'ticket' ],
		[ 'logs', 'گزارش اجرا', 'pulse' ],
		[ 'import', 'ورود گروهی', 'upload' ],
		[ 'team', 'اپراتورها', 'idcard', 'team' ]
	];
	function navItems() { return NAV.filter( function ( n ) { return ! n[ 3 ] || CAN( n[ 3 ] ); } ); }

	function render() {
		S.ticks.forEach( clearInterval );
		S.ticks = [];
		if ( ! S.me ) {
			renderLogin();
			return;
		}
		if ( ! $( '#nby-main' ) ) {
			renderShell();
		}
		var r = route();
		var key = r.path === 'applicants' && r.segs[ 1 ] === 'new' ? 'applicants/new' : r.path;
		$$( '.nby-nav a' ).forEach( function ( a ) {
			if ( a.getAttribute( 'data-key' ) === key ) { a.setAttribute( 'aria-current', 'page' ); } else { a.removeAttribute( 'aria-current' ); }
		} );
		var main = $( '#nby-main' );
		var views = { dashboard: viewDashboard, applicants: viewApplicants, tickets: viewTickets, logs: viewLogs, import: viewImport, team: viewTeam };
		var fn = views[ r.path ] || viewDashboard;
		if ( r.path === 'applicants' && r.segs[ 1 ] ) {
			fn = viewForm;
		}
		if ( r.path === 'team' ) {
			fn = ! CAN( 'team' ) ? viewDashboard : ( r.segs[ 1 ] ? viewMember : viewTeam );
		}
		closePicker();
		S.view = r.path;
		main.innerHTML = '';
		fn( main, r );
		var title = ( NAV.filter( function ( n ) { return n[ 0 ] === key; } )[ 0 ] || [ 0, 'نوبت‌یار' ] )[ 1 ];
		document.title = title + ' — نوبت‌یار';
		if ( C.mode === 'panel' ) { window.scrollTo( 0, 0 ); }
	}

	/* ================================================================ shell */

	function renderShell() {
		var nav = navItems().map( function ( n ) {
			return '<a href="#/' + n[ 0 ] + '" data-key="' + n[ 0 ] + '">' + ic( n[ 2 ] ) + '<span>' + n[ 1 ] + '</span>' + ( n[ 0 ] === 'applicants' ? '<span class="nby-count" data-count-queued hidden></span>' : '' ) + '</a>';
		} ).join( '' );
		var menu = '<div class="nby-pop" id="nby-pop" role="menu">';
		if ( C.mode === 'panel' ) {
			menu += '<button type="button" data-act="password" role="menuitem">' + ic( 'key' ) + 'تغییر رمز من</button>';
			menu += '<button type="button" data-act="logout" role="menuitem">' + ic( 'logout' ) + 'خروج از پنل</button>';
		} else {
			menu += '<a href="' + esc( C.panelUrl ) + '" target="_blank" rel="noopener" role="menuitem">' + ic( 'external' ) + 'باز کردن پنل در سایت</a>';
		}
		menu += '</div>';
		root.innerHTML =
			'<header class="nby-head"><div class="nby-head-in">' +
			'<a class="nby-brand" href="#/dashboard"><span class="nby-brand-mark">' + ic( 'mark' ) + '</span><span>نوبت‌یار<small>' + esc( C.siteName || 'ثبت نوبت NSIA' ) + '</small></span></a>' +
			'<nav class="nby-nav" aria-label="بخش‌های پنل">' + nav + '</nav>' +
			'<div class="nby-head-side"><span class="nby-botchip" id="nby-botchip"><i></i>…</span>' +
			'<div class="nby-usermenu"><button type="button" aria-haspopup="menu" aria-expanded="false" data-act="menu"><span class="nby-avatar">' + esc( initial( S.me.name ) ) + '</span><span class="nby-who"><b>' + esc( S.me.name ) + '</b><small>' + esc( S.me.role_name ) + '</small></span></button>' + menu + '</div></div>' +
			'</div></header><main class="nby-main" id="nby-main" tabindex="-1"></main>';
		startPoll();
	}

	document.addEventListener( 'click', function ( e ) {
		var t = e.target.closest( '[data-act]' );
		var pop = $( '#nby-pop' );
		if ( pop && ! e.target.closest( '.nby-usermenu' ) ) {
			pop.classList.remove( 'is-open' );
		}
		if ( ! t ) { return; }
		var act = t.getAttribute( 'data-act' );
		if ( act === 'menu' ) {
			pop.classList.toggle( 'is-open' );
			t.setAttribute( 'aria-expanded', pop.classList.contains( 'is-open' ) ? 'true' : 'false' );
		} else if ( act === 'password' ) {
			pop.classList.remove( 'is-open' );
			passwordDialog();
		} else if ( act === 'logout' ) {
			api( 'logout', { method: 'POST', body: {} } ).catch( function () {} ).then( function () {
				S.me = null; S.csrf = ''; stopPoll(); location.hash = '#/'; renderLogin( '', true );
			} );
		}
	} );

	function startPoll() {
		stopPoll();
		refreshStatus();
		S.poll = setInterval( function () { if ( ! document.hidden ) { refreshStatus(); } }, 12000 );
	}
	function stopPoll() { if ( S.poll ) { clearInterval( S.poll ); S.poll = null; } }

	function refreshStatus() {
		return api( 'status', { quiet: true } ).then( function ( st ) {
			S.status = st;
			var chip = $( '#nby-botchip' );
			if ( chip ) {
				chip.className = 'nby-botchip ' + ( st.running ? 'is-on' : 'is-off' );
				chip.innerHTML = '<i></i>' + ( st.running ? ( st.dry_run ? 'روشن · آزمایشی' : 'ربات روشن' ) : 'ربات خاموش' );
			}
			var cnt = $( '[data-count-queued]' );
			if ( cnt ) {
				cnt.hidden = ! st.counts.queued;
				cnt.textContent = fa( st.counts.queued );
			}
			if ( S.view === 'dashboard' && $( '#nby-dash' ) ) {
				paintDashboard( $( '#nby-dash' ), st );
			}
			return st;
		} ).catch( function () {
			// Server busy (e.g. a bot run holding the PHP worker): retry soon instead of leaving a skeleton.
			if ( S.me && S.view === 'dashboard' && ! S.status ) {
				setTimeout( refreshStatus, 3000 );
			}
		} );
	}

	/* ================================================================ login */

	function renderLogin( msg, bye ) {
		root.innerHTML =
			'<div class="nby-login">' +
			'<section class="nby-login-art" aria-hidden="true">' +
			'<span class="nby-brand"><span class="nby-brand-mark">' + ic( 'mark' ) + '</span><span>نوبت‌یار<small>' + esc( C.siteName || '' ) + '</small></span></span>' +
			'<div class="nby-login-quote"><h2>هر دقیقه یک بار، تا نوبت مشهد باز شود.</h2><p>صف متقاضیان، ارسال خودکار فرم سامانه NSIA و بایگانی تیکت‌ها؛ همه در یک پنل.</p></div>' +
			'<div class="nby-login-tickets"><span><b>مشهد</b>پایش دقیقه‌ای</span><span><b>زاهدان</b>ثبت خودکار</span><span><b>PDF</b>تیکت آماده چاپ</span></div>' +
			'</section>' +
			'<section class="nby-login-form"><div class="nby-login-box">' +
			'<h1>ورود به پنل</h1><p>' + ( bye ? 'با موفقیت خارج شدید.' : 'با نام کاربری و رمزی که مدیر برایتان ساخته وارد شوید.' ) + '</p>' +
			'<form novalidate>' +
			( msg ? '<div class="nby-login-err" role="alert">' + esc( msg ) + '</div>' : '<div class="nby-login-err" role="alert" hidden></div>' ) +
			'<label class="nby-field"><span class="nby-label">نام کاربری</span><input class="nby-input" name="username" dir="ltr" autocomplete="username" autocapitalize="none" spellcheck="false" required></label>' +
			'<label class="nby-field"><span class="nby-label">رمز عبور</span><span class="nby-pass"><input class="nby-input" name="password" type="password" dir="ltr" autocomplete="current-password" required><button type="button" class="nby-btn is-quiet is-icon is-sm" data-eye aria-label="نمایش رمز">' + ic( 'eye' ) + '</button></span></label>' +
			'<label class="nby-check"><input type="checkbox" name="remember" value="1"><span>مرا تا ۱۴ روز به خاطر بسپار</span></label>' +
			'<button class="nby-btn is-primary" type="submit">' + ic( 'lock' ) + 'ورود</button>' +
			'</form><p class="nby-login-foot">حساب ندارید؟ از مدیر سایت بخواهید برایتان بسازد.</p></div></section></div>';
		var form = $( '.nby-login form' );
		var err = $( '.nby-login-err' );
		form.username.focus();
		$( '[data-eye]' ).onclick = function () {
			var p = form.password;
			p.type = p.type === 'password' ? 'text' : 'password';
			this.innerHTML = ic( p.type === 'password' ? 'eye' : 'eyeOff' );
		};
		form.onsubmit = function ( e ) {
			e.preventDefault();
			if ( ! form.username.value.trim() || ! form.password.value ) {
				err.hidden = false;
				err.textContent = 'نام کاربری و رمز عبور را وارد کنید.';
				return;
			}
			var b = form.querySelector( '[type=submit]' );
			busy( b, true );
			api( 'login', { body: { username: form.username.value.trim(), password: form.password.value, remember: form.remember.checked } } )
				.then( function ( r ) {
					S.me = r.me; S.csrf = r.csrf;
					if ( ! location.hash || location.hash === '#/' ) { location.hash = '#/dashboard'; }
					root.innerHTML = '';
					render();
				} )
				.catch( function ( x ) {
					err.hidden = false;
					err.textContent = x.message;
					form.password.select();
				} )
				.then( function () { busy( b, false ); } );
		};
	}

	/* ================================================================ dashboard */

	function viewDashboard( main ) {
		main.innerHTML = '<div class="nby-page" id="nby-dash">' + dashSkeleton() + '</div>';
		if ( S.status ) {
			paintDashboard( $( '#nby-dash' ), S.status );
		}
		refreshStatus();
		S.ticks.push( setInterval( tickCountdowns, 1000 ) );
	}

	function dashSkeleton() {
		return '<div class="nby-skel" style="height:44px;width:min(520px,80%);margin-bottom:12px"></div><div class="nby-skel" style="height:18px;width:260px;margin-bottom:26px"></div>' +
			'<div class="nby-stations"><div class="nby-skel" style="height:250px;border-radius:22px"></div><div class="nby-skel" style="height:250px;border-radius:22px"></div></div>';
	}

	function tag( cls, label ) { return label ? '<span class="nby-tag ' + esc( cls ) + '">' + esc( label ) + '</span>' : ''; }

	function heroTitle( st ) {
		if ( ! st.running ) {
			return 'ربات <em class="is-bad">خاموش</em> است';
		}
		var open = st.teams.filter( function ( t ) { return t.state === 'open'; } );
		if ( open.length ) {
			return 'نوبت ' + open.map( function ( t ) { return '<em>' + esc( t.label ) + '</em>'; } ).join( ' و ' ) + ' باز است';
		}
		return 'ربات در حال پایش نوبت‌هاست';
	}

	function paintDashboard( el, st ) {
		var html = '';
		html += '<section class="nby-hero"><div><p class="nby-eyebrow">سلام ' + esc( S.me.name ) + '</p><h1 class="nby-hero-title">' + heroTitle( st ) + '</h1>' +
			'<p class="nby-hero-sub">' + ic( 'clock', '' ).replace( '<svg', '<svg width="16" height="16"' ) + '<span>آخرین اجرا: <b>' + esc( st.tick.ago ) + '</b>' + ( st.tick.source ? ' · ' + esc( st.tick.source ) : '' ) + '</span>' +
			( st.busy ? '<span class="nby-tag is-accent">در حال اجرا…</span>' : '' ) + '</p></div><div class="nby-actions">';
		if ( CAN( 'control' ) ) {
			html += st.running ? '<button class="nby-btn is-dark" data-ctl="stop">' + ic( 'power' ) + 'توقف ربات</button>' : '<button class="nby-btn is-primary is-lg" data-ctl="start">' + ic( 'play' ) + 'روشن کردن ربات</button>';
		}
		if ( CAN( 'try' ) ) {
			html += '<button class="nby-btn" data-run="tick">' + ic( 'bolt' ) + 'اجرای یک دور</button><button class="nby-btn is-quiet" data-run="probe">' + ic( 'plug' ) + 'بررسی اتصال</button>';
		}
		html += '</div></section>';

		if ( st.stop_reason ) {
			html += '<div class="nby-banner is-bad">' + ic( 'alert' ) + '<div><b>ربات خودکار متوقف شد.</b> ' + esc( st.stop_reason ) + '</div></div>';
		}
		if ( st.tick.stale ) {
			html += '<div class="nby-banner is-bad">' + ic( 'clock' ) + '<div><b>ربات بیش از ۳ دقیقه اجرا نشده.</b> کرون سرور کار نمی‌کند؛ به مدیر سایت اطلاع دهید.</div></div>';
		}
		if ( st.dry_run ) {
			html += '<div class="nby-banner is-warn">' + ic( 'info' ) + '<div><b>حالت آزمایشی روشن است.</b> ربات فرم سایت را بررسی می‌کند ولی چیزی ارسال نمی‌کند. خاموش کردن آن از تنظیمات وردپرس انجام می‌شود.</div></div>';
		}

		html += '<section class="nby-stations">';
		st.teams.forEach( function ( t ) {
			var counting = t.next_in !== null && t.next_in !== undefined;
			html += '<article class="nby-station" data-state="' + esc( t.state ) + '">' +
				'<div><div class="nby-station-name"><h3>' + esc( t.label ) + '</h3>' + tag( t.state === 'open' ? 'is-ok' : t.state === 'closed' ? 'is-bad' : t.state === 'paused' ? 'is-warn' : 'is-muted', t.state_label ) + '</div>' +
				'<div class="nby-station-big"><b>' + fa( t.queued ) + '</b><span>نفر در صف</span></div></div>' +
				'<div class="nby-ring" data-ring data-next="' + ( counting ? t.next_in : '' ) + '" data-int="' + t.interval + '">' + ringSvg( counting ? t.next_in : 0, t.interval ) +
				'<div class="nby-ring-label">' + ( counting ? '<b data-ring-n>' + fa( t.next_in ) + '</b><small>ثانیه تا تلاش</small>' : '<b>—</b><small>' + ( t.queued ? 'منتظر' : 'صف خالی' ) + '</small>' ) + '</div></div>' +
				'<dl><div><dt>نوبت امروز</dt><dd class="is-num">' + fa( t.booked_today ) + '</dd></div><div><dt>آخرین تلاش</dt><dd>' + esc( t.last_ago ) + '</dd></div><div><dt>آخرین بار باز بود</dt><dd>' + esc( t.last_open || 'هنوز دیده نشده' ) + '</dd></div></dl>' +
				( t.last_message ? '<p class="nby-station-msg">' + ( t.result_label ? tag( 'r-' + t.last_result, t.result_label ) + ' ' : '' ) + esc( t.last_message ) + '</p>' : '' ) +
				( t.paused_reason ? '<p class="nby-station-msg is-warn">' + esc( t.paused_reason ) + '</p>' : '' ) +
				'<div class="nby-station-foot"><a class="nby-btn is-quiet is-sm" href="' + hashFor( 'applicants', { team: t.key, status: 'queued' } ) + '">مشاهده صف ' + esc( t.label ) + '</a>' +
				( CAN( 'control' ) && t.state !== 'disabled' ? ( t.state === 'paused' ? '<button class="nby-btn is-sm is-primary" data-ctl="resume" data-team="' + esc( t.key ) + '">' + ic( 'play' ) + 'ادامه</button>' : '<button class="nby-btn is-sm" data-ctl="pause" data-team="' + esc( t.key ) + '">' + ic( 'pause' ) + 'توقف ' + esc( t.label ) + '</button>' ) : '' ) +
				'</div></article>';
		} );
		html += '</section>';

		var tiles = [ [ 'queued', 'در صف', 'is-accent' ], [ 'booked', 'نوبت گرفته‌شده', 'is-ok' ], [ 'needs_fix', 'نیاز به اصلاح', 'is-warn' ], [ 'uncertain', 'نامعلوم', 'is-warn' ], [ 'draft', 'پیش‌نویس', '' ], [ 'on_hold', 'متوقف', '' ] ];
		html += '<section class="nby-tiles">' + tiles.map( function ( x ) {
			return '<a class="nby-tile ' + x[ 2 ] + '" href="' + ( x[ 0 ] === 'booked' ? '#/tickets' : hashFor( 'applicants', { status: x[ 0 ] } ) ) + '"><b>' + fa( st.counts[ x[ 0 ] ] ) + '</b><span>' + x[ 1 ] + '</span></a>';
		} ).join( '' ) + '</section>';

		html += '<div class="nby-dash-grid"><section class="nby-card"><div class="nby-page-head" style="margin-bottom:6px"><h2 class="nby-h2" style="margin:0">آخرین فعالیت ربات</h2><a class="nby-btn is-quiet is-sm" href="#/logs">همه گزارش‌ها</a></div>';
		if ( ! st.recent.length ) {
			html += '<div class="nby-empty">' + ic( 'pulse' ) + '<b>هنوز فعالیتی ثبت نشده</b><span>وقتی ربات روشن شود، هر تلاش اینجا نمایش داده می‌شود.</span></div>';
		} else {
			html += '<ul class="nby-feed">' + st.recent.map( function ( a ) {
				return '<li><span class="nby-feed-dot r-' + esc( a.result ) + '"></span><div class="nby-feed-main"><b>' + ( a.citizen_id ? '<a href="#/applicants/' + a.citizen_id + '">' + esc( a.full_name || ( '#' + a.citizen_id ) ) + '</a>' : '—' ) + '</b> · ' + esc( a.team_label ) + ' ' + tag( 'r-' + a.result, a.result_label ) + '<p>' + esc( a.message ) + '</p></div><span class="nby-feed-time">' + esc( a.ago ) + '</span></li>';
			} ).join( '' ) + '</ul>';
		}
		html += '</section><aside class="nby-card"><h2 class="nby-h2">کارهای سریع</h2><div class="nby-quick">' +
			'<a class="nby-btn" href="#/applicants/new">' + ic( 'userPlus' ) + 'افزودن متقاضی جدید</a>' +
			'<a class="nby-btn" href="#/import">' + ic( 'upload' ) + 'ورود گروهی از اکسل</a>' +
			'<a class="nby-btn" href="#/tickets">' + ic( 'printer' ) + 'چاپ نوبت‌های گرفته‌شده</a>' +
			'<a class="nby-btn" href="' + hashFor( 'applicants', { status: 'needs_fix' } ) + '">' + ic( 'edit' ) + 'اصلاح پرونده‌های ناقص</a>' +
			'</div><p class="nby-hint" style="margin-top:14px">' + ( CAN( 'all' ) ? 'کل پرونده‌ها' : 'پرونده‌هایی که شما ثبت کرده‌اید' ) + ': <b class="is-num">' + fa( st.total ) + '</b></p></aside></div>';

		el.innerHTML = html;
	}

	function ringSvg( n, total ) {
		var r = 44, c = 2 * Math.PI * r;
		var frac = total ? Math.max( 0, Math.min( 1, n / total ) ) : 0;
		return '<svg viewBox="0 0 104 104" aria-hidden="true"><circle class="bg" cx="52" cy="52" r="' + r + '"/><circle class="fg" cx="52" cy="52" r="' + r + '" stroke-dasharray="' + c.toFixed( 1 ) + '" stroke-dashoffset="' + ( c * ( 1 - frac ) ).toFixed( 1 ) + '"/></svg>';
	}

	function tickCountdowns() {
		$$( '[data-ring]' ).forEach( function ( el ) {
			var n = el.getAttribute( 'data-next' );
			if ( n === '' ) { return; }
			n = Math.max( 0, +n - 1 );
			el.setAttribute( 'data-next', n );
			var total = +el.getAttribute( 'data-int' ) || 60;
			var fg = el.querySelector( '.fg' );
			var c = 2 * Math.PI * 44;
			if ( fg ) { fg.setAttribute( 'stroke-dashoffset', ( c * ( 1 - Math.min( 1, n / total ) ) ).toFixed( 1 ) ); }
			var lbl = el.querySelector( '[data-ring-n]' );
			if ( lbl ) { lbl.textContent = n > 0 ? fa( n ) : 'الان'; }
		} );
	}

	root.addEventListener( 'click', function ( e ) {
		var ctl = e.target.closest( '[data-ctl]' );
		if ( ctl ) {
			var op = ctl.getAttribute( 'data-ctl' );
			var go = op === 'stop' ? ask( 'توقف ربات', 'ربات تا وقتی دوباره روشنش کنید هیچ فرمی ارسال نمی‌کند.', 'توقف', true ) : Promise.resolve( true );
			go.then( function ( ok ) {
				if ( ! ok ) { return; }
				busy( ctl, true );
				api( 'control', { body: { op: op, team: ctl.getAttribute( 'data-team' ) || '' } } )
					.then( function ( r ) { toast( r.message, 'ok' ); return refreshStatus(); } )
					.catch( function ( x ) { toast( x.message, 'bad' ); busy( ctl, false ); } );
			} );
			return;
		}
		var run = e.target.closest( '[data-run]' );
		if ( run ) {
			busy( run, true );
			toast( run.getAttribute( 'data-run' ) === 'tick' ? 'در حال اجرای یک دور… (تا یک دقیقه)' : 'در حال بررسی اتصال به سایت…', 'info' );
			api( run.getAttribute( 'data-run' ), { method: 'POST', body: {} } )
				.then( function ( r ) { toast( r.message, r.tone || 'ok' ); return refreshStatus(); } )
				.catch( function ( x ) { toast( x.message, 'bad' ); } )
				.then( function () { busy( run, false ); } );
		}
	} );

	/* ================================================================ applicants list */

	var STATUS_ORDER = [ 'queued', 'needs_fix', 'uncertain', 'draft', 'on_hold', 'processing', 'booked' ];

	function viewApplicants( main, r ) {
		var q = { status: r.q.status || '', team: r.q.team || '', s: r.q.s || '', paged: +r.q.paged || 1 };
		var sel = {};
		main.innerHTML = '<div class="nby-page"><header class="nby-page-head"><div><h1 class="nby-h1">متقاضیان</h1><p class="nby-lead" id="nby-lead">در حال بارگذاری…</p></div>' +
			'<a class="nby-btn is-primary" href="#/applicants/new">' + ic( 'plus' ) + 'افزودن متقاضی</a></header>' +
			'<div class="nby-segs" id="nby-segs"></div>' +
			'<div class="nby-toolbar"><label class="nby-search">' + ic( 'search' ) + '<input class="nby-input" type="search" id="nby-s" placeholder="جستجو در نام، تلفن، شماره نوبت و همه فیلدها…" value="' + esc( q.s ) + '" aria-label="جستجو"></label>' +
			'<select class="nby-input" id="nby-team" style="width:auto;min-width:150px" aria-label="محل"><option value="">همه محل‌ها</option>' + Object.keys( C.teams ).map( function ( k ) { return '<option value="' + k + '"' + ( q.team === k ? ' selected' : '' ) + '>' + esc( C.teams[ k ] ) + '</option>'; } ).join( '' ) + '</select></div>' +
			'<section class="nby-card nby-table-card" id="nby-tablecard">' + '<div class="nby-skel nby-skel-row"></div>'.repeat( 6 ) + '</section><div id="nby-pager"></div><div id="nby-bulk"></div></div>';

		var t;
		$( '#nby-s' ).addEventListener( 'input', function () {
			clearTimeout( t );
			var v = this.value;
			t = setTimeout( function () { location.hash = hashFor( 'applicants', { status: q.status, team: q.team, s: v } ); }, 380 );
		} );
		$( '#nby-team' ).onchange = function () { location.hash = hashFor( 'applicants', { status: q.status, team: this.value, s: q.s } ); };

		function load() {
			api( 'citizens', { query: q } ).then( function ( d ) {
				$( '#nby-lead' ).textContent = fa( d.total ) + ' نفر' + ( q.status ? ' با وضعیت «' + C.statuses[ q.status ] + '»' : '' ) + ( q.team ? ' — ' + C.teams[ q.team ] : '' );
				$( '#nby-segs' ).innerHTML = '<button class="nby-seg" data-st=""' + ( ! q.status ? ' aria-pressed="true"' : ' aria-pressed="false"' ) + '>همه <small>' + fa( d.all ) + '</small></button>' +
					STATUS_ORDER.map( function ( k ) {
						if ( ! d.counts[ k ] && q.status !== k ) { return ''; }
						return '<button class="nby-seg" data-st="' + k + '" aria-pressed="' + ( q.status === k ) + '">' + esc( C.statuses[ k ] ) + ' <small>' + fa( d.counts[ k ] ) + '</small></button>';
					} ).join( '' );
				paintTable( d );
				paintPager( $( '#nby-pager' ), d.pages, q.paged, function ( p ) { location.hash = hashFor( 'applicants', { status: q.status, team: q.team, s: q.s, paged: p } ); } );
			} ).catch( function ( x ) {
				$( '#nby-tablecard' ).innerHTML = '<div class="nby-empty">' + ic( 'alert' ) + '<b>بارگذاری ناموفق بود</b><span>' + esc( x.message ) + '</span><button class="nby-btn" data-reload>' + ic( 'refresh' ) + 'تلاش دوباره</button></div>';
				$( '[data-reload]' ).onclick = load;
			} );
		}

		$( '#nby-segs' ).addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '[data-st]' );
			if ( b ) { location.hash = hashFor( 'applicants', { status: b.getAttribute( 'data-st' ), team: q.team, s: q.s } ); }
		} );

		function paintTable( d ) {
			var card = $( '#nby-tablecard' );
			if ( ! d.rows.length ) {
				card.innerHTML = '<div class="nby-empty">' + ic( 'inbox' ) + '<b>' + ( q.s || q.status || q.team ? 'نتیجه‌ای پیدا نشد' : 'هنوز متقاضی‌ای ثبت نشده' ) + '</b><span>' + ( q.s || q.status || q.team ? 'فیلترها را تغییر دهید.' : 'اولین پرونده را اضافه کنید یا از اکسل وارد کنید.' ) + '</span>' +
					( q.s || q.status || q.team ? '<a class="nby-btn" href="#/applicants">پاک کردن فیلترها</a>' : '<a class="nby-btn is-primary" href="#/applicants/new">' + ic( 'plus' ) + 'افزودن متقاضی</a>' ) + '</div>';
				return;
			}
			card.innerHTML = '<div class="nby-table-wrap"><table class="nby-table"><thead><tr><th style="width:40px"><input type="checkbox" class="nby-cbx" data-all aria-label="انتخاب همه"></th><th>متقاضی</th><th>محل</th><th>وضعیت</th><th class="is-hide-sm">تلاش</th><th>آخرین نتیجه</th><th class="is-hide-sm">ثبت‌کننده</th><th class="is-hide-sm">تاریخ ثبت</th><th></th></tr></thead><tbody>' +
				d.rows.map( rowHtml ).join( '' ) + '</tbody></table></div>';
		}

		function rowHtml( c ) {
			var a = '<div class="nby-rowacts">';
			a += '<a class="nby-btn" href="#/applicants/' + c.id + '" title="ویرایش" aria-label="ویرایش">' + ic( 'edit' ) + '</a>';
			if ( CAN( 'try' ) && [ 'queued', 'needs_fix', 'on_hold', 'draft' ].indexOf( c.status ) !== -1 ) {
				a += '<button class="nby-btn is-go" data-row="try" data-id="' + c.id + '" title="تلاش فوری: همین الان ارسال شود" aria-label="تلاش فوری">' + ic( 'bolt' ) + '</button>';
			}
			if ( c.status === 'booked' && c.has_ticket ) {
				a += '<a class="nby-btn is-go" href="' + esc( rawUrl( 'ticket', c.id ) ) + '" target="_blank" rel="noopener" title="مشاهده و چاپ تیکت" aria-label="تیکت">' + ic( 'printer' ) + '</a>';
			}
			if ( c.status === 'uncertain' && CAN( 'try' ) ) {
				a += '<button class="nby-btn" data-row="verify" data-id="' + c.id + '" title="جستجوی نوبت در سایت" aria-label="جستجو در سایت">' + ic( 'search' ) + '</button>';
				a += '<button class="nby-btn" data-row="requeue" data-id="' + c.id + '" title="مطمئنم ثبت نشده — بازگشت به صف" aria-label="بازگشت به صف">' + ic( 'undo' ) + '</button>';
			} else if ( [ 'draft', 'on_hold', 'needs_fix' ].indexOf( c.status ) !== -1 ) {
				a += '<button class="nby-btn" data-row="queue" data-id="' + c.id + '" title="افزودن به صف" aria-label="افزودن به صف">' + ic( 'plus' ) + '</button>';
			} else if ( c.status === 'queued' ) {
				a += '<button class="nby-btn" data-row="hold" data-id="' + c.id + '" title="خارج کردن موقت از صف" aria-label="توقف">' + ic( 'pause' ) + '</button>';
			}
			if ( CAN( 'delete' ) && c.status !== 'processing' ) {
				a += '<button class="nby-btn is-del" data-row="delete" data-id="' + c.id + '" data-name="' + esc( c.full_name ) + '" title="حذف" aria-label="حذف">' + ic( 'trash' ) + '</button>';
			}
			a += '</div>';
			return '<tr class="' + ( c.priority > 0 ? 'is-prio' : '' ) + ( sel[ c.id ] ? ' is-selected' : '' ) + '"><td><input type="checkbox" class="nby-cbx" data-sel="' + c.id + '"' + ( sel[ c.id ] ? ' checked' : '' ) + ' aria-label="انتخاب"></td>' +
				'<td><a class="nby-person" href="#/applicants/' + c.id + '"><span class="nby-avatar">' + esc( initial( c.full_name ) ) + '</span><span><b>' + esc( c.full_name || '(بدون نام)' ) + ( c.priority > 0 ? ' ' + ic( 'flag' ).replace( '<svg', '<svg width="14" height="14" style="color:var(--warn);vertical-align:-2px"' ) : '' ) + '</b><small dir="ltr">' + esc( c.phone ) + ' · #' + c.id + '</small></span></a></td>' +
				'<td>' + esc( c.team_label ) + '</td><td>' + tag( 's-' + c.status, c.status_label ) + ( c.ticket_no ? '<div class="nby-hint">نوبت ' + esc( c.ticket_no ) + '</div>' : '' ) + '</td>' +
				'<td class="is-hide-sm is-num">' + fa( c.attempts ) + '</td>' +
				'<td>' + ( c.result_label ? tag( 'r-' + c.last_result, c.result_label ) : '<span class="nby-hint">—</span>' ) + ( c.last_message ? '<div class="nby-msg" title="' + esc( c.last_message ) + '">' + esc( c.last_message ) + '</div>' : '' ) + '</td>' +
				'<td class="is-hide-sm">' + esc( c.created_by || '—' ) + '</td><td class="is-hide-sm nby-hint">' + esc( c.created_at ) + '</td><td>' + a + '</td></tr>';
		}

		function paintBulk() {
			var ids = Object.keys( sel ).filter( function ( k ) { return sel[ k ]; } );
			var box = $( '#nby-bulk' );
			if ( ! ids.length ) { box.innerHTML = ''; return; }
			box.innerHTML = '<div class="nby-bulkbar"><b>' + fa( ids.length ) + ' مورد انتخاب شده</b><span style="flex:1"></span>' +
				'<button class="nby-btn is-sm" data-bulk="queue">' + ic( 'plus' ) + 'افزودن به صف</button><button class="nby-btn is-sm" data-bulk="hold">' + ic( 'pause' ) + 'توقف</button>' +
				( CAN( 'priority' ) ? '<button class="nby-btn is-sm" data-bulk="prio">' + ic( 'flag' ) + 'فوری</button><button class="nby-btn is-sm" data-bulk="unprio">اولویت عادی</button>' : '' ) +
				( CAN( 'delete' ) ? '<button class="nby-btn is-sm is-del" data-bulk="delete">' + ic( 'trash' ) + 'حذف</button>' : '' ) +
				'<button class="nby-btn is-sm" data-bulk="clear" aria-label="لغو انتخاب">' + ic( 'x' ) + '</button></div>';
		}

		main.addEventListener( 'change', function ( e ) {
			if ( e.target.matches( '[data-sel]' ) ) {
				sel[ e.target.getAttribute( 'data-sel' ) ] = e.target.checked;
				e.target.closest( 'tr' ).classList.toggle( 'is-selected', e.target.checked );
				paintBulk();
			} else if ( e.target.matches( '[data-all]' ) ) {
				$$( '[data-sel]', main ).forEach( function ( cb ) { cb.checked = e.target.checked; sel[ cb.getAttribute( 'data-sel' ) ] = e.target.checked; cb.closest( 'tr' ).classList.toggle( 'is-selected', e.target.checked ); } );
				paintBulk();
			}
		} );

		main.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '[data-row]' );
			if ( b ) {
				rowAction( b.getAttribute( 'data-row' ), b.getAttribute( 'data-id' ), b ).then( function ( changed ) { if ( changed ) { load(); refreshStatus(); } } );
				return;
			}
			var bb = e.target.closest( '[data-bulk]' );
			if ( bb ) {
				var op = bb.getAttribute( 'data-bulk' );
				var ids = Object.keys( sel ).filter( function ( k ) { return sel[ k ]; } );
				if ( op === 'clear' ) { sel = {}; $$( '[data-sel]', main ).forEach( function ( cb ) { cb.checked = false; cb.closest( 'tr' ).classList.remove( 'is-selected' ); } ); paintBulk(); return; }
				( op === 'delete' ? ask( 'حذف ' + fa( ids.length ) + ' پرونده', 'اطلاعات و فایل تذکره این افراد برای همیشه پاک می‌شود.', 'حذف', true ) : Promise.resolve( true ) ).then( function ( ok ) {
					if ( ! ok ) { return; }
					busy( bb, true );
					api( 'citizens/bulk', { body: { op: op, ids: ids } } ).then( function ( r ) { toast( r.message, 'ok' ); sel = {}; paintBulk(); load(); refreshStatus(); } )
						.catch( function ( x ) { toast( x.message, 'bad' ); busy( bb, false ); } );
				} );
			}
		} );

		load();
	}

	function rowAction( op, id, btn ) {
		var confirmFor = {
			delete: [ 'حذف پرونده', 'اطلاعات و فایل تذکره «' + ( btn && btn.getAttribute( 'data-name' ) || '' ) + '» برای همیشه پاک می‌شود.', 'حذف', true ],
			try: [ 'ارسال همین الان', 'فرم این متقاضی همین الان به سامانه NSIA ارسال می‌شود.', 'ارسال', false ],
			requeue: [ 'بازگشت به صف', 'فقط اگر مطمئنید نوبت این نفر در سایت ثبت نشده ادامه دهید؛ وگرنه ممکن است نوبت تکراری ثبت شود.', 'بله، به صف برگردد', true ]
		};
		var c = confirmFor[ op ];
		return ( c ? ask( c[ 0 ], c[ 1 ], c[ 2 ], c[ 3 ] ) : Promise.resolve( true ) ).then( function ( ok ) {
			if ( ! ok ) { return false; }
			busy( btn, true );
			if ( op === 'try' || op === 'verify' ) { toast( op === 'try' ? 'در حال ارسال فرم به سایت…' : 'در حال جستجوی نوبت در سایت…', 'info' ); }
			return api( 'citizens/' + id + '/action', { body: { op: op === 'requeue' ? 'queue' : op } } )
				.then( function ( r ) { toast( r.message, r.tone || 'ok' ); return true; } )
				.catch( function ( x ) { toast( x.message, 'bad' ); busy( btn, false ); return false; } );
		} );
	}

	function paintPager( el, pages, cur, cb ) {
		if ( ! el ) { return; }
		if ( pages <= 1 ) { el.innerHTML = ''; return; }
		var h = '';
		for ( var i = 1; i <= pages; i++ ) {
			if ( pages > 9 && i > 2 && i < pages - 1 && Math.abs( i - cur ) > 1 ) {
				if ( i === 3 || i === pages - 2 ) { h += '<span class="nby-hint" style="align-self:center">…</span>'; }
				continue;
			}
			h += '<button data-p="' + i + '"' + ( i === cur ? ' aria-current="page"' : '' ) + '>' + fa( i ) + '</button>';
		}
		el.className = 'nby-pager';
		el.innerHTML = h;
		el.onclick = function ( e ) { var b = e.target.closest( '[data-p]' ); if ( b ) { cb( +b.getAttribute( 'data-p' ) ); } };
	}

	/* ================================================================ applicant form */

	function viewForm( main, r ) {
		var id = r.segs[ 1 ] === 'new' ? 0 : +r.segs[ 1 ];
		if ( id ) {
			main.innerHTML = '<div class="nby-page"><div class="nby-skel" style="height:40px;width:300px;margin-bottom:20px"></div><div class="nby-skel" style="height:420px;border-radius:22px"></div></div>';
			api( 'citizens/' + id ).then( function ( c ) { paintForm( main, c ); } ).catch( function ( x ) {
				main.innerHTML = '<div class="nby-page"><div class="nby-empty">' + ic( 'alert' ) + '<b>' + esc( x.message ) + '</b><a class="nby-btn" href="#/applicants">بازگشت به لیست</a></div></div>';
			} );
		} else {
			paintForm( main, null );
		}
	}

	var JALALI_FIELDS = { date_of_birth: 1, last_return_date_to_afghanistan: 1 };

	function paintForm( main, c ) {
		var d = c ? c.data : {};
		var errs = {};
		if ( S.flash && S.flash.id === ( c ? c.id : 0 ) ) { errs = S.flash.errors || {}; S.flash = null; }
		var groups = Object.keys( C.groups );
		var h = '<div class="nby-page"><header class="nby-page-head"><div><a class="nby-btn is-quiet is-sm" href="#/applicants">' + ic( 'back' ) + 'بازگشت به لیست</a>' +
			'<h1 class="nby-h1" style="margin-top:8px">' + ( c ? esc( c.full_name || 'متقاضی #' + c.id ) : 'افزودن متقاضی جدید' ) + '</h1>' +
			'<p class="nby-lead">' + ( c ? 'پرونده #' + c.id + ( c.created_by ? ' · ثبت توسط ' + esc( c.created_by ) : '' ) + ' · ' + esc( c.created_at ) : 'همه فیلدهای فرم سامانه NSIA. موارد ستاره‌دار اجباری‌اند؛ تاریخ را شمسی یا میلادی بنویسید.' ) + '</p></div></header>';

		if ( c ) {
			h += '<section class="nby-card" style="margin-bottom:16px"><div class="nby-statusline">' + tag( 's-' + c.status, c.status_label ) +
				'<span class="nby-hint">تلاش‌ها: <b class="is-num">' + fa( c.attempts ) + '</b></span><span class="nby-hint">آخرین تلاش: <b>' + esc( c.last_attempt || '—' ) + '</b></span>' + ( c.result_label ? tag( 'r-' + c.last_result, c.result_label ) : '' ) +
				'<span style="flex:1"></span>' +
				( CAN( 'try' ) && [ 'queued', 'needs_fix', 'on_hold', 'draft' ].indexOf( c.status ) !== -1 ? '<button class="nby-btn is-sm" data-row="try" data-id="' + c.id + '">' + ic( 'bolt' ) + 'تلاش فوری</button>' : '' ) +
				( c.status === 'uncertain' && CAN( 'try' ) ? '<button class="nby-btn is-sm" data-row="verify" data-id="' + c.id + '">' + ic( 'search' ) + 'جستجو در سایت</button><button class="nby-btn is-sm is-quiet" data-row="requeue" data-id="' + c.id + '">' + ic( 'undo' ) + 'بازگشت به صف</button>' : '' ) +
				( c.status === 'queued' ? '<button class="nby-btn is-sm is-quiet" data-row="hold" data-id="' + c.id + '">' + ic( 'pause' ) + 'خارج کردن از صف</button>' : '' ) +
				( CAN( 'delete' ) && c.status !== 'processing' ? '<button class="nby-btn is-sm is-danger-ghost" data-row="delete" data-id="' + c.id + '" data-name="' + esc( c.full_name ) + '">' + ic( 'trash' ) + 'حذف</button>' : '' ) +
				'</div>' + ( c.last_message ? '<p class="nby-station-msg">' + esc( c.last_message ) + '</p>' : '' );
			if ( c.status === 'booked' ) {
				h += '<div class="nby-ticketline">' + ic( 'ticket' ).replace( '<svg', '<svg width="22" height="22"' ) + '<span>شماره نوبت</span><b dir="ltr">' + esc( c.ticket_no ) + '</b><span>· ' + esc( c.ticket_date ) + ' · ' + esc( c.ticket_place ) + '</span><span style="flex:1"></span>' +
					( c.has_ticket ? '<a class="nby-btn is-primary is-sm" target="_blank" rel="noopener" href="' + esc( rawUrl( 'ticket', c.id ) ) + '">' + ic( 'printer' ) + 'مشاهده و چاپ / PDF</a>' : '' ) +
					( c.has_pdf ? '<a class="nby-btn is-sm" href="' + esc( rawUrl( 'pdf', c.id ) ) + '">' + ic( 'download' ) + 'PDF سایت</a>' : '' ) + '</div>';
			}
			if ( c.status === 'processing' ) {
				h += '<div class="nby-banner" style="margin:14px 0 0">' + ic( 'clock' ) + '<div>این پرونده همین الان در حال ارسال است؛ چند ثانیه دیگر صفحه را تازه کنید.</div></div>';
			}
			h += '</section>';
		}

		if ( Object.keys( errs ).length ) {
			h += '<div class="nby-banner is-warn">' + ic( 'alert' ) + '<div><b>این پرونده کامل نیست و به‌صورت پیش‌نویس ماند.</b> ' + fa( Object.keys( errs ).length ) + ' مورد پایین با رنگ قرمز مشخص شده است.</div></div>';
		}

		h += '<div class="nby-formwrap"><nav class="nby-toc" aria-label="بخش‌های فرم">' + groups.map( function ( g ) {
			return '<a href="#" data-goto="g-' + g + '">' + esc( C.groups[ g ] ) + '<span class="nby-prog" data-prog="' + g + '"></span></a>';
		} ).join( '' ) + ( CAN( 'priority' ) ? '<a href="#" data-goto="g-internal">مدیریت داخلی</a>' : '' ) + '</nav>';

		h += '<form id="nby-form" novalidate data-idem="' + Date.now().toString( 36 ) + Math.random().toString( 36 ).slice( 2, 10 ) + '">';
		groups.forEach( function ( g, gi ) {
			h += '<section class="nby-card nby-section" id="g-' + g + '"><div class="nby-section-head"><span>' + fa( gi + 1 ) + '</span><h2>' + esc( C.groups[ g ] ) + '</h2></div><div class="nby-form-grid">';
			C.fields.filter( function ( f ) { return f.group === g; } ).forEach( function ( f ) {
				var val = d[ f.key ] !== undefined ? d[ f.key ] : ( c ? '' : ( f.default || '' ) );
				h += fieldHtml( f, val, errs[ f.key ], c );
			} );
			if ( g === 'place' ) {
				h += fileHtml( c, errs.document_tazkira );
			}
			h += '</div></section>';
		} );
		var prio = c ? c.priority : 0;
		if ( CAN( 'priority' ) ) h += '<section class="nby-card nby-section" id="g-internal"><div class="nby-section-head"><span>' + fa( groups.length + 1 ) + '</span><h2>مدیریت داخلی</h2></div><div class="nby-form-grid">' +
			'<label class="nby-field"><span class="nby-label">اولویت در صف</span><select class="nby-input" name="priority"><option value="0"' + ( prio == 0 ? ' selected' : '' ) + '>عادی</option><option value="5"' + ( prio == 5 ? ' selected' : '' ) + '>فوری</option><option value="9"' + ( prio == 9 ? ' selected' : '' ) + '>خیلی فوری (اول صف)</option></select></label>' +
			'<label class="nby-field is-wide"><span class="nby-label">یادداشت اپراتور</span><textarea class="nby-input" name="notes" rows="2" placeholder="به سایت ارسال نمی‌شود">' + esc( c ? c.notes : '' ) + '</textarea></label></div></section>';

		h += '<div class="nby-savebar">';
		if ( c && c.status === 'processing' ) {
			h += '<span>در حال ارسال؛ ویرایش موقتاً بسته است.</span>';
		} else if ( c && c.status === 'booked' ) {
			h += '<button class="nby-btn is-primary" data-do="keep">' + ic( 'check' ) + 'ذخیره تغییرات</button><span class="nby-savebar-note">نوبت این نفر گرفته شده است.</span>';
		} else if ( c && c.status === 'uncertain' ) {
			h += '<button class="nby-btn is-primary" data-do="keep">' + ic( 'check' ) + 'ذخیره تغییرات</button><span class="nby-savebar-note">تا روشن شدن نتیجه، دوباره ارسال نمی‌شود.</span>';
		} else {
			h += '<button class="nby-btn is-primary" data-do="queue">' + ic( 'check' ) + 'ذخیره و افزودن به صف</button>';
			if ( CAN( 'try' ) ) { h += '<button class="nby-btn" data-do="try">' + ic( 'bolt' ) + 'ذخیره و ارسال همین الان</button>'; }
			h += '<button class="nby-btn" data-do="draft">ذخیره پیش‌نویس</button><span class="nby-savebar-note">فیلدهای ستاره‌دار اجباری‌اند</span>';
		}
		h += '</div></form></div>';

		if ( c && c.history && c.history.length ) {
			h += '<section class="nby-card" style="margin-top:22px"><h2 class="nby-h2">تاریخچه تلاش‌ها</h2>' + attemptsTable( c.history, true ) + '</section>';
		}
		h += '</div>';
		main.innerHTML = h;
		wireForm( main, c );
	}

	function fieldHtml( f, val, err, c ) {
		var n = 'f[' + f.key + ']';
		var w = '<label class="nby-field' + ( err ? ' has-error' : '' ) + ( f.type === 'textarea' ? ' is-wide' : '' ) + '" data-field="' + f.key + '" data-req="' + ( f.req ? 1 : 0 ) + '" data-group="' + f.group + '"><span class="nby-label">' + esc( f.label ) + ( f.req ? '<i>*</i>' : '' ) + '</span>';
		if ( f.type === 'select' ) {
			w += '<select class="nby-input" name="' + n + '"' + ( f.key === 'team' ? ' data-team' : '' ) + '><option value="">— انتخاب کنید —</option>' + Object.keys( f.options ).map( function ( k ) {
				return '<option value="' + esc( k ) + '"' + ( String( val ) === k ? ' selected' : '' ) + '>' + esc( f.options[ k ] ) + '</option>';
			} ).join( '' ) + '</select>';
		} else if ( f.type === 'doctype' ) {
			w += '<select class="nby-input" name="' + n + '" data-doctype><option value="">— انتخاب کنید —</option>';
			Object.keys( C.docTypes ).forEach( function ( team ) {
				Object.keys( C.docTypes[ team ] ).forEach( function ( k ) {
					w += '<option data-team="' + team + '" value="' + esc( k ) + '"' + ( String( val ) === k ? ' selected' : '' ) + '>' + esc( C.docTypes[ team ][ k ] ) + '</option>';
				} );
			} );
			w += '</select>';
		} else if ( f.type === 'textarea' ) {
			w += '<textarea class="nby-input" name="' + n + '" rows="2">' + esc( val ) + '</textarea>';
		} else {
			var type = { tel: 'tel', email: 'email' }[ f.type ] || 'text';
			var ltr = [ 'tel', 'email', 'number', 'date' ].indexOf( f.type ) !== -1 || f.key === 'foreign_document_number' || f.key === 'post_address';
			w += '<input class="nby-input' + ( f.type === 'number' ? ' is-num' : '' ) + '" type="' + type + '" name="' + n + '" value="' + esc( val ) + '"' + ( ltr ? ' dir="ltr"' : '' ) + ( f.type === 'date' ? ' data-date placeholder="۱۳۸۱/۰۵/۲۰"' : '' ) + ( f.type === 'number' ? ' inputmode="numeric"' : '' ) + ( f.type === 'tel' ? ' inputmode="tel" placeholder="09…"' : '' ) + ( f.type === 'date' ? ' autocomplete="off"' : '' ) + '>';
			if ( f.type === 'date' ) {
				w = w.replace( /(<input class="nby-input[^>]*data-date[^>]*>)$/, '<span class="nby-dateinput">$1<button type="button" class="nby-btn is-quiet is-icon is-sm" data-cal aria-label="باز کردن تقویم شمسی" title="تقویم شمسی">' + ic( 'calendar' ) + '</button></span>' );
			}
			if ( f.type === 'date' ) {
				var j = c && c.jalali ? c.jalali[ f.key ] : '';
				w += '<span class="nby-datehint" data-datehint>' + ( val && j ? 'ذخیره‌شده: <b dir="ltr">' + esc( val ) + '</b> (شمسی ' + esc( j ) + ')' : esc( f.help || 'شمسی یا میلادی' ) ) + '</span>';
			}
		}
		if ( err ) {
			w += '<span class="nby-field-err">' + esc( err ) + '</span>';
		}
		return w + '</label>';
	}

	function fileHtml( c, err ) {
		var thumb = ic( 'image' );
		var title = 'فایل تذکره را اینجا رها کنید یا کلیک کنید';
		var sub = 'JPG، PNG، WEBP یا PDF — حداکثر ' + fa( C.maxFileMb ) + ' مگابایت';
		if ( c && c.file ) {
			if ( /^image\//.test( c.file.mime ) ) {
				thumb = '<img src="' + esc( rawUrl( 'file', c.id, 'inline=1' ) ) + '" alt="پیش‌نمایش تذکره">';
			} else {
				thumb = ic( 'file' );
			}
			title = c.file.name;
			sub = 'برای جایگزینی، فایل جدید انتخاب کنید · <a href="' + esc( rawUrl( 'file', c.id ) ) + '">دانلود فایل فعلی</a>';
		}
		return '<div class="nby-field is-wide' + ( err ? ' has-error' : '' ) + '" data-field="document_tazkira" data-req="1" data-group="place" data-hasfile="' + ( c && c.file ? 1 : 0 ) + '"><span class="nby-label">تذکره (فایل)<i>*</i></span>' +
			'<label class="nby-drop" data-drop><input type="file" name="tazkira" accept=".jpg,.jpeg,.png,.webp,.pdf,image/*,application/pdf"><span class="nby-drop-thumb" data-thumb>' + thumb + '</span><span><b data-ftitle>' + esc( title ) + '</b><small data-fsub>' + sub + '</small></span></label>' +
			( err ? '<span class="nby-field-err">' + esc( err ) + '</span>' : '' ) + '</div>';
	}

	function wireForm( main, c ) {
		var form = $( '#nby-form', main );
		if ( ! form ) { return; }

		main.addEventListener( 'click', function ( e ) {
			var g = e.target.closest( '[data-goto]' );
			if ( g ) {
				e.preventDefault();
				var t = document.getElementById( g.getAttribute( 'data-goto' ) );
				if ( t ) { t.scrollIntoView( { behavior: 'smooth', block: 'start' } ); var f = t.querySelector( 'input,select,textarea' ); if ( f ) { setTimeout( function () { f.focus( { preventScroll: true } ); }, 350 ); } }
			}
			var b = e.target.closest( '[data-row]' );
			if ( b ) {
				rowAction( b.getAttribute( 'data-row' ), b.getAttribute( 'data-id' ), b ).then( function ( ok ) {
					if ( ! ok ) { return; }
					refreshStatus();
					if ( b.getAttribute( 'data-row' ) === 'delete' ) { location.hash = '#/applicants'; } else { render(); }
				} );
			}
		} );

		// team → doc types
		var team = $( '[data-team]', form ), doc = $( '[data-doctype]', form );
		function syncDoc() {
			var t = team.value, keep = false, prev = doc.value;
			Array.prototype.forEach.call( doc.options, function ( o ) {
				if ( ! o.value ) { return; }
				var show = ! t || o.getAttribute( 'data-team' ) === t;
				o.hidden = ! show; o.disabled = ! show;
				if ( show && o.selected ) { keep = true; }
			} );
			if ( ! keep && prev ) {
				doc.value = '';
				Array.prototype.forEach.call( doc.options, function ( o ) { if ( ! o.disabled && o.value === prev ) { o.selected = true; } } );
			}
		}
		if ( team && doc ) { team.addEventListener( 'change', syncDoc ); syncDoc(); }

		// jalali hints
		$$( '[data-date]', form ).forEach( function ( inp ) {
			var hint = inp.closest( '.nby-field' ).querySelector( '[data-datehint]' );
			inp.addEventListener( 'click', function () { openPicker( inp ); } );
			inp.parentNode.querySelector( '[data-cal]' ).addEventListener( 'click', function () { openPicker( inp ); } );
			inp.addEventListener( 'input', function () { hint.innerHTML = dateHint( inp.value ); } );
		} );

		// file drop + preview
		var drop = $( '[data-drop]', form );
		var finput = drop.querySelector( 'input' );
		[ 'dragenter', 'dragover' ].forEach( function ( ev ) { drop.addEventListener( ev, function ( e ) { e.preventDefault(); drop.classList.add( 'is-over' ); } ); } );
		[ 'dragleave', 'drop' ].forEach( function ( ev ) { drop.addEventListener( ev, function () { drop.classList.remove( 'is-over' ); } ); } );
		drop.addEventListener( 'drop', function ( e ) {
			e.preventDefault();
			if ( e.dataTransfer.files.length ) { finput.files = e.dataTransfer.files; finput.dispatchEvent( new Event( 'change', { bubbles: true } ) ); }
		} );
		finput.addEventListener( 'change', function () {
			var f = finput.files[ 0 ];
			if ( ! f ) { return; }
			var wrap = finput.closest( '.nby-field' );
			if ( f.size > C.maxFileMb * 1048576 ) {
				toast( 'حجم فایل بیشتر از ' + C.maxFileMb + ' مگابایت است.', 'bad' );
				finput.value = '';
				return;
			}
			wrap.classList.remove( 'has-error' );
			wrap.setAttribute( 'data-hasfile', '1' );
			$( '[data-ftitle]', drop ).textContent = f.name;
			$( '[data-fsub]', drop ).textContent = ( f.size / 1024 ).toFixed( 0 ) + ' کیلوبایت — آماده بارگذاری با ذخیره فرم';
			var th = $( '[data-thumb]', drop );
			if ( /^image\//.test( f.type ) ) {
				th.innerHTML = '<img alt="پیش‌نمایش" src="' + URL.createObjectURL( f ) + '">';
			} else {
				th.innerHTML = ic( 'file' );
			}
			progress();
		} );

		// section progress
		function progress() {
			Object.keys( C.groups ).forEach( function ( g ) {
				var fs = $$( '[data-group="' + g + '"][data-req="1"]', form );
				var done = fs.filter( function ( f ) {
					if ( f.getAttribute( 'data-field' ) === 'document_tazkira' ) { return f.getAttribute( 'data-hasfile' ) === '1'; }
					var i = f.querySelector( 'input,select,textarea' );
					return i && String( i.value ).trim() !== '';
				} ).length;
				var err = $$( '[data-group="' + g + '"].has-error', form ).length;
				var el = $( '[data-prog="' + g + '"]', main );
				if ( el ) {
					el.textContent = fa( done ) + '/' + fa( fs.length );
					el.className = 'nby-prog' + ( err ? ' is-err' : done === fs.length ? ' is-done' : '' );
				}
			} );
		}
		form.addEventListener( 'input', function ( e ) {
			var f = e.target.closest( '.nby-field' );
			if ( f && f.classList.contains( 'has-error' ) && String( e.target.value ).trim() !== '' ) {
				f.classList.remove( 'has-error' );
				var er = f.querySelector( '.nby-field-err' );
				if ( er ) { er.remove(); }
			}
			progress();
		} );
		form.addEventListener( 'change', progress );
		progress();

		// submit
		var lastDo = 'queue';
		$$( '[data-do]', form ).forEach( function ( b ) { b.addEventListener( 'click', function () { lastDo = b.getAttribute( 'data-do' ); } ); } );
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var btn = $( '[data-do="' + lastDo + '"]', form );
			var fd = new FormData( form );
			fd.append( 'do', lastDo );
			if ( ! c ) { fd.append( '_idem', form.getAttribute( 'data-idem' ) || '' ); }
			if ( ! finput.files.length ) { fd.delete( 'tazkira' ); }
			var go = function () {
				$$( '[data-do]', form ).forEach( function ( b ) { b.disabled = true; } );
				busy( btn, true );
				if ( lastDo === 'try' ) { toast( 'در حال ذخیره و ارسال فرم به سایت…', 'info' ); }
				api( c ? 'citizens/' + c.id : 'citizens', { body: fd } ).then( function ( res ) {
					toast( res.message, res.tone || 'ok' );
					S.flash = { id: res.id, errors: res.errors };
					refreshStatus();
					if ( ! c ) {
						location.hash = '#/applicants/' + res.id;
					} else {
						render();
					}
				} ).catch( function ( x ) {
					toast( x.message, 'bad' );
					$$( '[data-do]', form ).forEach( function ( b ) { b.disabled = false; } );
					busy( btn, false );
				} );
			};
			if ( lastDo === 'try' ) {
				ask( 'ذخیره و ارسال همین الان', 'بعد از ذخیره، فرم این متقاضی فوراً به سامانه NSIA ارسال می‌شود.', 'ارسال' ).then( function ( ok ) { if ( ok ) { go(); } } );
			} else {
				go();
			}
		} );
	}

	/* ---------- jalali ---------- */
	function digits( s ) {
		return String( s ).replace( /[۰-۹]/g, function ( d ) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf( d ); } ).replace( /[٠-٩]/g, function ( d ) { return '٠١٢٣٤٥٦٧٨٩'.indexOf( d ); } );
	}
	function dv( a, b ) { return ~~( a / b ); }
	function j2g( jy, jm, jd ) {
		jy += 1595;
		var days = -355668 + ( 365 * jy ) + ( dv( jy, 33 ) * 8 ) + dv( ( jy % 33 ) + 3, 4 ) + jd + ( ( jm < 7 ) ? ( jm - 1 ) * 31 : ( ( jm - 7 ) * 30 ) + 186 );
		var gy = 400 * dv( days, 146097 );
		days %= 146097;
		if ( days > 36524 ) { gy += 100 * dv( --days, 36524 ); days %= 36524; if ( days >= 365 ) { days++; } }
		gy += 4 * dv( days, 1461 );
		days %= 1461;
		if ( days > 365 ) { gy += dv( days - 1, 365 ); days = ( days - 1 ) % 365; }
		var gd = days + 1;
		var ml = [ 0, 31, ( ( gy % 4 === 0 && gy % 100 !== 0 ) || gy % 400 === 0 ) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];
		var gm;
		for ( gm = 0; gm < 13 && gd > ml[ gm ]; gm++ ) { gd -= ml[ gm ]; }
		return [ gy, gm, gd ];
	}
	function pad( n ) { return ( n < 10 ? '0' : '' ) + n; }
	function dateHint( v ) {
		var p = digits( v ).trim().split( /[\/\-.\s]+/ );
		if ( ! v.trim() ) { return 'شمسی یا میلادی، مثل ۱۳۸۱/۰۵/۲۰'; }
		if ( p.length !== 3 ) { return 'به شکل سال/ماه/روز بنویسید'; }
		var y = +p[ 0 ], m = +p[ 1 ], d = +p[ 2 ];
		if ( p[ 2 ].length === 4 ) { y = +p[ 2 ]; d = +p[ 0 ]; }
		if ( ! y || ! m || ! d || m > 12 || d > 31 ) { return '<span style="color:var(--bad)">تاریخ نامعتبر است</span>'; }
		if ( y < 1700 ) {
			var g = j2g( y, m, d );
			return 'شمسی ← میلادی: <b dir="ltr">' + g[ 0 ] + '/' + pad( g[ 1 ] ) + '/' + pad( g[ 2 ] ) + '</b>';
		}
		return 'میلادی: <b dir="ltr">' + y + '/' + pad( m ) + '/' + pad( d ) + '</b>';
	}

	/* ================================================================ jalali date picker */

	var JM = [ 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند' ];
	var JW = [ 'ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج' ];
	function g2j( gy, gm, gd ) {
		var gdm = [ 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 ];
		var gy2 = gm > 2 ? gy + 1 : gy;
		var days = 355666 + ( 365 * gy ) + dv( gy2 + 3, 4 ) - dv( gy2 + 99, 100 ) + dv( gy2 + 399, 400 ) + gd + gdm[ gm - 1 ];
		var jy = -1595 + ( 33 * dv( days, 12053 ) );
		days %= 12053;
		jy += 4 * dv( days, 1461 );
		days %= 1461;
		if ( days > 365 ) { jy += dv( days - 1, 365 ); days = ( days - 1 ) % 365; }
		var jm = days < 186 ? 1 + dv( days, 31 ) : 7 + dv( days - 186, 30 );
		var jd = 1 + ( days < 186 ? days % 31 : ( days - 186 ) % 30 );
		return [ jy, jm, jd ];
	}
	function jLeap( y ) { var g = j2g( y, 12, 30 ), b = g2j( g[ 0 ], g[ 1 ], g[ 2 ] ); return b[ 1 ] === 12 && b[ 2 ] === 30; }
	function jLen( y, m ) { return m <= 6 ? 31 : m <= 11 ? 30 : ( jLeap( y ) ? 30 : 29 ); }
	function jWeekday( y, m, d ) { var g = j2g( y, m, d ); return ( new Date( g[ 0 ], g[ 1 ] - 1, g[ 2 ] ).getDay() + 1 ) % 7; }
	function jToday() { var n = new Date(); return g2j( n.getFullYear(), n.getMonth() + 1, n.getDate() ); }
	function parseToJ( v ) {
		var p = digits( v || '' ).trim().split( /[\/\-.\s]+/ );
		if ( p.length !== 3 ) { return null; }
		var y = +p[ 0 ], m = +p[ 1 ], d = +p[ 2 ];
		if ( p[ 2 ].length === 4 ) { y = +p[ 2 ]; d = +p[ 0 ]; }
		if ( ! y || ! m || ! d || m > 12 || d > 31 ) { return null; }
		return y < 1700 ? [ y, m, d ] : g2j( y, m, d );
	}

	var PK = null;
	function closePicker() { if ( PK ) { PK.el.remove(); document.removeEventListener( 'mousedown', PK.out, true ); window.removeEventListener( 'resize', closePicker ); PK = null; } }
	function openPicker( inp ) {
		if ( PK && PK.inp === inp ) { return; }
		closePicker();
		var today = jToday();
		var cur = parseToJ( inp.value );
		var isBirth = /date_of_birth/.test( inp.name );
		var view = cur ? [ cur[ 0 ], cur[ 1 ] ] : ( isBirth ? [ today[ 0 ] - 30, 1 ] : [ today[ 0 ], today[ 1 ] ] );
		var el = document.createElement( 'div' );
		el.className = 'nby-picker';
		el.setAttribute( 'role', 'dialog' );
		el.setAttribute( 'aria-label', 'انتخاب تاریخ شمسی' );
		( inp.closest( '.nby-app' ) || document.body ).appendChild( el );
		PK = { el: el, inp: inp, out: function ( e ) { if ( ! el.contains( e.target ) && e.target !== inp && ! e.target.closest( '[data-cal]' ) ) { closePicker(); } } };
		document.addEventListener( 'mousedown', PK.out, true );
		window.addEventListener( 'resize', closePicker );

		function place() {
			var r = inp.getBoundingClientRect();
			var w = el.offsetWidth, h = el.offsetHeight;
			var top = r.bottom + 6;
			if ( top + h > window.innerHeight - 8 && r.top - h - 6 > 8 ) { top = r.top - h - 6; }
			el.style.top = Math.max( 8, top ) + 'px';
			el.style.left = Math.min( Math.max( 8, r.right - w ), window.innerWidth - w - 8 ) + 'px';
		}
		function paint() {
			var y = view[ 0 ], m = view[ 1 ];
			var first = jWeekday( y, m, 1 ), len = jLen( y, m );
			var years = '';
			for ( var yy = today[ 0 ] + 1; yy >= 1300; yy-- ) { years += '<option value="' + yy + '"' + ( yy === y ? ' selected' : '' ) + '>' + fa( yy ).replace( /٬/g, '' ) + '</option>'; }
			var h = '<div class="nby-picker-head"><button type="button" class="nby-btn is-quiet is-icon is-sm" data-pk="prev" aria-label="ماه قبل">' + ic( 'chevR' ) + '</button>' +
				'<select class="nby-input" data-pk="m" aria-label="ماه">' + JM.map( function ( n, i ) { return '<option value="' + ( i + 1 ) + '"' + ( i + 1 === m ? ' selected' : '' ) + '>' + n + '</option>'; } ).join( '' ) + '</select>' +
				'<select class="nby-input" data-pk="y" aria-label="سال">' + years + '</select>' +
				'<button type="button" class="nby-btn is-quiet is-icon is-sm" data-pk="next" aria-label="ماه بعد">' + ic( 'chevL' ) + '</button></div>' +
				'<div class="nby-picker-grid">' + JW.map( function ( w ) { return '<span class="nby-picker-wd">' + w + '</span>'; } ).join( '' );
			for ( var i = 0; i < first; i++ ) { h += '<span></span>'; }
			for ( var d = 1; d <= len; d++ ) {
				var sel = cur && cur[ 0 ] === y && cur[ 1 ] === m && cur[ 2 ] === d;
				var tod = today[ 0 ] === y && today[ 1 ] === m && today[ 2 ] === d;
				h += '<button type="button" data-day="' + d + '" class="' + ( sel ? 'is-sel ' : '' ) + ( tod ? 'is-today' : '' ) + '">' + fa( d ) + '</button>';
			}
			h += '</div><div class="nby-picker-foot"><button type="button" class="nby-btn is-quiet is-sm" data-pk="today">امروز</button><span class="nby-hint">' + ( cur ? fa( cur[ 2 ] ) + ' ' + JM[ cur[ 1 ] - 1 ] + ' ' + fa( cur[ 0 ] ).replace( /٬/g, '' ) : 'روز را انتخاب کنید' ) + '</span><button type="button" class="nby-btn is-quiet is-sm" data-pk="close">بستن</button></div>';
			el.innerHTML = h;
			place();
		}
		el.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( 'button' );
			if ( ! b ) { return; }
			var a = b.getAttribute( 'data-pk' );
			if ( b.hasAttribute( 'data-day' ) ) {
				cur = [ view[ 0 ], view[ 1 ], +b.getAttribute( 'data-day' ) ];
				inp.value = cur[ 0 ] + '/' + pad( cur[ 1 ] ) + '/' + pad( cur[ 2 ] );
				inp.dispatchEvent( new Event( 'input', { bubbles: true } ) );
				closePicker();
				inp.focus();
				return;
			}
			if ( a === 'prev' ) { view = view[ 1 ] === 1 ? [ view[ 0 ] - 1, 12 ] : [ view[ 0 ], view[ 1 ] - 1 ]; }
			if ( a === 'next' ) { view = view[ 1 ] === 12 ? [ view[ 0 ] + 1, 1 ] : [ view[ 0 ], view[ 1 ] + 1 ]; }
			if ( a === 'today' ) { view = [ today[ 0 ], today[ 1 ] ]; }
			if ( a === 'close' ) { closePicker(); return; }
			paint();
		} );
		el.addEventListener( 'change', function ( e ) {
			var a = e.target.getAttribute( 'data-pk' );
			if ( a === 'm' ) { view[ 1 ] = +e.target.value; }
			if ( a === 'y' ) { view[ 0 ] = +e.target.value; }
			paint();
		} );
		el.addEventListener( 'keydown', function ( e ) { if ( e.key === 'Escape' ) { closePicker(); inp.focus(); } } );
		paint();
	}
	document.addEventListener( 'scroll', function ( e ) { if ( PK && ! PK.el.contains( e.target ) ) { closePicker(); } }, true );

	/* ================================================================ my password */

	function passwordDialog() {
		var d = document.createElement( 'dialog' );
		d.className = 'nby-dialog';
		d.innerHTML = '<form class="nby-dialog-body nby-form-grid is-one" novalidate><h3>تغییر رمز عبور</h3>' +
			'<label class="nby-field"><span class="nby-label">رمز فعلی</span><input class="nby-input" type="password" name="current" dir="ltr" autocomplete="current-password" required></label>' +
			'<label class="nby-field"><span class="nby-label">رمز جدید (حداقل ' + fa( C.minPass || 8 ) + ' کاراکتر)</span><input class="nby-input" type="password" name="password" dir="ltr" autocomplete="new-password" required></label>' +
			'<label class="nby-field"><span class="nby-label">تکرار رمز جدید</span><input class="nby-input" type="password" name="again" dir="ltr" autocomplete="new-password" required></label>' +
			'<p class="nby-field-err" data-err hidden></p>' +
			'<div class="nby-actions"><button class="nby-btn is-primary" type="submit">' + ic( 'key' ) + 'ذخیره رمز جدید</button><button class="nby-btn is-quiet" type="button" data-no>انصراف</button></div></form>';
		( document.querySelector( '.nby-app' ) || document.body ).appendChild( d );
		var f = d.querySelector( 'form' ), er = d.querySelector( '[data-err]' );
		var done = function () { d.close(); d.remove(); };
		d.querySelector( '[data-no]' ).onclick = done;
		d.addEventListener( 'cancel', function ( e ) { e.preventDefault(); done(); } );
		f.onsubmit = function ( e ) {
			e.preventDefault();
			er.hidden = true;
			if ( f.password.value.length < ( C.minPass || 8 ) ) { er.hidden = false; er.textContent = 'رمز جدید کوتاه است.'; return; }
			if ( f.password.value !== f.again.value ) { er.hidden = false; er.textContent = 'تکرار رمز با رمز جدید یکی نیست.'; return; }
			var b = f.querySelector( '[type=submit]' );
			busy( b, true );
			api( 'me/password', { body: { current: f.current.value, password: f.password.value } } )
				.then( function ( r ) { toast( r.message, 'ok' ); done(); } )
				.catch( function ( x ) { er.hidden = false; er.textContent = x.message; busy( b, false ); } );
		};
		d.showModal();
		f.current.focus();
	}

	/* ================================================================ team (managers) */

	function genPass() {
		var a = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789', s = '';
		var buf = new Uint32Array( 12 );
		( window.crypto || window.msCrypto ).getRandomValues( buf );
		for ( var i = 0; i < 12; i++ ) { s += a[ buf[ i ] % a.length ]; }
		return s.slice( 0, 4 ) + '-' + s.slice( 4, 8 ) + '-' + s.slice( 8 );
	}

	function viewTeam( main ) {
		main.innerHTML = '<div class="nby-page"><header class="nby-page-head"><div><h1 class="nby-h1">اپراتورها</h1><p class="nby-lead">کارکرد امروز هر نفر، ورود و خروج‌ها و ساخت حساب اپراتور جدید.</p></div>' +
			'<button class="nby-btn is-primary" data-new-op>' + ic( 'userPlus' ) + 'اپراتور جدید</button></header>' +
			'<section class="nby-card" id="nby-newop" hidden></section>' +
			'<div class="nby-team-grid" id="nby-team">' + '<div class="nby-skel" style="height:200px;border-radius:18px"></div>'.repeat( 3 ) + '</div></div>';
		function load() {
			api( 'team' ).then( function ( d ) {
				var box = $( '#nby-team', main );
				if ( ! d.users.length ) {
					box.innerHTML = '<div class="nby-card"><div class="nby-empty">' + ic( 'idcard' ) + '<b>هنوز حسابی ساخته نشده</b><span>اولین اپراتور را بسازید.</span></div></div>';
					return;
				}
				box.innerHTML = d.users.map( function ( u ) {
					return '<a class="nby-member' + ( u.active ? '' : ' is-off' ) + '" href="#/team/' + u.id + '">' +
						'<div class="nby-member-top"><span class="nby-avatar is-lg">' + esc( initial( u.display_name ) ) + ( u.online ? '<i class="nby-dot" title="آنلاین"></i>' : '' ) + '</span>' +
						'<span class="nby-member-name"><b>' + esc( u.display_name ) + ( u.self ? ' <small>(شما)</small>' : '' ) + '</b><small dir="ltr">' + esc( u.username ) + '</small></span>' +
						tag( u.role === 'manager' ? 'is-accent' : 'is-muted', u.role_name ) + ( u.active ? '' : tag( 'is-bad', 'غیرفعال' ) ) + '</div>' +
						'<dl class="nby-member-stats"><div><dt>افزودن امروز</dt><dd>' + fa( u.today.added ) + '</dd></div><div><dt>ناقص / مشکل‌دار</dt><dd' + ( u.today.incomplete ? ' class="is-warn"' : '' ) + '>' + fa( u.today.incomplete ) + '</dd></div><div><dt>چاپ نوبت</dt><dd>' + fa( u.today.printed ) + '</dd></div><div><dt>حذف</dt><dd' + ( u.today.deleted ? ' class="is-bad"' : '' ) + '>' + fa( u.today.deleted ) + '</dd></div></dl>' +
						'<p class="nby-hint">' + ( u.online ? '<b style="color:var(--ok)">الان در پنل است</b>' : 'آخرین ورود: ' + esc( u.last_login || 'هرگز' ) ) + '</p></a>';
				} ).join( '' );
			} ).catch( function ( x ) { toast( x.message, 'bad' ); } );
		}
		$( '[data-new-op]', main ).onclick = function () {
			var card = $( '#nby-newop', main );
			card.hidden = false;
			card.innerHTML = '<h2 class="nby-h2">ساخت حساب اپراتور</h2><form class="nby-form-grid" novalidate>' +
				'<label class="nby-field"><span class="nby-label">نام نمایشی<i>*</i></span><input class="nby-input" name="display_name" required placeholder="مثلاً طاها مددی"></label>' +
				'<label class="nby-field"><span class="nby-label">نام کاربری (انگلیسی)<i>*</i></span><input class="nby-input" name="username" dir="ltr" autocomplete="off" required placeholder="taha"></label>' +
				'<label class="nby-field"><span class="nby-label">رمز عبور<i>*</i></span><span class="nby-pass"><input class="nby-input" name="password" dir="ltr" autocomplete="new-password" required><button type="button" class="nby-btn is-quiet is-sm" data-gen style="width:auto;padding:0 8px">ساخت رمز</button></span></label>' +
				'<div class="nby-row-actions"><button class="nby-btn is-primary" type="submit">' + ic( 'check' ) + 'ساخت حساب</button><button class="nby-btn is-quiet" type="button" data-cancel>انصراف</button><span class="nby-field-err" data-err hidden></span></div></form>';
			var f = card.querySelector( 'form' );
			f.display_name.focus();
			card.querySelector( '[data-gen]' ).onclick = function () { f.password.value = genPass(); };
			card.querySelector( '[data-cancel]' ).onclick = function () { card.hidden = true; card.innerHTML = ''; };
			f.onsubmit = function ( e ) {
				e.preventDefault();
				var er = card.querySelector( '[data-err]' ), b = f.querySelector( '[type=submit]' );
				busy( b, true );
				api( 'team', { body: { display_name: f.display_name.value, username: f.username.value.trim(), password: f.password.value } } ).then( function ( r ) {
					toast( r.message + ' نام کاربری: ' + f.username.value.trim() + ' — رمز را به اپراتور بدهید.', 'ok' );
					card.hidden = true; card.innerHTML = '';
					load();
				} ).catch( function ( x ) { er.hidden = false; er.textContent = x.message; busy( b, false ); } );
			};
		};
		load();
	}

	function viewMember( main, r ) {
		var id = +r.segs[ 1 ];
		main.innerHTML = '<div class="nby-page"><div class="nby-skel" style="height:40px;width:280px;margin-bottom:20px"></div><div class="nby-skel" style="height:320px;border-radius:22px"></div></div>';
		api( 'team/' + id ).then( function ( u ) {
			var h = '<div class="nby-page"><header class="nby-page-head"><div><a class="nby-btn is-quiet is-sm" href="#/team">' + ic( 'back' ) + 'همه اپراتورها</a>' +
				'<h1 class="nby-h1" style="margin-top:8px">' + esc( u.display_name ) + ' ' + tag( u.role === 'manager' ? 'is-accent' : 'is-muted', u.role_name ) + ( u.online ? ' ' + tag( 'is-ok', 'آنلاین' ) : '' ) + ( u.active ? '' : ' ' + tag( 'is-bad', 'غیرفعال' ) ) + '</h1>' +
				'<p class="nby-lead" dir="auto">' + esc( u.username ) + ' · آخرین ورود: ' + esc( u.last_login || 'هرگز' ) + '</p></div></header>';
			h += '<section class="nby-tiles"><div class="nby-tile is-accent"><b>' + fa( u.today.added ) + '</b><span>متقاضی جدید امروز</span></div><div class="nby-tile is-warn"><b>' + fa( u.today.incomplete ) + '</b><span>ناقص یا مشکل‌دار</span></div>' +
				'<div class="nby-tile"><b>' + fa( u.today.updated ) + '</b><span>ویرایش</span></div><div class="nby-tile is-ok"><b>' + fa( u.today.printed ) + '</b><span>چاپ نوبت</span></div><div class="nby-tile"><b>' + fa( u.today.deleted ) + '</b><span>حذف</span></div></section>';
			h += '<div class="nby-split"><div>';
			h += '<section class="nby-card"><h2 class="nby-h2">ورود و خروج‌ها</h2>' + ( u.sessions.length ? '<div class="nby-table-wrap"><table class="nby-table"><thead><tr><th>ورود</th><th>خروج</th><th>مدت</th><th class="is-hide-sm">نحوه پایان</th><th class="is-hide-sm">IP</th></tr></thead><tbody>' +
				u.sessions.map( function ( s ) { return '<tr><td class="nby-hint">' + esc( s.start ) + '</td><td>' + ( s.open ? tag( 'is-ok', 'هنوز در پنل' ) : '<span class="nby-hint">' + esc( s.end ) + '</span>' ) + '</td><td>' + esc( s.duration ) + '</td><td class="is-hide-sm">' + esc( s.reason ) + '</td><td class="is-hide-sm" dir="ltr">' + esc( s.ip ) + '</td></tr>'; } ).join( '' ) +
				'</tbody></table></div>' : '<div class="nby-empty"><b>هنوز واردی نداشته</b></div>' ) + '</section>';
			h += '<section class="nby-card"><h2 class="nby-h2">آخرین کارها</h2>' + ( u.activity.length ? '<ul class="nby-feed">' + u.activity.map( function ( a ) {
				var link = a.id && [ 'create', 'update', 'try', 'queue', 'hold', 'print', 'verify' ].indexOf( a.action ) !== -1 ? '<a href="#/applicants/' + a.id + '">' + esc( a.object ) + '</a>' : esc( a.object );
				return '<li><span class="nby-feed-dot' + ( a.action === 'delete' ? ' r-closed' : a.action === 'create' ? ' r-success' : '' ) + '"></span><div class="nby-feed-main"><b>' + esc( a.label ) + '</b>' + ( a.object ? ' · ' + link : '' ) + ( a.note ? '<p>' + esc( a.note ) + '</p>' : '' ) + '</div><span class="nby-feed-time">' + esc( a.time ) + '</span></li>';
			} ).join( '' ) + '</ul>' : '<div class="nby-empty"><b>کاری ثبت نشده</b></div>' ) + '</section></div><aside>';
			h += '<section class="nby-card"><h2 class="nby-h2">وضعیت پرونده‌های امروز</h2>' + ( u.by_status.length ? '<ul class="nby-kv">' + u.by_status.map( function ( b ) { return '<li>' + tag( 's-' + b.status, b.label ) + '<b>' + fa( b.n ) + '</b></li>'; } ).join( '' ) + '</ul>' : '<p class="nby-hint">امروز پرونده‌ای ثبت نکرده.</p>' ) +
				( u.printed.length ? '<h3 class="nby-h3">نوبت‌های چاپ‌شده</h3><p class="nby-hint">' + u.printed.map( esc ).join( '، ' ) + '</p>' : '' ) + '</section>';
			if ( u.editable ) {
				h += '<section class="nby-card"><h2 class="nby-h2">ویرایش حساب</h2><form class="nby-form-grid is-one" id="nby-opform" novalidate>' +
					'<label class="nby-field"><span class="nby-label">نام نمایشی</span><input class="nby-input" name="display_name" value="' + esc( u.display_name ) + '"></label>' +
					'<label class="nby-field"><span class="nby-label">رمز جدید (خالی = بدون تغییر)</span><span class="nby-pass"><input class="nby-input" name="password" dir="ltr" autocomplete="new-password"><button type="button" class="nby-btn is-quiet is-sm" data-gen style="width:auto;padding:0 8px">ساخت رمز</button></span></label>' +
					'<label class="nby-switch"><input type="checkbox" name="active"' + ( u.active ? ' checked' : '' ) + '><span class="nby-switch-ui"></span><span class="nby-switch-text"><b>حساب فعال است</b><small>با غیرفعال کردن، اپراتور فوراً از پنل خارج می‌شود.</small></span></label>' +
					'<p class="nby-field-err" data-err hidden></p><button class="nby-btn is-primary" type="submit">' + ic( 'check' ) + 'ذخیره</button></form></section>';
			} else {
				h += '<section class="nby-card"><p class="nby-hint">' + ( u.role === 'manager' ? 'حساب مدیران فقط از پیشخوان وردپرس (کاربران پنل) قابل تغییر است. رمز خودتان را از منوی بالا ← «تغییر رمز من» عوض کنید.' : '' ) + '</p></section>';
			}
			h += '</aside></div></div>';
			main.innerHTML = h;
			var f = $( '#nby-opform', main );
			if ( f ) {
				f.querySelector( '[data-gen]' ).onclick = function () { f.password.value = genPass(); };
				f.onsubmit = function ( e ) {
					e.preventDefault();
					var b = f.querySelector( '[type=submit]' ), er = f.querySelector( '[data-err]' );
					busy( b, true );
					api( 'team/' + id, { body: { display_name: f.display_name.value, password: f.password.value, active: f.active.checked } } )
						.then( function ( res ) { toast( res.message, 'ok' ); render(); } )
						.catch( function ( x ) { er.hidden = false; er.textContent = x.message; busy( b, false ); } );
				};
			}
		} ).catch( function ( x ) {
			main.innerHTML = '<div class="nby-page"><div class="nby-empty">' + ic( 'alert' ) + '<b>' + esc( x.message ) + '</b><a class="nby-btn" href="#/team">بازگشت</a></div></div>';
		} );
	}

	/* ================================================================ tickets */

	function viewTickets( main, r ) {
		var q = { status: 'booked', orderby: 'booked', s: r.q.s || '', team: r.q.team || '', paged: +r.q.paged || 1, per_page: 24 };
		main.innerHTML = '<div class="nby-page"><header class="nby-page-head"><div><h1 class="nby-h1">نوبت‌های گرفته‌شده</h1><p class="nby-lead" id="nby-lead">در حال بارگذاری…</p></div></header>' +
			'<div class="nby-toolbar"><label class="nby-search">' + ic( 'search' ) + '<input class="nby-input" type="search" id="nby-s" placeholder="جستجو در نام، تلفن یا شماره نوبت…" value="' + esc( q.s ) + '" aria-label="جستجو"></label>' +
			'<select class="nby-input" id="nby-team" style="width:auto;min-width:150px" aria-label="محل"><option value="">همه محل‌ها</option>' + Object.keys( C.teams ).map( function ( k ) { return '<option value="' + k + '"' + ( q.team === k ? ' selected' : '' ) + '>' + esc( C.teams[ k ] ) + '</option>'; } ).join( '' ) + '</select></div>' +
			'<div class="nby-stubs" id="nby-stubs">' + '<div class="nby-skel" style="height:190px;border-radius:16px"></div>'.repeat( 3 ) + '</div><div id="nby-pager"></div></div>';
		var t;
		$( '#nby-s' ).addEventListener( 'input', function () { clearTimeout( t ); var v = this.value; t = setTimeout( function () { location.hash = hashFor( 'tickets', { s: v, team: q.team } ); }, 380 ); } );
		$( '#nby-team' ).onchange = function () { location.hash = hashFor( 'tickets', { s: q.s, team: this.value } ); };
		api( 'citizens', { query: q } ).then( function ( d ) {
			$( '#nby-lead' ).textContent = fa( d.total ) + ' نوبت ثبت‌شده — برای PDF، تیکت را باز کنید و «چاپ / ذخیره PDF» را بزنید.';
			var box = $( '#nby-stubs' );
			if ( ! d.rows.length ) {
				box.outerHTML = '<div class="nby-card"><div class="nby-empty">' + ic( 'ticket' ) + '<b>' + ( q.s || q.team ? 'نوبتی با این جستجو پیدا نشد' : 'هنوز نوبتی گرفته نشده' ) + '</b><span>وقتی ربات برای کسی نوبت بگیرد، تیکتش اینجا آماده چاپ است.</span></div></div>';
				return;
			}
			box.innerHTML = d.rows.map( function ( c ) {
				return '<article class="nby-stub"><div class="nby-stub-top"><p class="nby-eyebrow"><span>' + esc( c.team_label ) + ( c.ticket_place && c.ticket_place !== c.team_label ? ' · ' + esc( c.ticket_place ) : '' ) + '</span><span>' + esc( c.booked_at ) + '</span></p>' +
					'<p class="nby-stub-no">' + esc( c.ticket_no || '—' ) + '</p><p class="nby-stub-date">' + esc( c.ticket_date || 'تاریخ نوبت خوانده نشد؛ تیکت را ببینید' ) + '</p></div>' +
					'<div class="nby-stub-bot"><a class="nby-person" href="#/applicants/' + c.id + '"><span class="nby-avatar">' + esc( initial( c.full_name ) ) + '</span><span><b>' + esc( c.full_name ) + '</b><small dir="ltr">' + esc( c.phone ) + '</small></span></a><span class="nby-actions">' +
					( c.has_ticket ? '<a class="nby-btn is-primary is-sm" target="_blank" rel="noopener" href="' + esc( rawUrl( 'ticket', c.id ) ) + '">' + ic( 'printer' ) + 'چاپ</a>' : '' ) +
					( c.has_pdf ? '<a class="nby-btn is-sm is-icon" href="' + esc( rawUrl( 'pdf', c.id ) ) + '" aria-label="دانلود PDF سایت" title="PDF سایت">' + ic( 'download' ) + '</a>' : '' ) + '</span></div></article>';
			} ).join( '' );
			paintPager( $( '#nby-pager' ), d.pages, q.paged, function ( p ) { location.hash = hashFor( 'tickets', { s: q.s, team: q.team, paged: p } ); } );
		} ).catch( function ( x ) { toast( x.message, 'bad' ); } );
	}

	/* ================================================================ logs */

	function attemptsTable( rows, compact ) {
		return '<div class="nby-table-wrap"><table class="nby-table"><thead><tr><th>زمان</th>' + ( compact ? '' : '<th>متقاضی</th><th>محل</th>' ) + '<th>نوع</th><th>نتیجه</th><th>پیام</th><th class="is-hide-sm">کد</th><th class="is-hide-sm">مدت</th><th></th></tr></thead><tbody>' +
			rows.map( function ( a ) {
				return '<tr><td class="nby-hint" style="white-space:nowrap">' + esc( a.time ) + '</td>' +
					( compact ? '' : '<td>' + ( a.citizen_id ? '<a href="#/applicants/' + a.citizen_id + '">' + esc( a.full_name || '#' + a.citizen_id ) + '</a>' : '—' ) + '</td><td>' + esc( a.team_label ) + '</td>' ) +
					'<td>' + esc( a.kind_label ) + '</td><td>' + tag( 'r-' + a.result, a.result_label ) + '</td><td><div class="nby-msg" title="' + esc( a.message ) + '">' + esc( a.message ) + '</div></td>' +
					'<td class="is-hide-sm is-num">' + ( a.http_code || '—' ) + '</td><td class="is-hide-sm is-num">' + fa( a.seconds ) + ' ث</td>' +
					'<td>' + ( a.has_response ? '<a class="nby-btn is-quiet is-sm" target="_blank" rel="noopener" href="' + esc( rawUrl( 'response', a.id ) ) + '">' + ic( 'eye' ) + 'پاسخ سایت</a>' : '' ) + '</td></tr>';
			} ).join( '' ) + '</tbody></table></div>';
	}

	function viewLogs( main, r ) {
		var q = { result: r.q.result || '', team: r.q.team || '', paged: +r.q.paged || 1 };
		main.innerHTML = '<div class="nby-page"><header class="nby-page-head"><div><h1 class="nby-h1">گزارش اجرا</h1><p class="nby-lead" id="nby-lead">هر تلاش ربات و پاسخ سامانه NSIA.</p></div><button class="nby-btn is-quiet" data-reload>' + ic( 'refresh' ) + 'تازه‌سازی</button></header>' +
			'<div class="nby-toolbar"><select class="nby-input" id="nby-res" style="width:auto;min-width:170px" aria-label="نتیجه"><option value="">همه نتیجه‌ها</option>' + Object.keys( C.results ).map( function ( k ) { return '<option value="' + k + '"' + ( q.result === k ? ' selected' : '' ) + '>' + esc( C.results[ k ] ) + '</option>'; } ).join( '' ) + '</select>' +
			'<select class="nby-input" id="nby-team" style="width:auto;min-width:150px" aria-label="محل"><option value="">همه محل‌ها</option>' + Object.keys( C.teams ).map( function ( k ) { return '<option value="' + k + '"' + ( q.team === k ? ' selected' : '' ) + '>' + esc( C.teams[ k ] ) + '</option>'; } ).join( '' ) + '</select></div>' +
			'<section class="nby-card nby-table-card" id="nby-tablecard">' + '<div class="nby-skel nby-skel-row"></div>'.repeat( 6 ) + '</section><div id="nby-pager"></div></div>';
		$( '#nby-res' ).onchange = function () { location.hash = hashFor( 'logs', { result: this.value, team: q.team } ); };
		$( '#nby-team' ).onchange = function () { location.hash = hashFor( 'logs', { result: q.result, team: this.value } ); };
		function load() {
			api( 'attempts', { query: q } ).then( function ( d ) {
				$( '#nby-lead' ).textContent = fa( d.total ) + ' رکورد · پاسخ کامل سایت برای نتیجه‌های مهم ذخیره می‌شود.';
				$( '#nby-tablecard' ).innerHTML = d.rows.length ? attemptsTable( d.rows, false ) : '<div class="nby-empty">' + ic( 'pulse' ) + '<b>رکوردی پیدا نشد</b></div>';
				paintPager( $( '#nby-pager' ), d.pages, q.paged, function ( p ) { location.hash = hashFor( 'logs', { result: q.result, team: q.team, paged: p } ); } );
			} ).catch( function ( x ) { toast( x.message, 'bad' ); } );
		}
		$( '[data-reload]', main ).onclick = load;
		load();
	}

	/* ================================================================ import */

	function viewImport( main ) {
		main.innerHTML = '<div class="nby-page"><header class="nby-page-head"><div><h1 class="nby-h1">ورود گروهی متقاضیان</h1><p class="nby-lead">ده‌ها پرونده را یک‌جا از فایل اکسل (CSV) و یک ZIP از اسکن تذکره‌ها وارد کنید.</p></div></header>' +
			'<div class="nby-split"><section class="nby-card"><h2 class="nby-h2">بارگذاری فایل‌ها</h2><form id="nby-imp" class="nby-form-grid is-one" novalidate>' +
			'<div class="nby-field"><span class="nby-label">فایل CSV<i>*</i></span><label class="nby-drop" data-drop><input type="file" name="csv" accept=".csv,.txt,text/csv"><span class="nby-drop-thumb">' + ic( 'file' ) + '</span><span><b data-ftitle>فایل CSV را اینجا رها کنید</b><small data-fsub>اکسل ← Save As ← CSV UTF-8</small></span></label></div>' +
			'<div class="nby-field"><span class="nby-label">ZIP اسکن تذکره‌ها</span><label class="nby-drop" data-drop><input type="file" name="zip" accept=".zip,application/zip"><span class="nby-drop-thumb">' + ic( 'image' ) + '</span><span><b data-ftitle>فایل ZIP را اینجا رها کنید</b><small data-fsub>اختیاری؛ نام هر فایل در ستون «' + esc( C.fileCol ) + '» آمده باشد</small></span></label></div>' +
			'<div><button class="nby-btn is-primary is-lg" type="submit">' + ic( 'upload' ) + 'شروع ورود</button></div></form><div id="nby-imp-out"></div></section>' +
			'<aside class="nby-card"><h2 class="nby-h2">راهنما</h2><ol class="nby-steps">' +
			'<li><span><a href="' + esc( rawUrl( 'template', 0 ) ) + '">' + 'فایل نمونه CSV را دانلود کنید</a> و در اکسل باز کنید؛ هر ردیف یک نفر.</span></li>' +
			'<li><span>تاریخ‌ها را شمسی بنویسید (مثل ۱۳۷۰/۰۵/۱۲)؛ خودکار تبدیل می‌شوند. جنسیت، شغل و محل را فارسی بنویسید.</span></li>' +
			'<li><span>در ستون «' + esc( C.fileCol ) + '» نام فایل اسکن را بنویسید و همه اسکن‌ها را در یک ZIP بگذارید.</span></li>' +
			'<li><span>پرونده‌های کامل مستقیم وارد صف می‌شوند؛ بقیه پیش‌نویس می‌مانند تا اصلاح شوند.</span></li></ol></aside></div></div>';

		$$( '[data-drop]', main ).forEach( function ( drop ) {
			var inp = drop.querySelector( 'input' );
			[ 'dragenter', 'dragover' ].forEach( function ( ev ) { drop.addEventListener( ev, function ( e ) { e.preventDefault(); drop.classList.add( 'is-over' ); } ); } );
			[ 'dragleave', 'drop' ].forEach( function ( ev ) { drop.addEventListener( ev, function () { drop.classList.remove( 'is-over' ); } ); } );
			drop.addEventListener( 'drop', function ( e ) { e.preventDefault(); if ( e.dataTransfer.files.length ) { inp.files = e.dataTransfer.files; inp.dispatchEvent( new Event( 'change' ) ); } } );
			inp.addEventListener( 'change', function () {
				var f = inp.files[ 0 ];
				if ( f ) { $( '[data-ftitle]', drop ).textContent = f.name; $( '[data-fsub]', drop ).textContent = ( f.size / 1024 ).toFixed( 0 ) + ' کیلوبایت'; }
			} );
		} );

		var form = $( '#nby-imp', main );
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			if ( ! form.csv.files.length ) { toast( 'فایل CSV را انتخاب کنید.', 'warn' ); return; }
			var btn = form.querySelector( '[type=submit]' );
			busy( btn, true );
			var fd = new FormData( form );
			if ( ! form.zip.files.length ) { fd.delete( 'zip' ); }
			api( 'import', { body: fd } ).then( function ( rep ) {
				var out = '<div class="nby-report"><div class="nby-tile is-accent"><b>' + fa( rep.imported ) + '</b><span>پرونده وارد شد</span></div><div class="nby-tile is-ok"><b>' + fa( rep.queued ) + '</b><span>مستقیم وارد صف شد</span></div><div class="nby-tile is-warn"><b>' + fa( rep.drafts ) + '</b><span>پیش‌نویس (ناقص)</span></div></div>';
				if ( rep.errors && rep.errors.length ) {
					out += '<div class="nby-banner is-warn">' + ic( 'alert' ) + '<div><b>موارد قابل توجه:</b><ul>' + rep.errors.slice( 0, 50 ).map( function ( x ) { return '<li>' + esc( x ) + '</li>'; } ).join( '' ) + '</ul></div></div>';
				}
				if ( rep.drafts ) { out += '<a class="nby-btn" href="' + hashFor( 'applicants', { status: 'draft' } ) + '">' + ic( 'edit' ) + 'دیدن پیش‌نویس‌ها</a>'; }
				$( '#nby-imp-out' ).innerHTML = out;
				toast( fa( rep.imported ) + ' پرونده وارد شد.', rep.errors && rep.errors.length ? 'warn' : 'ok' );
				refreshStatus();
			} ).catch( function ( x ) { toast( x.message, 'bad' ); } ).then( function () { busy( btn, false ); } );
		} );
	}

	/* ================================================================ boot */

	window.addEventListener( 'hashchange', render );
	function start() {
		if ( C.mode === 'panel' && ! S.me ) {
			renderLogin();
		} else {
			if ( ! location.hash ) { history.replaceState( null, '', '#/dashboard' ); }
			render();
		}
	}
	if ( C.mode === 'panel' ) {
		// The page HTML may come from a cache: re-read identity + CSRF and find a working transport first.
		api( 'me' ).then( function ( r ) { S.me = r.me; S.csrf = r.csrf; start(); }, function () { S.me = null; renderLogin(); } );
	} else {
		start();
	}
}() );
