<?php
/**
 * Server cron entry point (command line only), e.g. DirectAdmin:
 *   /usr/local/bin/php /home/USER/domains/SITE/public_html/wp-content/plugins/nobatyar/cron.php >/dev/null 2>&1
 */
if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 403 );
	exit;
}
$nby_wp_load = dirname( __DIR__, 3 ) . '/wp-load.php';
if ( ! file_exists( $nby_wp_load ) ) {
	fwrite( STDERR, "wp-load.php not found at $nby_wp_load\n" );
	exit( 1 );
}
define( 'NBY_CRON_CLI', true );
require $nby_wp_load;
if ( ! class_exists( 'NBY_Runner' ) ) {
	fwrite( STDERR, "Nobatyar plugin is not active.\n" );
	exit( 1 );
}
$nby_result = NBY_Runner::tick( 'server-cron' );
unset( $nby_result['results'] );
echo wp_json_encode( $nby_result ) . "\n";
