<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$nby_settings = get_option( 'nby_settings', array() );
if ( empty( $nby_settings['delete_on_uninstall'] ) ) {
	return; // Data kept unless the admin explicitly asked for deletion.
}

global $wpdb;
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}nby_attempts" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}nby_citizens" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}nby_users" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}nby_sessions" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}nby_activity" );
foreach ( array( 'nby_settings', 'nby_state', 'nby_control', 'nby_db_version', 'nby_tick_lock', 'nby_flush_rewrite', 'nby_notify_last' ) as $nby_opt ) {
	delete_option( $nby_opt );
}
remove_role( 'nby_operator' );
$nby_admin = get_role( 'administrator' );
if ( $nby_admin ) {
	$nby_admin->remove_cap( 'nby_manage' );
}

$nby_up  = wp_upload_dir( null, false );
$nby_dir = trailingslashit( $nby_up['basedir'] ) . 'nobatyar-private';
if ( is_dir( $nby_dir ) ) {
	$nby_it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $nby_dir, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
	foreach ( $nby_it as $nby_f ) {
		$nby_f->isDir() ? @rmdir( $nby_f->getPathname() ) : @unlink( $nby_f->getPathname() );
	}
	@rmdir( $nby_dir );
}
