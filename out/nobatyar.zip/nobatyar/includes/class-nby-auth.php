<?php
defined( 'ABSPATH' ) || exit;

/**
 * Panel accounts (separate from WordPress users) + session cookie + permissions + session history.
 *
 * A request's "actor" is either:
 *  - a WordPress user with the nby_manage capability (wp-admin side, REST nonce), role = manager, or
 *  - a panel account authenticated by the nby_s session cookie (+ CSRF token on writes).
 */
class NBY_Auth {

	const COOKIE       = 'nby_s';
	const MIN_PASS     = 8;
	const MAX_FAILS    = 8;
	const LOCK_SECONDS = 900;
	const IDLE_CLOSE   = 7200; // a session idle this long is closed and its work report sent

	private static $actor = false;

	/** Front-end panel page / ajax bridge: identify by panel session only, never by a WordPress login. */
	public static $panel_only = false;

	public static function init() {
		add_action( NBY_Runner::DAILY, array( __CLASS__, 'purge_sessions' ) );
	}

	public static function t_users() {
		global $wpdb;
		return $wpdb->prefix . 'nby_users';
	}

	public static function t_sessions() {
		global $wpdb;
		return $wpdb->prefix . 'nby_sessions';
	}

	public static function install( $cs ) {
		$u = self::t_users();
		$s = self::t_sessions();
		dbDelta( "CREATE TABLE $u (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  username varchar(60) NOT NULL,
  pass_hash varchar(255) NOT NULL,
  display_name varchar(100) NOT NULL DEFAULT '',
  role varchar(20) NOT NULL DEFAULT 'operator',
  active tinyint(1) NOT NULL DEFAULT 1,
  last_login datetime NULL DEFAULT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY username (username)
) $cs;" );
		dbDelta( "CREATE TABLE $s (
  token_hash char(64) NOT NULL,
  user_id bigint(20) unsigned NOT NULL,
  expires_at int(10) unsigned NOT NULL,
  ip varchar(45) NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  started_at int(10) unsigned NOT NULL DEFAULT 0,
  last_seen int(10) unsigned NOT NULL DEFAULT 0,
  ended tinyint(1) NOT NULL DEFAULT 0,
  ended_at int(10) unsigned NOT NULL DEFAULT 0,
  end_reason varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY  (token_hash),
  KEY user_id (user_id,started_at),
  KEY expires_at (expires_at),
  KEY open_idx (ended,last_seen)
) $cs;" );
		// Sessions from before v1.2 have no history columns: close expired ones silently, adopt live ones.
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "UPDATE $s SET ended = 1, end_reason = 'upgrade' WHERE started_at = 0 AND expires_at < %d", time() ) );
		$wpdb->query( $wpdb->prepare( "UPDATE $s SET started_at = %d, last_seen = %d WHERE started_at = 0", time(), time() ) );
	}

	/* ------------------------------------------------------------------ roles */

	public static function roles() {
		return array(
			'manager'  => 'مدیر',
			'operator' => 'اپراتور',
		);
	}

	/**
	 * Operators: view, add/edit applicants, bulk import.
	 * Managers: + immediate submit / manual run, delete, bot control, operator management.
	 */
	public static function role_caps( $role ) {
		$base = array( 'view', 'edit', 'import' );
		return 'manager' === $role ? array_merge( $base, array( 'try', 'delete', 'control', 'team', 'all', 'priority' ) ) : $base;
	}

	/* ------------------------------------------------------------------ users */

	public static function get_user( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t_users() . ' WHERE id = %d', $id ), ARRAY_A );
	}

	public static function get_by_username( $username ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t_users() . ' WHERE username = %s', $username ), ARRAY_A );
	}

	public static function list_users() {
		global $wpdb;
		return $wpdb->get_results( 'SELECT id, username, display_name, role, active, last_login, created_at FROM ' . self::t_users() . ' ORDER BY role ASC, id ASC', ARRAY_A );
	}

	private static function check_username( $u ) {
		if ( ! preg_match( '/^[A-Za-z0-9_.\-@]{3,40}$/', $u ) ) {
			return new WP_Error( 'nby_user', 'نام کاربری باید ۳ تا ۴۰ حرف انگلیسی، عدد یا . _ - @ باشد.' );
		}
		return true;
	}

	public static function check_password( $p ) {
		if ( strlen( $p ) < self::MIN_PASS ) {
			return new WP_Error( 'nby_user', 'رمز عبور باید حداقل ' . self::MIN_PASS . ' کاراکتر باشد.' );
		}
		if ( preg_match( '/^(\d)\1+$|^(0?123456789?|12345678|password|qwerty123|11111111)$/i', $p ) ) {
			return new WP_Error( 'nby_user', 'این رمز خیلی ساده و قابل حدس است؛ رمز دیگری انتخاب کنید.' );
		}
		return true;
	}

	public static function create_user( $username, $password, $display, $role ) {
		global $wpdb;
		$username = trim( $username );
		$ok       = self::check_username( $username );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$ok = self::check_password( $password );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		if ( self::get_by_username( $username ) ) {
			return new WP_Error( 'nby_user', 'این نام کاربری قبلاً ساخته شده است.' );
		}
		$role = isset( self::roles()[ $role ] ) ? $role : 'operator';
		$disp = mb_substr( sanitize_text_field( $display ? $display : $username ), 0, 100 );
		$wpdb->insert(
			self::t_users(),
			array(
				'username'     => $username,
				'pass_hash'    => wp_hash_password( $password ),
				'display_name' => $disp,
				'role'         => $role,
				'active'       => 1,
				'created_at'   => current_time( 'mysql', true ),
			)
		);
		$id = (int) $wpdb->insert_id;
		NBY_Activity::log( 'user_create', $id, $disp, array( 'note' => self::roles()[ $role ] . ' — ' . $username ) );
		NBY_Notify::event( 'password', array( 'حساب_جدید', self::roles()[ $role ] ), '🆕 حساب جدید ساخته شد', array( '👤 ' . $disp . ' (' . $username . ')', '🎖 نقش: ' . self::roles()[ $role ], '🛠 توسط: ' . self::who() ) );
		return $id;
	}

	/** Name of whoever is acting right now (panel user, WP admin, or system). */
	public static function who() {
		$n = self::actor_name();
		if ( '' === $n && is_user_logged_in() ) {
			$u = wp_get_current_user();
			$n = ( $u->display_name ? $u->display_name : $u->user_login ) . ' (وردپرس)';
		}
		return '' !== $n ? $n : 'سیستم';
	}

	public static function update_user( $id, array $f ) {
		global $wpdb;
		$user = self::get_user( $id );
		if ( ! $user ) {
			return new WP_Error( 'nby_user', 'حساب پیدا نشد.' );
		}
		$row = array();
		if ( isset( $f['display_name'] ) && '' !== trim( $f['display_name'] ) ) {
			$row['display_name'] = mb_substr( sanitize_text_field( $f['display_name'] ), 0, 100 );
		}
		if ( isset( $f['role'] ) && isset( self::roles()[ $f['role'] ] ) ) {
			$row['role'] = $f['role'];
		}
		if ( isset( $f['active'] ) ) {
			$row['active'] = $f['active'] ? 1 : 0;
		}
		if ( isset( $f['password'] ) && '' !== $f['password'] ) {
			$ok = self::check_password( $f['password'] );
			if ( is_wp_error( $ok ) ) {
				return $ok;
			}
			$row['pass_hash'] = wp_hash_password( $f['password'] );
		}
		if ( ! $row ) {
			return true;
		}
		$wpdb->update( self::t_users(), $row, array( 'id' => (int) $id ) );
		$name = $user['display_name'] . ' (' . $user['username'] . ')';
		if ( isset( $row['pass_hash'] ) && empty( $f['silent'] ) ) {
			self::end_sessions( $id, 'password' );
			NBY_Activity::log( 'password', $id, $user['display_name'] );
			NBY_Notify::event( 'password', array( 'تغییر_رمز' ), '🔑 رمز عبور عوض شد', array( '👤 حساب: ' . $name, '🛠 توسط: ' . self::who(), '🚪 همه نشست‌های قبلی این حساب بسته شد.' ) );
		}
		if ( isset( $row['active'] ) && ! $row['active'] && (int) $user['active'] ) {
			self::end_sessions( $id, 'disabled' );
			NBY_Notify::event( 'password', array( 'غیرفعال_شدن_حساب' ), '⛔ حساب غیرفعال شد', array( '👤 حساب: ' . $name, '🛠 توسط: ' . self::who() ) );
		}
		if ( isset( $row['display_name'] ) || isset( $row['role'] ) || isset( $row['active'] ) ) {
			NBY_Activity::log( 'user_update', $id, isset( $row['display_name'] ) ? $row['display_name'] : $user['display_name'] );
		}
		return true;
	}

	public static function delete_user( $id ) {
		global $wpdb;
		self::end_sessions( $id, 'deleted' );
		$wpdb->delete( self::t_users(), array( 'id' => (int) $id ) );
	}

	/** Close every open session of a user (logout everywhere). */
	public static function end_sessions( $user_id, $reason ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t_sessions() . ' SET ended = 1, ended_at = %d, end_reason = %s, expires_at = LEAST(expires_at, %d) WHERE user_id = %d AND ended = 0', time(), $reason, time(), $user_id ) );
	}

	public static function purge_sessions() {
		global $wpdb;
		// keep 180 days of session history for the activity report
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::t_sessions() . ' WHERE ended = 1 AND started_at < %d', time() - 180 * DAY_IN_SECONDS ) );
	}

	/**
	 * Sessions that expired or went idle without an explicit logout get closed here (called by the bot tick)
	 * so the logout report is still sent.
	 */
	public static function close_idle_sessions() {
		global $wpdb;
		$now  = time();
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT s.*, u.display_name, u.username, u.role FROM ' . self::t_sessions() . ' s JOIN ' . self::t_users() . ' u ON u.id = s.user_id WHERE s.ended = 0 AND ( s.expires_at < %d OR ( s.last_seen > 0 AND s.last_seen < %d ) ) LIMIT 20',
				$now,
				$now - self::IDLE_CLOSE
			),
			ARRAY_A
		);
		foreach ( $rows as $s ) {
			$end = max( (int) $s['last_seen'], (int) $s['started_at'] );
			$wpdb->update( self::t_sessions(), array( 'ended' => 1, 'ended_at' => $end, 'end_reason' => 'idle', 'expires_at' => min( (int) $s['expires_at'], $now ) ), array( 'token_hash' => $s['token_hash'] ) );
			NBY_Activity::log( 'logout_auto', (int) $s['user_id'], $s['display_name'], array( 'note' => 'بدون زدن دکمه خروج' ), 'p:' . $s['user_id'], $s['display_name'] );
			self::send_report( $s, $end, true );
		}
	}

	private static function send_report( array $s, $end_ts, $auto ) {
		$role  = isset( self::roles()[ $s['role'] ] ) ? self::roles()[ $s['role'] ] : '';
		$key   = 'p:' . $s['user_id'];
		$since = gmdate( 'Y-m-d H:i:s', (int) $s['started_at'] ? min( (int) $s['started_at'], strtotime( NBY_Activity::today_start() . ' UTC' ) ) : strtotime( NBY_Activity::today_start() . ' UTC' ) );
		$lines = NBY_Activity::report_lines( $key, NBY_Activity::today_start(), (int) $s['started_at'], $end_ts );
		NBY_Notify::event(
			'logout',
			array( $auto ? 'خروج_خودکار' : 'خروج', 'گزارش_کار', $role ),
			'👋 ' . $role . ' «' . $s['display_name'] . '» ' . ( $auto ? 'مدتی فعالیت نداشت و نشستش بسته شد' : 'از پنل خارج شد' ),
			$lines
		);
		unset( $since );
	}

	/* ------------------------------------------------------------------ login */

	private static function ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ), 0, 45 ) : '';
	}

	private static function fail_keys( $username ) {
		return array( 'nby_lf_ip_' . md5( self::ip() ), 'nby_lf_u_' . md5( strtolower( $username ) ) );
	}

	public static function locked( $username ) {
		foreach ( self::fail_keys( $username ) as $k ) {
			if ( (int) get_transient( $k ) >= self::MAX_FAILS ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Returns user row on success or WP_Error.
	 */
	public static function login( $username, $password, $remember ) {
		$username = trim( (string) $username );
		if ( self::locked( $username ) ) {
			return new WP_Error( 'nby_locked', 'به‌دلیل تلاش‌های ناموفق زیاد، ورود تا ۱۵ دقیقه بسته است.' );
		}
		$user = '' !== $username ? self::get_by_username( $username ) : null;
		// Constant-ish time: always run one password check.
		$ok = wp_check_password( (string) $password, $user ? $user['pass_hash'] : '$P$BXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX' );
		if ( ! $user || ! $ok || ! (int) $user['active'] ) {
			$hit = 0;
			foreach ( self::fail_keys( $username ) as $k ) {
				$n = (int) get_transient( $k ) + 1;
				set_transient( $k, $n, self::LOCK_SECONDS );
				$hit = max( $hit, $n );
			}
			if ( self::MAX_FAILS === $hit ) {
				NBY_Activity::log( 'login_locked', $user ? (int) $user['id'] : 0, $username, array( 'note' => 'IP ' . self::ip() ), $user ? 'p:' . $user['id'] : '', $user ? $user['display_name'] : $username );
				NBY_Notify::event( 'security', array( 'امنیت', 'قفل_ورود' ), '🚨 ورود به‌دلیل رمزهای اشتباه پیاپی قفل شد', array( '👤 نام کاربری واردشده: ' . $username, '🌐 IP: ' . self::ip(), '⏳ تا ۱۵ دقیقه امکان ورود نیست.' ) );
			}
			return new WP_Error( 'nby_bad', ( $user && $ok && ! (int) $user['active'] ) ? 'این حساب غیرفعال شده است.' : 'نام کاربری یا رمز عبور اشتباه است.' );
		}
		foreach ( self::fail_keys( $username ) as $k ) {
			delete_transient( $k );
		}
		if ( function_exists( 'wp_password_needs_rehash' ) && wp_password_needs_rehash( $user['pass_hash'] ) ) {
			self::update_user( $user['id'], array( 'password' => $password, 'silent' => true ) );
		}
		self::start_session( (int) $user['id'], (bool) $remember );
		global $wpdb;
		$wpdb->update( self::t_users(), array( 'last_login' => current_time( 'mysql', true ) ), array( 'id' => (int) $user['id'] ) );
		$role = self::roles()[ $user['role'] ];
		NBY_Activity::log( 'login', (int) $user['id'], $user['display_name'], array(), 'p:' . $user['id'], $user['display_name'] );
		NBY_Notify::event( 'login', array( 'ورود', $role ), '🔓 ' . $role . ' «' . $user['display_name'] . '» وارد پنل شد', array( '👤 نام کاربری: ' . $user['username'], '🌐 IP: ' . self::ip(), '🧭 مرورگر: ' . self::ua_short() ) );
		return $user;
	}

	private static function ua_short() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';
		$os = preg_match( '/Android/i', $ua ) ? 'اندروید' : ( preg_match( '/iPhone|iPad/i', $ua ) ? 'iOS' : ( preg_match( '/Windows/i', $ua ) ? 'ویندوز' : ( preg_match( '/Mac OS/i', $ua ) ? 'مک' : 'دیگر' ) ) );
		$br = preg_match( '/Edg\//', $ua ) ? 'Edge' : ( preg_match( '/Firefox\//', $ua ) ? 'Firefox' : ( preg_match( '/Chrome\//', $ua ) ? 'Chrome' : ( preg_match( '/Safari\//', $ua ) ? 'Safari' : 'نامشخص' ) ) );
		return $br . ' / ' . $os;
	}

	private static function start_session( $user_id, $remember ) {
		global $wpdb;
		$token   = wp_generate_password( 48, false, false );
		$expires = time() + ( $remember ? 14 * DAY_IN_SECONDS : 12 * HOUR_IN_SECONDS );
		$wpdb->insert(
			self::t_sessions(),
			array(
				'token_hash' => hash( 'sha256', $token ),
				'user_id'    => $user_id,
				'expires_at' => $expires,
				'ip'         => self::ip(),
				'created_at' => current_time( 'mysql', true ),
				'started_at' => time(),
				'last_seen'  => time(),
			)
		);
		self::set_cookie( $token, $remember ? $expires : 0 );
		$_COOKIE[ self::COOKIE ] = $token;
		self::$actor             = false;
	}

	private static function set_cookie( $value, $expires ) {
		if ( headers_sent() ) {
			return;
		}
		setcookie(
			self::COOKIE,
			$value,
			array(
				'expires'  => $expires,
				'path'     => '/',
				'domain'   => COOKIE_DOMAIN ? COOKIE_DOMAIN : '',
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
	}

	public static function logout() {
		global $wpdb;
		$tok = self::token();
		if ( $tok ) {
			$hash = hash( 'sha256', $tok );
			$s    = $wpdb->get_row( $wpdb->prepare( 'SELECT s.*, u.display_name, u.username, u.role FROM ' . self::t_sessions() . ' s JOIN ' . self::t_users() . ' u ON u.id = s.user_id WHERE s.token_hash = %s', $hash ), ARRAY_A );
			if ( $s && ! (int) $s['ended'] ) {
				$wpdb->update( self::t_sessions(), array( 'ended' => 1, 'ended_at' => time(), 'end_reason' => 'logout', 'expires_at' => time() ), array( 'token_hash' => $hash ) );
				NBY_Activity::log( 'logout', (int) $s['user_id'], $s['display_name'], array(), 'p:' . $s['user_id'], $s['display_name'] );
				self::send_report( $s, time(), false );
			}
		}
		self::set_cookie( '', time() - YEAR_IN_SECONDS );
		unset( $_COOKIE[ self::COOKIE ] );
		self::$actor = false;
	}

	private static function token() {
		$t = isset( $_COOKIE[ self::COOKIE ] ) ? (string) wp_unslash( $_COOKIE[ self::COOKIE ] ) : '';
		return preg_match( '/^[A-Za-z0-9]{48}$/', $t ) ? $t : '';
	}

	public static function panel_user() {
		global $wpdb;
		$tok = self::token();
		if ( ! $tok ) {
			return null;
		}
		$hash = hash( 'sha256', $tok );
		$row  = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT u.*, s.last_seen AS s_last_seen FROM ' . self::t_sessions() . ' s JOIN ' . self::t_users() . ' u ON u.id = s.user_id WHERE s.token_hash = %s AND s.expires_at > %d AND s.ended = 0 AND u.active = 1',
				$hash,
				time()
			),
			ARRAY_A
		);
		if ( $row && time() - (int) $row['s_last_seen'] > 60 ) {
			$wpdb->update( self::t_sessions(), array( 'last_seen' => time() ), array( 'token_hash' => $hash ) );
		}
		return $row ? $row : null;
	}

	public static function csrf() {
		$tok = self::token();
		return $tok ? hash_hmac( 'sha256', 'csrf|' . $tok, wp_salt( 'auth' ) ) : '';
	}

	public static function check_csrf( $value ) {
		$own = self::csrf();
		return '' !== $own && is_string( $value ) && hash_equals( $own, $value );
	}

	/** Change own password (panel user) after re-checking the current one. */
	public static function change_own_password( $current, $new ) {
		$a = self::actor();
		if ( ! $a || 'panel' !== $a['type'] ) {
			return new WP_Error( 'nby_user', 'فقط حساب‌های پنل از اینجا رمز عوض می‌کنند.' );
		}
		$u = self::get_user( $a['id'] );
		if ( ! $u || ! wp_check_password( (string) $current, $u['pass_hash'] ) ) {
			return new WP_Error( 'nby_user', 'رمز فعلی اشتباه است.' );
		}
		global $wpdb;
		$ok = self::check_password( (string) $new );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$wpdb->update( self::t_users(), array( 'pass_hash' => wp_hash_password( (string) $new ) ), array( 'id' => (int) $u['id'] ) );
		// keep this session, close the others
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t_sessions() . ' SET ended = 1, ended_at = %d, end_reason = %s, expires_at = %d WHERE user_id = %d AND ended = 0 AND token_hash <> %s', time(), 'password', time(), (int) $u['id'], hash( 'sha256', self::token() ) ) );
		NBY_Activity::log( 'password', (int) $u['id'], $u['display_name'], array( 'note' => 'توسط خود کاربر' ) );
		NBY_Notify::event( 'password', array( 'تغییر_رمز' ), '🔑 رمز عبور عوض شد', array( '👤 حساب: ' . $u['display_name'] . ' (' . $u['username'] . ')', '🛠 توسط: خود کاربر', '🚪 نشست‌های دیگر این حساب بسته شد.' ) );
		return true;
	}

	/* ------------------------------------------------------------------ actor */

	/** array(type, id, name, username, role, caps) or null. */
	public static function actor() {
		if ( false !== self::$actor ) {
			return self::$actor;
		}
		$a = null;
		if ( ! self::$panel_only && is_user_logged_in() && current_user_can( 'nby_manage' ) ) {
			$u = wp_get_current_user();
			$a = array(
				'type'     => 'wp',
				'id'       => (int) $u->ID,
				'name'     => $u->display_name ? $u->display_name : $u->user_login,
				'username' => $u->user_login,
				'role'     => 'manager',
			);
		} else {
			$p = self::panel_user();
			if ( $p ) {
				$a = array(
					'type'     => 'panel',
					'id'       => (int) $p['id'],
					'name'     => $p['display_name'] ? $p['display_name'] : $p['username'],
					'username' => $p['username'],
					'role'     => $p['role'],
				);
			}
		}
		if ( $a ) {
			$a['caps']      = self::role_caps( $a['role'] );
			$a['role_name'] = self::roles()[ $a['role'] ];
		}
		self::$actor = $a;
		return $a;
	}

	/**
	 * Owner filter for the current actor: operators only ever see applicants they created themselves,
	 * managers (and WordPress admins) see everything (null).
	 */
	public static function scope() {
		$a = self::actor();
		if ( ! $a ) {
			return 'p:0';
		}
		return in_array( 'all', $a['caps'], true ) ? null : self::actor_key();
	}

	/** May the current actor see / touch this applicant row? */
	public static function owns( array $row ) {
		$s = self::scope();
		return null === $s || ( isset( $row['owner'] ) && $row['owner'] === $s );
	}

	public static function can( $cap ) {
		$a = self::actor();
		return $a && in_array( $cap, $a['caps'], true );
	}

	public static function actor_name() {
		$a = self::actor();
		if ( $a ) {
			return mb_substr( $a['name'], 0, 100 );
		}
		return ( defined( 'DOING_CRON' ) || defined( 'NBY_CRON_CLI' ) ) ? 'سیستم' : '';
	}

	/** 'p:ID' for panel accounts, 'w:ID' for WordPress admins, '' for the system. */
	public static function actor_key() {
		$a = self::actor();
		if ( ! $a ) {
			return '';
		}
		return ( 'panel' === $a['type'] ? 'p:' : 'w:' ) . $a['id'];
	}

	/* ------------------------------------------------------------------ team overview */

	public static function sessions_of( $user_id, $limit = 20 ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT started_at, last_seen, ended, ended_at, end_reason, ip, expires_at FROM ' . self::t_sessions() . ' WHERE user_id = %d AND started_at > 0 ORDER BY started_at DESC LIMIT %d', $user_id, $limit ), ARRAY_A );
		$why  = array( 'logout' => 'خروج', 'idle' => 'بی‌فعالیتی', 'password' => 'تغییر رمز', 'disabled' => 'غیرفعال شدن', 'deleted' => 'حذف حساب' );
		return array_map(
			function ( $s ) use ( $why ) {
				$open = ! (int) $s['ended'] && (int) $s['expires_at'] > time();
				$end  = $open ? (int) $s['last_seen'] : (int) $s['ended_at'];
				return array(
					'start'    => NBY_Jalali::ts( (int) $s['started_at'] ),
					'end'      => $open ? 'هنوز در پنل' : NBY_Jalali::ts( $end ),
					'open'     => $open,
					'duration' => NBY_Activity::duration( max( 0, $end - (int) $s['started_at'] ) ),
					'reason'   => $open ? '' : ( isset( $why[ $s['end_reason'] ] ) ? $why[ $s['end_reason'] ] : 'پایان اعتبار' ),
					'ip'       => $s['ip'],
				);
			},
			$rows
		);
	}

	public static function online_ids() {
		global $wpdb;
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT user_id FROM ' . self::t_sessions() . ' WHERE ended = 0 AND expires_at > %d AND last_seen > %d', time(), time() - 300 ) ) );
	}
}
