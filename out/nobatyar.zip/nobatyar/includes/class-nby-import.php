<?php
defined( 'ABSPATH' ) || exit;

/**
 * Bulk import: CSV (UTF-8, headers = Persian labels or field keys) + optional ZIP of tazkira files.
 */
class NBY_Import {

	const FILE_COL = 'فایل تذکره';

	public static function columns() {
		$cols = array();
		foreach ( NBY_Fields::schema() as $k => $f ) {
			$cols[ $k ] = $f['label'];
		}
		$cols['_file']     = self::FILE_COL;
		$cols['_priority'] = 'اولویت';
		$cols['_notes']    = 'یادداشت';
		return $cols;
	}

	public static function template_csv() {
		$cols = self::columns();
		$out  = "\xEF\xBB\xBF" . self::csv_line( array_values( $cols ) );
		$ex   = array(
			'name'                            => 'نصرالله',
			'surname'                         => 'نصیری',
			'fathers_name'                    => 'محمد',
			'grandfathers_name'               => 'احمد',
			'mothers_name'                    => 'فاطمه',
			'date_of_birth'                   => '1370/05/12',
			'gender'                          => 'مرد',
			'occupation'                      => 'کارگر ماهر',
			'religion'                        => 'اسلام',
			'country'                         => 'افغانستان',
			'province'                        => 'هرات',
			'city'                            => 'هرات',
			'duration_of_residence_abroad'    => '15',
			'last_return_date_to_afghanistan' => '1402/01/15',
			'current_residenced'              => 'مشهد',
			'Number_of_children'              => '2',
			'Ch_names'                        => 'شکریه و شکیلا',
			'marital_status'                  => 'متأهل',
			'mother_tongue'                   => 'دری',
			'thumbprint'                      => 'تاجیک',
			'phone_number'                    => '09150000000',
			'email_address'                   => '',
			'post_address'                    => '9100000000',
			'team'                            => 'مشهد',
			'_doc_type'                       => 'کارت آمایش',
			'foreign_document_number'         => '123456789',
			'_file'                           => 'nasiri.jpg',
			'_priority'                       => '0',
			'_notes'                          => '',
		);
		$row  = array();
		foreach ( array_keys( $cols ) as $k ) {
			$row[] = isset( $ex[ $k ] ) ? $ex[ $k ] : '';
		}
		return $out . self::csv_line( $row );
	}

	private static function csv_line( array $cells ) {
		$o = array();
		foreach ( $cells as $c ) {
			$c   = (string) $c;
			$o[] = '"' . str_replace( '"', '""', $c ) . '"';
		}
		return implode( ',', $o ) . "\r\n";
	}

	private static function norm( $s ) {
		$s = trim( str_replace( array( "\xEF\xBB\xBF", '‌', 'ي', 'ك', 'أ' ), array( '', ' ', 'ی', 'ک', 'ا' ), (string) $s ) );
		return mb_strtolower( preg_replace( '/\s+/u', ' ', $s ) );
	}

	/** Map Persian label → option code for selects / team / doc type. */
	private static function to_code( $key, $val ) {
		$val = trim( (string) $val );
		if ( '' === $val ) {
			return '';
		}
		$schema = NBY_Fields::schema();
		if ( '_doc_type' === $key ) {
			foreach ( NBY_Fields::doc_types() as $opts ) {
				foreach ( $opts as $code => $label ) {
					if ( $val === $code || self::norm( $val ) === self::norm( $label ) ) {
						return $code;
					}
				}
			}
			return $val;
		}
		if ( isset( $schema[ $key ]['options'] ) ) {
			foreach ( $schema[ $key ]['options'] as $code => $label ) {
				if ( self::norm( $val ) === self::norm( $code ) || self::norm( $val ) === self::norm( $label ) ) {
					return $code;
				}
			}
			$aliases = array( 'متاهل' => 'Married', 'married' => 'Married', 'single' => 'Unmarried', 'male' => 'Male', 'female' => 'Female' );
			if ( isset( $aliases[ self::norm( $val ) ] ) ) {
				return $aliases[ self::norm( $val ) ];
			}
		}
		return $val;
	}

	/**
	 * Returns array(imported, queued, drafts, errors[]).
	 */
	public static function run( $csv_path, $zip_path = '' ) {
		$report = array( 'imported' => 0, 'queued' => 0, 'drafts' => 0, 'errors' => array() );
		$raw    = file_get_contents( $csv_path );
		if ( false === $raw || '' === $raw ) {
			$report['errors'][] = 'فایل CSV خالی است.';
			return $report;
		}
		if ( ! preg_match( '//u', $raw ) ) {
			$conv = @iconv( 'windows-1256', 'UTF-8//IGNORE', $raw );
			if ( $conv ) {
				$raw = $conv;
			}
		}
		if ( 0 === strpos( $raw, "\xEF\xBB\xBF" ) ) {
			$raw = substr( $raw, 3 ); // BOM before the first quote breaks fgetcsv enclosure parsing
		}
		$fh = fopen( 'php://temp', 'r+' );
		fwrite( $fh, $raw );
		rewind( $fh );
		$first = fgets( $fh );
		$delim = ( substr_count( $first, ';' ) > substr_count( $first, ',' ) ) ? ';' : ( substr_count( $first, "\t" ) > substr_count( $first, ',' ) ? "\t" : ',' );
		rewind( $fh );
		$header = fgetcsv( $fh, 0, $delim );
		if ( ! $header ) {
			$report['errors'][] = 'سطر عنوان ستون‌ها پیدا نشد.';
			return $report;
		}
		$map = array();
		foreach ( $header as $i => $h ) {
			$hn = self::norm( $h );
			foreach ( self::columns() as $k => $label ) {
				if ( $hn === self::norm( $k ) || $hn === self::norm( $label ) ) {
					$map[ $i ] = $k;
				}
			}
		}
		if ( ! in_array( 'name', $map, true ) ) {
			$report['errors'][] = 'ستون «نام» پیدا نشد. از قالب نمونه استفاده کنید.';
			return $report;
		}

		$zipfiles = array();
		$tmpdir   = '';
		if ( $zip_path ) {
			if ( ! class_exists( 'ZipArchive' ) ) {
				$report['errors'][] = 'افزونه ZipArchive روی سرور فعال نیست؛ فایل‌ها را تکی بارگذاری کنید.';
			} else {
				$zip = new ZipArchive();
				if ( true === $zip->open( $zip_path ) ) {
					$tmpdir = trailingslashit( get_temp_dir() ) . 'nby-' . wp_generate_password( 10, false, false );
					wp_mkdir_p( $tmpdir );
					for ( $i = 0; $i < $zip->numFiles; $i++ ) {
						$n = $zip->getNameIndex( $i );
						if ( '/' === substr( $n, -1 ) ) {
							continue;
						}
						$base = basename( str_replace( '\\', '/', $n ) );
						if ( '' === $base || '.' === $base[0] ) {
							continue;
						}
						$dest = $tmpdir . '/' . md5( $n ) . '-' . sanitize_file_name( $base );
						$data = $zip->getFromIndex( $i );
						if ( false !== $data && strlen( $data ) < 30 * MB_IN_BYTES ) {
							file_put_contents( $dest, $data );
							$zipfiles[ self::norm( $base ) ] = array( $dest, $base );
						}
					}
					$zip->close();
				} else {
					$report['errors'][] = 'فایل ZIP باز نشد.';
				}
			}
		}

		$line = 1;
		while ( ( $row = fgetcsv( $fh, 0, $delim ) ) !== false ) {
			$line++;
			if ( ! array_filter( $row, 'strlen' ) ) {
				continue;
			}
			$in = array();
			foreach ( $map as $i => $k ) {
				$in[ $k ] = isset( $row[ $i ] ) ? trim( $row[ $i ] ) : '';
			}
			foreach ( array( 'gender', 'occupation', 'marital_status', 'team', '_doc_type' ) as $k ) {
				if ( isset( $in[ $k ] ) ) {
					$in[ $k ] = self::to_code( $k, $in[ $k ] );
				}
			}
			$file_rel = '';
			$fname    = '';
			$mime     = '';
			if ( ! empty( $in['_file'] ) ) {
				$key = self::norm( basename( $in['_file'] ) );
				if ( isset( $zipfiles[ $key ] ) ) {
					$chk = NBY_Storage::check_file( $zipfiles[ $key ][0], $zipfiles[ $key ][1] );
					if ( is_wp_error( $chk ) ) {
						$report['errors'][] = 'سطر ' . $line . ': ' . $chk->get_error_message();
					} else {
						$file_rel = NBY_Storage::move_upload( $zipfiles[ $key ][0], $chk[0] );
						$fname    = $zipfiles[ $key ][1];
						$mime     = $chk[1];
					}
				} elseif ( $zip_path ) {
					$report['errors'][] = 'سطر ' . $line . ': فایل «' . $in['_file'] . '» در ZIP نبود.';
				}
			}
			list( $clean, $errors ) = NBY_Fields::validate( $in, '' !== $file_rel );
			$status = $errors ? 'draft' : 'queued';
			NBY_DB::save(
				array(
					'data'      => $clean,
					'status'    => $status,
					'priority'  => isset( $in['_priority'] ) ? max( 0, min( 9, (int) NBY_Jalali::digits( $in['_priority'] ) ) ) : 0,
					'notes'     => isset( $in['_notes'] ) ? sanitize_textarea_field( $in['_notes'] ) : '',
					'file_rel'  => $file_rel,
					'file_name' => $fname,
					'file_mime' => $mime,
					'last_message' => $errors ? 'ورود گروهی — موارد ناقص: ' . implode( ' ', $errors ) : '',
				)
			);
			$report['imported']++;
			if ( $errors ) {
				$report['drafts']++;
			} else {
				$report['queued']++;
			}
		}
		fclose( $fh );
		if ( $tmpdir ) {
			foreach ( (array) glob( $tmpdir . '/*' ) as $f ) {
				@unlink( $f );
			}
			@rmdir( $tmpdir );
		}
		return $report;
	}
}
