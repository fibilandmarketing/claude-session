<?php
defined( 'ABSPATH' ) || exit;

class NBY_DB {

	const DB_VERSION = '3';

	public static function statuses() {
		return array(
			'draft'      => 'پیش‌نویس',
			'queued'     => 'در صف',
			'processing' => 'در حال ارسال',
			'booked'     => 'نوبت گرفته شد',
			'needs_fix'  => 'نیاز به اصلاح',
			'uncertain'  => 'نامعلوم — بررسی',
			'on_hold'    => 'متوقف',
		);
	}

	public static function results() {
		return array(
			'success'     => 'موفق',
			'closed'      => 'بسته / پر',
			'validation'  => 'خطای اطلاعات',
			'transient'   => 'خطای شبکه',
			'uncertain'   => 'نامعلوم',
			'unknown'     => 'پاسخ ناشناخته',
			'fingerprint' => 'تغییر فرم سایت',
			'dry'         => 'آزمایشی',
			'found'       => 'یافت شد',
			'not_found'   => 'یافت نشد',
		);
	}

	public static function t_citizens() {
		global $wpdb;
		return $wpdb->prefix . 'nby_citizens';
	}

	public static function t_attempts() {
		global $wpdb;
		return $wpdb->prefix . 'nby_attempts';
	}

	public static function now() {
		return current_time( 'mysql', true );
	}

	public static function activate() {
		self::install();
		NBY_Settings::ensure_cron_key();
		NBY_Storage::ensure();
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->add_cap( 'nby_manage' );
		}
		if ( ! get_role( 'nby_operator' ) ) {
			add_role( 'nby_operator', 'اپراتور نوبت‌یار', array( 'read' => true, 'nby_manage' => true ) );
		}
		NBY_Runner::schedule();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'nby_db_version' ) !== self::DB_VERSION ) {
			self::install();
		}
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$cs = $wpdb->get_charset_collate();
		$c  = self::t_citizens();
		$a  = self::t_attempts();
		dbDelta( "CREATE TABLE $c (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  status varchar(20) NOT NULL DEFAULT 'draft',
  team varchar(10) NOT NULL DEFAULT '',
  priority tinyint(4) NOT NULL DEFAULT 0,
  full_name varchar(191) NOT NULL DEFAULT '',
  phone varchar(40) NOT NULL DEFAULT '',
  data longtext NOT NULL,
  file_rel varchar(191) NOT NULL DEFAULT '',
  file_name varchar(191) NOT NULL DEFAULT '',
  file_mime varchar(100) NOT NULL DEFAULT '',
  attempts int(10) unsigned NOT NULL DEFAULT 0,
  last_attempt_at datetime NULL DEFAULT NULL,
  last_result varchar(20) NOT NULL DEFAULT '',
  last_message text NULL,
  verified_at datetime NULL DEFAULT NULL,
  ticket_no varchar(40) NOT NULL DEFAULT '',
  ticket_date varchar(80) NOT NULL DEFAULT '',
  ticket_place varchar(80) NOT NULL DEFAULT '',
  ticket_rel varchar(191) NOT NULL DEFAULT '',
  ticket_pdf_rel varchar(191) NOT NULL DEFAULT '',
  booked_at datetime NULL DEFAULT NULL,
  notes text NULL,
  created_by bigint(20) unsigned NOT NULL DEFAULT 0,
  created_by_name varchar(100) NOT NULL DEFAULT '',
  owner varchar(40) NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY status_team (status,team,priority,id),
  KEY phone (phone),
  KEY booked_at (booked_at),
  KEY owner (owner,created_at)
) $cs;" );
		dbDelta( "CREATE TABLE $a (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  citizen_id bigint(20) unsigned NOT NULL DEFAULT 0,
  team varchar(10) NOT NULL DEFAULT '',
  kind varchar(20) NOT NULL DEFAULT 'submit',
  result varchar(20) NOT NULL DEFAULT '',
  http_code smallint(6) NOT NULL DEFAULT 0,
  message text NULL,
  duration_ms int(10) unsigned NOT NULL DEFAULT 0,
  response_rel varchar(191) NOT NULL DEFAULT '',
  source varchar(20) NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY citizen_id (citizen_id),
  KEY created_at (created_at),
  KEY result (result)
) $cs;" );
		NBY_Auth::install( $cs );
		NBY_Activity::install( $cs );
		update_option( 'nby_db_version', self::DB_VERSION, false );
		update_option( 'nby_flush_rewrite', 1, false );
	}

	/* ---------- citizens ---------- */

	public static function get( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t_citizens() . ' WHERE id = %d', $id ), ARRAY_A );
		if ( $row ) {
			$row['data'] = json_decode( $row['data'], true );
			if ( ! is_array( $row['data'] ) ) {
				$row['data'] = array();
			}
		}
		return $row;
	}

	public static function save( array $fields, $id = 0 ) {
		global $wpdb;
		if ( isset( $fields['data'] ) && is_array( $fields['data'] ) ) {
			$fields['full_name'] = mb_substr( NBY_Fields::full_name( $fields['data'] ), 0, 190 );
			$fields['phone']     = isset( $fields['data']['phone_number'] ) ? $fields['data']['phone_number'] : '';
			$fields['team']      = isset( $fields['data']['team'] ) ? $fields['data']['team'] : '';
			$fields['data']      = wp_json_encode( $fields['data'], JSON_UNESCAPED_UNICODE );
		}
		$fields['updated_at'] = self::now();
		if ( $id ) {
			$wpdb->update( self::t_citizens(), $fields, array( 'id' => $id ) );
			return $id;
		}
		$fields['created_at'] = self::now();
		$fields['created_by'] = get_current_user_id();
		if ( ! isset( $fields['created_by_name'] ) ) {
			$fields['created_by_name'] = NBY_Auth::actor_name();
		}
		if ( ! isset( $fields['owner'] ) ) {
			$fields['owner'] = NBY_Auth::actor_key();
		}
		if ( ! isset( $fields['data'] ) ) {
			$fields['data'] = '{}';
		}
		$wpdb->insert( self::t_citizens(), $fields );
		return (int) $wpdb->insert_id;
	}

	public static function set_status( $id, $status, array $extra = array() ) {
		global $wpdb;
		$extra['status']     = $status;
		$extra['updated_at'] = self::now();
		return $wpdb->update( self::t_citizens(), $extra, array( 'id' => $id ) );
	}

	public static function delete( $id ) {
		global $wpdb;
		$row = self::get( $id );
		if ( ! $row ) {
			return;
		}
		NBY_Storage::delete( $row['file_rel'] );
		NBY_Storage::delete( $row['ticket_rel'] );
		NBY_Storage::delete( $row['ticket_pdf_rel'] );
		$rels = $wpdb->get_col( $wpdb->prepare( 'SELECT response_rel FROM ' . self::t_attempts() . " WHERE citizen_id = %d AND response_rel <> ''", $id ) );
		foreach ( $rels as $r ) {
			NBY_Storage::delete( $r );
		}
		$wpdb->delete( self::t_attempts(), array( 'citizen_id' => $id ) );
		$wpdb->delete( self::t_citizens(), array( 'id' => $id ) );
	}

	/**
	 * Atomically claim the next queued applicant of a team (status -> processing).
	 */
	public static function claim_next( $team, $exclude = array() ) {
		global $wpdb;
		$t = self::t_citizens();
		for ( $i = 0; $i < 5; $i++ ) {
			$sql = $wpdb->prepare( "SELECT id FROM $t WHERE status = 'queued' AND team = %s", $team );
			if ( $exclude ) {
				$sql .= ' AND id NOT IN (' . implode( ',', array_map( 'intval', $exclude ) ) . ')';
			}
			$sql .= ' ORDER BY priority DESC, id ASC LIMIT 1';
			$id   = (int) $wpdb->get_var( $sql );
			if ( ! $id ) {
				return null;
			}
			$ok = $wpdb->query( $wpdb->prepare( "UPDATE $t SET status = 'processing', updated_at = %s WHERE id = %d AND status = 'queued'", self::now(), $id ) );
			if ( $ok ) {
				return self::get( $id );
			}
		}
		return null;
	}

	public static function claim( $id, array $from = array( 'queued', 'needs_fix', 'on_hold', 'draft' ) ) {
		global $wpdb;
		$t   = self::t_citizens();
		$in  = "'" . implode( "','", array_map( 'esc_sql', $from ) ) . "'";
		$ok  = $wpdb->query( $wpdb->prepare( "UPDATE $t SET status = 'processing', updated_at = %s WHERE id = %d AND status IN ($in)", self::now(), $id ) );
		return $ok ? self::get( $id ) : null;
	}

	/** Applicants stuck in "processing" (crash mid-request) become "uncertain". */
	public static function recover_stale( $minutes = 15 ) {
		global $wpdb;
		$t   = self::t_citizens();
		$cut = gmdate( 'Y-m-d H:i:s', time() - $minutes * 60 );
		return $wpdb->query( $wpdb->prepare( "UPDATE $t SET status = 'uncertain', last_result = 'uncertain', last_message = %s WHERE status = 'processing' AND updated_at < %s", 'ارسال نیمه‌کاره ماند (قطع اجرای سرور). قبل از ارسال دوباره، وجود نوبت بررسی شود.', $cut ) );
	}

	public static function next_uncertain() {
		global $wpdb;
		$t   = self::t_citizens();
		$cut = gmdate( 'Y-m-d H:i:s', time() - 30 * 60 );
		$id  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE status = 'uncertain' AND (verified_at IS NULL OR verified_at < %s) ORDER BY id ASC LIMIT 1", $cut ) );
		return $id ? self::get( $id ) : null;
	}

	/** @param string|null $owner  limit to one owner ('p:ID'); null = everyone */
	public static function counts( $owner = null ) {
		global $wpdb;
		$t    = self::t_citizens();
		$rows = null === $owner
			? $wpdb->get_results( "SELECT status, team, COUNT(*) n FROM $t GROUP BY status, team", ARRAY_A )
			: $wpdb->get_results( $wpdb->prepare( "SELECT status, team, COUNT(*) n FROM $t WHERE owner = %s GROUP BY status, team", $owner ), ARRAY_A );
		$out  = array( 'by_status' => array(), 'by_team' => array(), 'total' => 0 );
		foreach ( self::statuses() as $k => $l ) {
			$out['by_status'][ $k ] = 0;
		}
		foreach ( $rows as $r ) {
			$out['by_status'][ $r['status'] ] = ( isset( $out['by_status'][ $r['status'] ] ) ? $out['by_status'][ $r['status'] ] : 0 ) + (int) $r['n'];
			if ( ! isset( $out['by_team'][ $r['team'] ] ) ) {
				$out['by_team'][ $r['team'] ] = array();
			}
			$out['by_team'][ $r['team'] ][ $r['status'] ] = (int) $r['n'];
			$out['total'] += (int) $r['n'];
		}
		return $out;
	}

	public static function booked_today( $team ) {
		global $wpdb;
		$t     = self::t_citizens();
		$start = get_gmt_from_date( wp_date( 'Y-m-d 00:00:00' ) );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE status = 'booked' AND team = %s AND booked_at >= %s", $team, $start ) );
	}

	public static function query( array $args ) {
		global $wpdb;
		$t     = self::t_citizens();
		$where = array( '1=1' );
		$vals  = array();
		if ( ! empty( $args['status'] ) ) {
			$where[] = 'status = %s';
			$vals[]  = $args['status'];
		}
		if ( ! empty( $args['team'] ) ) {
			$where[] = 'team = %s';
			$vals[]  = $args['team'];
		}
		if ( isset( $args['owner'] ) && null !== $args['owner'] ) {
			$where[] = 'owner = %s';
			$vals[]  = $args['owner'];
		}
		if ( ! empty( $args['s'] ) ) {
			$like    = '%' . $wpdb->esc_like( $args['s'] ) . '%';
			$where[] = '(full_name LIKE %s OR phone LIKE %s OR ticket_no LIKE %s OR data LIKE %s OR id = %d)';
			array_push( $vals, $like, $like, $like, $like, (int) $args['s'] );
		}
		$w       = implode( ' AND ', $where );
		$per     = isset( $args['per_page'] ) ? (int) $args['per_page'] : 50;
		$page    = max( 1, isset( $args['paged'] ) ? (int) $args['paged'] : 1 );
		$orderby = ( isset( $args['orderby'] ) && 'booked' === $args['orderby'] ) ? 'booked_at DESC, id DESC' : 'priority DESC, id DESC';
		$count   = (int) $wpdb->get_var( $vals ? $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE $w", $vals ) : "SELECT COUNT(*) FROM $t WHERE $w" );
		$sql     = "SELECT id, status, team, priority, full_name, phone, attempts, last_attempt_at, last_result, last_message, ticket_no, ticket_date, ticket_place, ticket_rel, ticket_pdf_rel, booked_at, created_at, created_by_name FROM $t WHERE $w ORDER BY $orderby LIMIT %d OFFSET %d";
		$rows    = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $vals, array( $per, ( $page - 1 ) * $per ) ) ), ARRAY_A );
		return array( 'rows' => $rows, 'total' => $count, 'pages' => max( 1, (int) ceil( $count / $per ) ) );
	}

	/* ---------- attempts ---------- */

	public static function log_attempt( array $a ) {
		global $wpdb;
		$a = array_merge(
			array(
				'citizen_id'   => 0,
				'team'         => '',
				'kind'         => 'submit',
				'result'       => '',
				'http_code'    => 0,
				'message'      => '',
				'duration_ms'  => 0,
				'response_rel' => '',
				'source'       => '',
			),
			$a
		);
		$a['message']    = mb_substr( (string) $a['message'], 0, 2000 );
		$a['created_at'] = self::now();
		$wpdb->insert( self::t_attempts(), $a );
		return (int) $wpdb->insert_id;
	}

	public static function attempts( array $args ) {
		global $wpdb;
		$ta    = self::t_attempts();
		$tc    = self::t_citizens();
		$where = array( '1=1' );
		$vals  = array();
		foreach ( array( 'result', 'team', 'kind' ) as $k ) {
			if ( ! empty( $args[ $k ] ) ) {
				$where[] = "a.$k = %s";
				$vals[]  = $args[ $k ];
			}
		}
		if ( ! empty( $args['citizen_id'] ) ) {
			$where[] = 'a.citizen_id = %d';
			$vals[]  = (int) $args['citizen_id'];
		}
		if ( isset( $args['owner'] ) && null !== $args['owner'] ) {
			$where[] = 'c.owner = %s';
			$vals[]  = $args['owner'];
		}
		$w     = implode( ' AND ', $where );
		$per   = isset( $args['per_page'] ) ? (int) $args['per_page'] : 50;
		$page  = max( 1, isset( $args['paged'] ) ? (int) $args['paged'] : 1 );
		$count = (int) $wpdb->get_var( $vals ? $wpdb->prepare( "SELECT COUNT(*) FROM $ta a LEFT JOIN $tc c ON c.id = a.citizen_id WHERE $w", $vals ) : "SELECT COUNT(*) FROM $ta a LEFT JOIN $tc c ON c.id = a.citizen_id WHERE $w" );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT a.*, c.full_name FROM $ta a LEFT JOIN $tc c ON c.id = a.citizen_id WHERE $w ORDER BY a.id DESC LIMIT %d OFFSET %d", array_merge( $vals, array( $per, ( $page - 1 ) * $per ) ) ), ARRAY_A );
		return array( 'rows' => $rows, 'total' => $count, 'pages' => max( 1, (int) ceil( $count / $per ) ) );
	}

	public static function get_attempt( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t_attempts() . ' WHERE id = %d', $id ), ARRAY_A );
	}

	public static function cleanup( $days ) {
		global $wpdb;
		$ta   = self::t_attempts();
		$cut  = gmdate( 'Y-m-d H:i:s', time() - max( 1, (int) $days ) * DAY_IN_SECONDS );
		$rels = $wpdb->get_col( $wpdb->prepare( "SELECT response_rel FROM $ta WHERE created_at < %s AND response_rel <> '' AND result <> 'success'", $cut ) );
		foreach ( $rels as $r ) {
			NBY_Storage::delete( $r );
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM $ta WHERE created_at < %s AND result <> 'success'", $cut ) );
	}
}
