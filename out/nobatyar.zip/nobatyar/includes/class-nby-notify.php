<?php
defined( 'ABSPATH' ) || exit;

/**
 * Bale (bale.ai) bot / email notifications. Bale's Bot API is Telegram-compatible:
 * https://tapi.bale.ai/bot<token>/METHOD — sendMessage(chat_id, text ≤ 4096), sendDocument(chat_id, document, caption).
 *
 * Messages are queued and delivered on shutdown, after the response has been flushed to the
 * browser — a slow messenger API can never delay a login or a form save.
 * Every message starts with hashtags so the chat can be filtered. Bale renders text as Markdown,
 * but italics need spaces around "_", so in-word underscores in hashtags are safe; we never emit ** or [](…).
 */
class NBY_Notify {

	private static $queue  = array();
	private static $hooked = false;

	/** Event keys → settings label. */
	public static function events() {
		return array(
			'mashhad_open' => 'باز شدن نوبت مشهد/زاهدان',
			'booked'       => 'ثبت موفق نوبت',
			'nsia'         => 'مشکل یا قطعی سامانه NSIA و برقراری دوباره',
			'bot'          => 'روشن/خاموش شدن ربات',
			'login'        => 'ورود اپراتورها و مدیران',
			'logout'       => 'خروج + گزارش کار روزانه هر کاربر',
			'password'     => 'تغییر رمز عبور',
			'delete'       => 'حذف متقاضی',
			'security'     => 'قفل شدن ورود (تلاش‌های ناموفق)',
			'uncertain'    => 'نتیجه نامعلوم ارسال',
		);
	}

	public static function enabled( $event ) {
		$on = NBY_Settings::get( 'notify_events' );
		return ! is_array( $on ) || ! empty( $on[ $event ] );
	}

	private static function tagify( $t ) {
		return '#' . preg_replace( '/[\s\-‌]+/u', '_', trim( $t ) );
	}

	/**
	 * Queue a formatted event message.
	 *
	 * @param string   $event  key from events()
	 * @param string[] $tags   hashtags (without #)
	 * @param string   $title  first line (with emoji)
	 * @param string[] $lines  body lines
	 */
	public static function event( $event, array $tags, $title, array $lines = array(), $doc_html = '', $doc_name = '' ) {
		if ( ! self::enabled( $event ) ) {
			return;
		}
		$text = implode( ' ', array_map( array( __CLASS__, 'tagify' ), $tags ) ) . "\n" . $title;
		if ( $lines ) {
			$text .= "\n" . implode( "\n", $lines );
		}
		$text .= "\n🕒 " . NBY_Jalali::ts( time() ) . "\n— نوبت‌یار";
		self::push( $text, $doc_html, $doc_name );
	}

	/** Same event at most once per $ttl seconds. */
	public static function event_once( $key, $ttl, $event, array $tags, $title, array $lines = array() ) {
		$k = 'nby_n_' . md5( $key );
		if ( get_transient( $k ) ) {
			return;
		}
		set_transient( $k, 1, $ttl );
		self::event( $event, $tags, $title, $lines );
	}

	private static function push( $text, $doc_html = '', $doc_name = '' ) {
		self::$queue[] = array( $text, $doc_html, $doc_name );
		if ( ! self::$hooked ) {
			self::$hooked = true;
			add_action( 'shutdown', array( __CLASS__, 'flush' ), 999 );
		}
	}

	public static function flush() {
		if ( ! self::$queue ) {
			return;
		}
		$s = NBY_Settings::all();
		if ( ! ( $s['bale_token'] && $s['bale_chat'] ) && ! ( $s['notify_email'] && is_email( $s['notify_email'] ) ) ) {
			self::$queue = array();
			return;
		}
		// Let the browser go first.
		if ( ! defined( 'DOING_CRON' ) && ! defined( 'NBY_CRON_CLI' ) && ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			if ( function_exists( 'fastcgi_finish_request' ) ) {
				fastcgi_finish_request();
			} elseif ( function_exists( 'litespeed_finish_request' ) ) {
				litespeed_finish_request();
			}
		}
		ignore_user_abort( true );
		$q           = self::$queue;
		self::$queue = array();
		foreach ( $q as $m ) {
			self::deliver( $m[0], $m[1], $m[2] );
		}
	}

	private static function api_base() {
		$s = NBY_Settings::all();
		return rtrim( $s['bale_api'] ? $s['bale_api'] : 'https://tapi.bale.ai', '/' ) . '/bot' . trim( $s['bale_token'] );
	}

	/** POST to a Bale bot method; one polite retry when Bale answers 429 with a short retry_after. */
	private static function call( $method, array $args ) {
		for ( $i = 0; $i < 2; $i++ ) {
			$r    = wp_remote_post( self::api_base() . '/' . $method, $args );
			$code = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
			if ( 429 !== $code ) {
				return $r;
			}
			$j    = json_decode( wp_remote_retrieve_body( $r ), true );
			$wait = isset( $j['parameters']['retry_after'] ) ? (int) $j['parameters']['retry_after'] : 3;
			if ( $wait > 10 ) {
				return $r;
			}
			sleep( max( 1, $wait ) );
		}
		return $r;
	}

	private static function deliver( $text, $doc_html = '', $doc_name = '' ) {
		$s = NBY_Settings::all();
		if ( $s['bale_token'] && $s['bale_chat'] ) {
			if ( $doc_html ) {
				$b    = '----NbyBale' . wp_generate_password( 16, false, false );
				$body = "--$b\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n" . $s['bale_chat'] . "\r\n";
				$body .= "--$b\r\nContent-Disposition: form-data; name=\"caption\"\r\n\r\n" . mb_substr( $text, 0, 1000 ) . "\r\n";
				$body .= "--$b\r\nContent-Disposition: form-data; name=\"document\"; filename=\"" . ( $doc_name ? $doc_name : 'ticket.html' ) . "\"\r\nContent-Type: text/html\r\n\r\n" . $doc_html . "\r\n--$b--\r\n";
				$r = self::call( 'sendDocument', array( 'timeout' => 20, 'headers' => array( 'Content-Type' => 'multipart/form-data; boundary=' . $b ), 'body' => $body ) );
			} else {
				$r = self::call(
					'sendMessage',
					array(
						'timeout' => 12,
						'body'    => array(
							'chat_id' => $s['bale_chat'],
							'text'    => mb_substr( $text, 0, 4000 ),
						),
					)
				);
			}
			$code = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
			$j    = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
			$ok   = 200 === $code && ( ! is_array( $j ) || ! isset( $j['ok'] ) || $j['ok'] );
			update_option(
				'nby_notify_last',
				array(
					'ok'    => $ok,
					'time'  => time(),
					'error' => $ok ? '' : ( is_wp_error( $r ) ? $r->get_error_message() : 'HTTP ' . $code . ( isset( $j['description'] ) ? ' — ' . $j['description'] : ' ' . mb_substr( wp_remote_retrieve_body( $r ), 0, 200 ) ) ),
				),
				false
			);
		}
		if ( $s['notify_email'] && is_email( $s['notify_email'] ) ) {
			wp_mail( $s['notify_email'], 'نوبت‌یار', $text );
		}
	}

	/**
	 * Chats that recently messaged the bot (or channels/groups it was added to), via getUpdates.
	 * Lets the admin pick the chat_id instead of hunting for it.
	 */
	public static function bale_chats() {
		if ( ! trim( (string) NBY_Settings::get( 'bale_token' ) ) ) {
			return new WP_Error( 'nby_bale', 'اول توکن بازو را وارد و ذخیره کنید.' );
		}
		$r = wp_remote_post( self::api_base() . '/getUpdates', array( 'timeout' => 15, 'body' => array( 'limit' => 100 ) ) );
		if ( is_wp_error( $r ) ) {
			return new WP_Error( 'nby_bale', 'اتصال به بله ناموفق: ' . $r->get_error_message() );
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $j ) || empty( $j['ok'] ) ) {
			return new WP_Error( 'nby_bale', 'بله خطا داد: ' . ( isset( $j['description'] ) ? $j['description'] : 'HTTP ' . wp_remote_retrieve_response_code( $r ) ) . ' (توکن را بررسی کنید)' );
		}
		$chats = array();
		foreach ( (array) $j['result'] as $u ) {
			foreach ( array( 'message', 'channel_post', 'edited_message', 'my_chat_member' ) as $k ) {
				if ( ! empty( $u[ $k ]['chat']['id'] ) ) {
					$c                            = $u[ $k ]['chat'];
					$chats[ (string) $c['id'] ] = array(
						'id'    => (string) $c['id'],
						'title' => isset( $c['title'] ) ? $c['title'] : trim( ( isset( $c['first_name'] ) ? $c['first_name'] : '' ) . ' ' . ( isset( $c['last_name'] ) ? $c['last_name'] : '' ) ),
						'type'  => isset( $c['type'] ) ? $c['type'] : '',
						'user'  => isset( $c['username'] ) ? $c['username'] : '',
					);
				}
			}
		}
		return array_values( $chats );
	}

	/** Synchronous test from settings (shows the real result to the admin). */
	public static function test() {
		self::deliver( "#آزمایش\n✅ اعلان‌های نوبت‌یار درست تنظیم شده‌اند.\n🕒 " . NBY_Jalali::ts( time() ) );
		return get_option( 'nby_notify_last' );
	}
}
