<?php
defined( 'ABSPATH' ) || exit;

/**
 * Applicant field schema = exact mirror of the NSIA appointment form.
 * Keys are the site's own input names (except internal ones prefixed with "_").
 */
class NBY_Fields {

	public static function groups() {
		return array(
			'identity'  => 'مشخصات هویتی',
			'birth'     => 'تولد و شغل',
			'residence' => 'محل سکونت',
			'other'     => 'خانواده و سایر',
			'contact'   => 'اطلاعات تماس',
			'place'     => 'محل ثبت‌نام و مدارک',
		);
	}

	public static function doc_types() {
		return array(
			'team2' => array(
				'passport_family' => 'پاسپورت خانوار (دارای نوبت کفالت)',
			),
			'team3' => array(
				'passport_family'    => 'پاسپورت خانوار (دارای نوبت کفالت)',
				'amayesh'            => 'کارت آمایش',
				'census'             => 'برگه سرشماری',
				'residence_passport' => 'پاسپورت اقامت',
			),
		);
	}

	public static function schema() {
		$s = NBY_Settings::all();
		return array(
			'name'                            => array( 'label' => 'نام', 'group' => 'identity', 'req' => 1 ),
			'surname'                         => array( 'label' => 'تخلص (نام خانوادگی)', 'group' => 'identity', 'req' => 1 ),
			'fathers_name'                    => array( 'label' => 'نام پدر (ولد)', 'group' => 'identity', 'req' => 1 ),
			'grandfathers_name'               => array( 'label' => 'نام پدربزرگ (ولدیت)', 'group' => 'identity', 'req' => 1 ),
			'mothers_name'                    => array( 'label' => 'نام مادر', 'group' => 'identity', 'req' => 1 ),
			'date_of_birth'                   => array( 'label' => 'تاریخ تولد', 'group' => 'birth', 'req' => 1, 'type' => 'date', 'sep' => '/', 'help' => 'شمسی یا میلادی، مثلاً ۱۳۸۱/۰۱/۰۱ — خودکار به میلادی تبدیل می‌شود' ),
			'gender'                          => array( 'label' => 'جنسیت', 'group' => 'birth', 'req' => 1, 'type' => 'select', 'options' => array( 'Male' => 'مرد', 'Female' => 'زن' ) ),
			'occupation'                      => array( 'label' => 'شغل (وظیفه)', 'group' => 'birth', 'req' => 1, 'type' => 'select', 'options' => array( 'self-employed' => 'شغل آزاد', 'skilledworker' => 'کارگر ماهر', 'Unemployed' => 'بیکار' ) ),
			'religion'                        => array( 'label' => 'دین', 'group' => 'birth', 'req' => 1, 'default' => $s['default_religion'] ),
			'country'                         => array( 'label' => 'کشور (محل تولد)', 'group' => 'birth', 'req' => 1, 'default' => $s['default_country'] ),
			'province'                        => array( 'label' => 'ولایت (محل تولد)', 'group' => 'birth', 'req' => 1 ),
			'city'                            => array( 'label' => 'ولسوالی / شهر (محل تولد)', 'group' => 'birth', 'req' => 1 ),
			'duration_of_residence_abroad'    => array( 'label' => 'مدت اقامت در خارج از کشور', 'group' => 'residence', 'req' => 1 ),
			'last_return_date_to_afghanistan' => array( 'label' => 'آخرین تاریخ بازگشت به افغانستان', 'group' => 'residence', 'req' => 1, 'type' => 'date', 'sep' => '-', 'help' => 'شمسی یا میلادی' ),
			'current_residenced'              => array( 'label' => 'محل سکونت فعلی', 'group' => 'residence', 'req' => 1 ),
			'Number_of_children'              => array( 'label' => 'تعداد اعضای خانواده', 'group' => 'other', 'req' => 0, 'type' => 'number' ),
			'Ch_names'                        => array( 'label' => 'نام اعضای خانواده', 'group' => 'other', 'req' => 0, 'type' => 'textarea' ),
			'marital_status'                  => array( 'label' => 'وضعیت تأهل', 'group' => 'other', 'req' => 1, 'type' => 'select', 'options' => array( 'Married' => 'متأهل', 'Unmarried' => 'مجرد' ) ),
			'mother_tongue'                   => array( 'label' => 'زبان مادری', 'group' => 'other', 'req' => 1 ),
			'thumbprint'                      => array( 'label' => 'قوم', 'group' => 'other', 'req' => 1 ),
			'phone_number'                    => array( 'label' => 'شماره تماس', 'group' => 'contact', 'req' => 1, 'type' => 'tel' ),
			'email_address'                   => array( 'label' => 'ایمیل', 'group' => 'contact', 'req' => 0, 'type' => 'email' ),
			'post_address'                    => array( 'label' => 'آدرس پستی', 'group' => 'contact', 'req' => 1 ),
			'team'                            => array( 'label' => 'محل ثبت‌نام', 'group' => 'place', 'req' => 1, 'type' => 'select', 'options' => array( 'team3' => 'مشهد', 'team2' => 'زاهدان' ) ),
			'_doc_type'                       => array( 'label' => 'نوع سند خارجی', 'group' => 'place', 'req' => 1, 'type' => 'doctype' ),
			'foreign_document_number'         => array( 'label' => 'شماره مدرک خارجی', 'group' => 'place', 'req' => 1 ),
		);
	}

	/** Site input names that must exist on the live form (fingerprint). */
	public static function site_required_names() {
		$names = array();
		foreach ( self::schema() as $k => $f ) {
			if ( '_' !== $k[0] ) {
				$names[] = $k;
			}
		}
		$names[] = 'document_tazkira';
		return $names;
	}

	/**
	 * Normalize + validate. Returns array( clean_data, errors[key => msg] ).
	 */
	public static function validate( array $in, $has_file ) {
		$clean  = array();
		$errors = array();
		foreach ( self::schema() as $k => $f ) {
			$type = isset( $f['type'] ) ? $f['type'] : 'text';
			$raw  = isset( $in[ $k ] ) ? $in[ $k ] : '';
			$val  = 'textarea' === $type ? sanitize_textarea_field( wp_unslash( $raw ) ) : sanitize_text_field( wp_unslash( $raw ) );
			$val  = trim( preg_replace( '/[\x{200C}\x{200F}\x{200E}]+$/u', '', $val ) );

			if ( in_array( $type, array( 'number', 'tel', 'date' ), true ) || 'foreign_document_number' === $k || 'post_address' === $k || 'duration_of_residence_abroad' === $k ) {
				$val = NBY_Jalali::digits( $val );
			}

			if ( '' === $val ) {
				if ( ! empty( $f['req'] ) ) {
					$errors[ $k ] = 'پر کردن «' . $f['label'] . '» اجباری است.';
				}
				$clean[ $k ] = '';
				continue;
			}

			switch ( $type ) {
				case 'select':
					if ( ! isset( $f['options'][ $val ] ) ) {
						$errors[ $k ] = 'مقدار «' . $f['label'] . '» نامعتبر است.';
					}
					break;
				case 'date':
					$g = NBY_Jalali::parse( $val );
					if ( ! $g ) {
						$errors[ $k ] = 'تاریخ «' . $f['label'] . '» نامعتبر است.';
					} else {
						if ( $g[0] < 1900 || $g[0] > 2099 ) {
							$errors[ $k ] = 'سال «' . $f['label'] . '» باید بین ۱۹۰۰ تا ۲۰۹۹ میلادی باشد.';
						}
						$val = NBY_Jalali::fmt( $g, $f['sep'] );
					}
					break;
				case 'number':
					if ( ! ctype_digit( $val ) ) {
						$errors[ $k ] = '«' . $f['label'] . '» باید عدد باشد.';
					}
					break;
				case 'tel':
					$val = preg_replace( '/[\s\-()]/', '', $val );
					if ( ! preg_match( '/^\+?\d{7,15}$/', $val ) ) {
						$errors[ $k ] = 'شماره تماس نامعتبر است.';
					}
					break;
				case 'email':
					if ( ! is_email( $val ) ) {
						$errors[ $k ] = 'ایمیل نامعتبر است.';
					}
					break;
			}
			$clean[ $k ] = $val;
		}

		// Birth date must match the site's own client-side regex.
		if ( empty( $errors['date_of_birth'] ) && '' !== $clean['date_of_birth']
			&& ! preg_match( '/^(20\d{2}|19\d{2})\/(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])$/', $clean['date_of_birth'] ) ) {
			$errors['date_of_birth'] = 'فرمت تاریخ تولد با سایت سازگار نیست.';
		}

		$team = $clean['team'];
		$dts  = self::doc_types();
		if ( $team && isset( $dts[ $team ] ) && '' !== $clean['_doc_type'] && ! isset( $dts[ $team ][ $clean['_doc_type'] ] ) ) {
			$errors['_doc_type'] = 'این نوع سند برای ' . NBY_Settings::teams()[ $team ] . ' مجاز نیست.';
		}
		if ( ! $has_file ) {
			$errors['document_tazkira'] = 'ارسال فایل «تذکره» اجباری است.';
		}
		return array( $clean, $errors );
	}

	/**
	 * Build the POST field list in the exact order a browser would send it.
	 * Returns ordered array of [name, value]; the file goes where 'document_tazkira' is.
	 */
	public static function payload( array $d ) {
		$v = function ( $k ) use ( $d ) {
			return isset( $d[ $k ] ) ? (string) $d[ $k ] : '';
		};
		$team  = $v( 'team' );
		$order = array( 'name', 'surname', 'fathers_name', 'grandfathers_name', 'mothers_name', 'date_of_birth', 'gender', 'occupation', 'religion', 'country', 'province', 'city', 'duration_of_residence_abroad', 'last_return_date_to_afghanistan', 'current_residenced', 'Number_of_children', 'Ch_names', 'marital_status', 'mother_tongue', 'thumbprint', 'phone_number', 'email_address', 'post_address', 'team' );
		$out   = array();
		foreach ( $order as $k ) {
			$out[] = array( $k, $v( $k ) );
		}
		for ( $i = 1; $i <= 5; $i++ ) {
			$out[] = array( 'team' . $i . '_detail', ( 'team' . $i === $team ) ? 'foreign' : '' );
		}
		$out[] = array( 'foreign_document_number', $v( 'foreign_document_number' ) );
		$out[] = array( 'document_tazkira', null );
		return $out;
	}

	public static function full_name( array $d ) {
		return trim( ( isset( $d['name'] ) ? $d['name'] : '' ) . ' ' . ( isset( $d['surname'] ) ? $d['surname'] : '' ) );
	}

	public static function label_of( $key, $value ) {
		$s = self::schema();
		if ( '_doc_type' === $key ) {
			foreach ( self::doc_types() as $opts ) {
				if ( isset( $opts[ $value ] ) ) {
					return $opts[ $value ];
				}
			}
			return $value;
		}
		if ( isset( $s[ $key ]['options'][ $value ] ) ) {
			return $s[ $key ]['options'][ $value ];
		}
		return $value;
	}
}
