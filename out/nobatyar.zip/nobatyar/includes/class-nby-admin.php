<?php
defined( 'ABSPATH' ) || exit;

/**
 * wp-admin side:
 *  - «نوبت‌یار»       → the same app as the front-end panel, embedded (WP login, cap nby_manage)
 *  - «کاربران پنل»    → panel accounts (manage_options)
 *  - «تنظیمات»        → bot settings, cron, notifications (manage_options) — never shown in the panel
 */
class NBY_Admin {

	const CAP = 'nby_manage';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_nby_save_settings', array( __CLASS__, 'h_save_settings' ) );
		add_action( 'admin_post_nby_user_save', array( __CLASS__, 'h_user_save' ) );
		add_action( 'admin_post_nby_user_delete', array( __CLASS__, 'h_user_delete' ) );
		add_action( 'wp_ajax_nby_test_notify', array( __CLASS__, 'ajax_test_notify' ) );
		add_action( 'wp_ajax_nby_netcheck', array( __CLASS__, 'ajax_netcheck' ) );
		add_action( 'wp_ajax_nby_bale_chats', array( __CLASS__, 'ajax_bale_chats' ) );
		add_filter( 'admin_body_class', function ( $c ) {
			$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : ''; // phpcs:ignore
			return 0 === strpos( $page, 'nobatyar' ) ? $c . ' nby-admin-page' : $c;
		} );
	}

	public static function menu() {
		$counts = NBY_DB::counts();
		$badge  = $counts['by_status']['queued'] ? ' <span class="awaiting-mod">' . (int) $counts['by_status']['queued'] . '</span>' : '';
		add_menu_page( 'نوبت‌یار', 'نوبت‌یار' . $badge, self::CAP, 'nobatyar', array( __CLASS__, 'page_app' ), 'dashicons-tickets-alt', 26 );
		add_submenu_page( 'nobatyar', 'پنل نوبت‌یار', 'پنل نوبت‌یار', self::CAP, 'nobatyar', array( __CLASS__, 'page_app' ) );
		add_submenu_page( 'nobatyar', 'کاربران پنل', 'کاربران پنل', 'manage_options', 'nobatyar-users', array( __CLASS__, 'page_users' ) );
		add_submenu_page( 'nobatyar', 'تنظیمات نوبت‌یار', 'تنظیمات', 'manage_options', 'nobatyar-settings', array( __CLASS__, 'page_settings' ) );
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'nobatyar' ) ) {
			return;
		}
		wp_enqueue_style( 'nby-app', NBY_URL . 'assets/app.css', array(), NBY_VERSION );
		if ( 'toplevel_page_nobatyar' === $hook ) {
			wp_enqueue_script( 'nby-app', NBY_URL . 'assets/app.js', array(), NBY_VERSION, true );
			wp_add_inline_script( 'nby-app', 'window.NBY_APP = ' . wp_json_encode( NBY_Panel::boot( 'wp' ), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ) . ';', 'before' );
		}
	}

	/* ================================================================== helpers */

	private static function notice( $msg, $type = 'ok' ) {
		set_transient( 'nby_notice_' . get_current_user_id(), array( $msg, $type ), 120 );
	}

	private static function show_notice() {
		$k = 'nby_notice_' . get_current_user_id();
		$n = get_transient( $k );
		if ( $n ) {
			delete_transient( $k );
			echo '<div class="nby-banner is-' . esc_attr( $n[1] ) . '" role="status">' . esc_html( $n[0] ) . '</div>';
		}
	}

	private static function back( $page, array $args = array() ) {
		wp_safe_redirect( add_query_arg( array_merge( array( 'page' => $page ), $args ), admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function open( $title, $sub = '' ) {
		echo '<div class="wrap nby-wp-wrap"><div class="nby-app is-embedded"><div class="nby-page">';
		echo '<header class="nby-page-head"><div><h1 class="nby-h1">' . esc_html( $title ) . '</h1>';
		if ( $sub ) {
			echo '<p class="nby-lead">' . esc_html( $sub ) . '</p>';
		}
		echo '</div><a class="nby-btn is-ghost" href="' . esc_url( NBY_Panel::url() ) . '" target="_blank" rel="noopener">باز کردن پنل در سایت ↗</a></header>';
		self::show_notice();
	}

	private static function close() {
		echo '</div></div></div>';
	}

	/* ================================================================== app */

	public static function page_app() {
		echo '<div class="wrap nby-wp-wrap"><div class="nby-app is-embedded"><div id="nby-root"><div class="nby-boot"><span class="nby-boot-mark"></span></div></div></div></div>';
	}

	/* ================================================================== panel users */

	public static function page_users() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		$users = NBY_Auth::list_users();
		$roles = NBY_Auth::roles();
		self::open( 'کاربران پنل', 'حساب‌هایی که با آن‌ها در آدرس ' . NBY_Panel::url() . ' وارد پنل می‌شوند. این حساب‌ها به پیشخوان وردپرس دسترسی ندارند.' );

		echo '<div class="nby-split">';
		echo '<section class="nby-card"><h2 class="nby-h2">حساب‌ها</h2>';
		if ( ! $users ) {
			echo '<div class="nby-empty"><b>هنوز حسابی ساخته نشده.</b><span>از فرم کنار، اولین حساب را بسازید.</span></div>';
		} else {
			echo '<div class="nby-userlist">';
			foreach ( $users as $u ) {
				$initial = mb_substr( $u['display_name'] ? $u['display_name'] : $u['username'], 0, 1 );
				echo '<details class="nby-user' . ( $u['active'] ? '' : ' is-off' ) . '"><summary>';
				echo '<span class="nby-avatar" aria-hidden="true">' . esc_html( $initial ) . '</span>';
				echo '<span class="nby-user-main"><b>' . esc_html( $u['display_name'] ) . '</b><small dir="ltr">' . esc_html( $u['username'] ) . '</small></span>';
				echo '<span class="nby-tag is-' . ( 'manager' === $u['role'] ? 'accent' : 'muted' ) . '">' . esc_html( $roles[ $u['role'] ] ) . '</span>';
				echo $u['active'] ? '' : '<span class="nby-tag is-bad">غیرفعال</span>';
				echo '<span class="nby-user-meta">آخرین ورود: ' . esc_html( $u['last_login'] ? NBY_Jalali::dt( $u['last_login'] ) : 'هرگز' ) . '</span>';
				echo '</summary><form class="nby-form-grid" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
				wp_nonce_field( 'nby_user_save' );
				echo '<input type="hidden" name="action" value="nby_user_save"><input type="hidden" name="id" value="' . (int) $u['id'] . '">';
				self::field( 'display_name', 'نام نمایشی', $u['display_name'] );
				self::select( 'role', 'نقش', $roles, $u['role'] );
				self::field( 'password', 'رمز جدید (خالی = بدون تغییر)', '', 'password', 'new-password' );
				echo '<label class="nby-check"><input type="checkbox" name="active" value="1"' . checked( (int) $u['active'], 1, false ) . '><span>حساب فعال است</span></label>';
				echo '<div class="nby-row-actions"><button class="nby-btn is-primary">ذخیره</button>';
				echo '<a class="nby-btn is-danger-ghost" data-confirm="حساب «' . esc_attr( $u['username'] ) . '» حذف شود؟" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=nby_user_delete&id=' . (int) $u['id'] ), 'nby_user_delete' ) ) . '">حذف حساب</a></div>';
				echo '</form></details>';
			}
			echo '</div>';
		}
		echo '</section>';

		echo '<section class="nby-card"><h2 class="nby-h2">ساخت حساب جدید</h2><form class="nby-form-grid is-one" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'nby_user_save' );
		echo '<input type="hidden" name="action" value="nby_user_save"><input type="hidden" name="id" value="0">';
		self::field( 'username', 'نام کاربری (انگلیسی)', '', 'text', 'off', 'ltr' );
		self::field( 'display_name', 'نام نمایشی', '' );
		self::field( 'password', 'رمز عبور (حداقل ' . NBY_Auth::MIN_PASS . ' کاراکتر)', '', 'password', 'new-password' );
		self::select( 'role', 'نقش', $roles, 'operator' );
		echo '<ul class="nby-mini-list"><li><b>مدیر:</b> همه بخش‌ها + روشن/خاموش کردن ربات + حذف متقاضی.</li><li><b>اپراتور:</b> افزودن، ویرایش، تلاش فوری و ورود گروهی؛ بدون حذف و بدون خاموش/روشن کردن ربات.</li></ul>';
		echo '<button class="nby-btn is-primary">ساخت حساب</button></form></section>';
		echo '</div>';
		self::close();
	}

	private static function field( $name, $label, $val, $type = 'text', $ac = '', $dir = '' ) {
		echo '<label class="nby-field"><span class="nby-label">' . esc_html( $label ) . '</span><input class="nby-input" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '"' . ( $ac ? ' autocomplete="' . esc_attr( $ac ) . '"' : '' ) . ( $dir ? ' dir="' . esc_attr( $dir ) . '"' : '' ) . '></label>';
	}

	private static function select( $name, $label, array $opts, $val ) {
		echo '<label class="nby-field"><span class="nby-label">' . esc_html( $label ) . '</span><select class="nby-input" name="' . esc_attr( $name ) . '">';
		foreach ( $opts as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $val, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></label>';
	}

	public static function h_user_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی ندارید.', 403 );
		}
		check_admin_referer( 'nby_user_save' );
		$id   = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$pass = isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : ''; // phpcs:ignore -- raw password, hashed
		$disp = isset( $_POST['display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['display_name'] ) ) : '';
		$role = isset( $_POST['role'] ) ? sanitize_key( $_POST['role'] ) : 'operator';
		if ( $id ) {
			$r = NBY_Auth::update_user(
				$id,
				array(
					'display_name' => $disp,
					'role'         => $role,
					'active'       => ! empty( $_POST['active'] ),
					'password'     => $pass,
				)
			);
			self::notice( is_wp_error( $r ) ? $r->get_error_message() : 'حساب به‌روز شد.' . ( '' !== $pass ? ' (همه نشست‌های قبلی این حساب بسته شد)' : '' ), is_wp_error( $r ) ? 'bad' : 'ok' );
		} else {
			$user = isset( $_POST['username'] ) ? sanitize_user( wp_unslash( $_POST['username'] ), true ) : '';
			$r    = NBY_Auth::create_user( $user, $pass, $disp, $role );
			self::notice( is_wp_error( $r ) ? $r->get_error_message() : 'حساب «' . $user . '» ساخته شد. ورود از آدرس ' . NBY_Panel::url(), is_wp_error( $r ) ? 'bad' : 'ok' );
		}
		self::back( 'nobatyar-users' );
	}

	public static function h_user_delete() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی ندارید.', 403 );
		}
		check_admin_referer( 'nby_user_delete' );
		NBY_Auth::delete_user( isset( $_GET['id'] ) ? (int) $_GET['id'] : 0 );
		self::notice( 'حساب حذف شد.' );
		self::back( 'nobatyar-users' );
	}

	/* ================================================================== settings */

	public static function page_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		$s = NBY_Settings::all();
		self::open( 'تنظیمات نوبت‌یار', 'این بخش فقط برای مدیر وردپرس است و در پنل کاربران نمایش داده نمی‌شود.' );
		echo '<form class="nby-settings" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'nby_save_settings' );
		echo '<input type="hidden" name="action" value="nby_save_settings">';

		echo '<section class="nby-card"><h2 class="nby-h2">تست شبکه سرور</h2><p class="nby-prose">ربات از روی <b>سرور هاست</b> به NSIA وصل می‌شود، نه از مرورگر شما. اگر خطای «مهلت اتصال تمام شد» می‌بینید، این تست از خود سرور بررسی می‌کند مشکل از DNS، دسترسی بین‌الملل هاست یا مسیر به NSIA است (حدود یک دقیقه).</p>';
		echo '<div class="nby-inline"><button type="button" class="nby-btn is-primary" id="nby-netcheck" data-nonce="' . esc_attr( wp_create_nonce( 'nby_netcheck' ) ) . '">اجرای تست شبکه</button><span class="nby-hint" id="nby-netcheck-busy"></span></div><div id="nby-netcheck-out"></div></section>';
		echo '<section class="nby-card"><h2 class="nby-h2">حالت کار</h2>';
		self::sw( 'dry_run', 'حالت آزمایشی', 'فرم سایت را باز و بررسی می‌کند ولی چیزی ارسال نمی‌کند. برای ثبت واقعی خاموش کنید.', $s['dry_run'] );
		echo '</section>';

		echo '<section class="nby-card"><h2 class="nby-h2">پنل کاربران</h2><div class="nby-form-grid">';
		self::sfield( 'panel_slug', 'آدرس پنل', $s['panel_slug'], 'ltr', home_url( '/' ) . '…' );
		echo '</div><p class="nby-hint">آدرس فعلی: <a href="' . esc_url( NBY_Panel::url() ) . '" target="_blank" rel="noopener" dir="ltr">' . esc_html( NBY_Panel::url() ) . '</a> — حساب‌ها را از «کاربران پنل» بسازید.</p></section>';

		echo '<section class="nby-card"><h2 class="nby-h2">زمان‌بندی تلاش‌ها</h2>';
		foreach ( NBY_Settings::teams() as $t => $l ) {
			echo '<h3 class="nby-h3">' . esc_html( $l ) . '</h3>';
			self::sw( $t . '_enabled', 'پایش ' . $l . ' فعال است', '', $s[ $t . '_enabled' ] );
			echo '<div class="nby-form-grid">';
			self::snum( $t . '_interval', 'فاصله تلاش وقتی بسته است (ثانیه، حداقل ۲۰)', $s[ $t . '_interval' ], 20 );
			self::snum( $t . '_burst', 'ثبت پشت‌سرهم در هر دور وقتی باز است', $s[ $t . '_burst' ], 1 );
			self::snum( $t . '_open_gap', 'مکث بین دورها وقتی باز است (ثانیه)', $s[ $t . '_open_gap' ], 0 );
			echo '</div>';
		}
		echo '<h3 class="nby-h3">اجرا</h3><div class="nby-form-grid">';
		self::snum( 'tick_budget', 'حداکثر مدت هر اجرای ربات (ثانیه)', $s['tick_budget'], 10 );
		self::snum( 'timeout_get', 'مهلت باز شدن فرم (ثانیه)', $s['timeout_get'], 5 );
		self::snum( 'timeout_post', 'مهلت پاسخ به ارسال فرم (ثانیه)', $s['timeout_post'], 10 );
		self::snum( 'connect_timeout', 'مهلت برقراری اتصال به NSIA (ثانیه، ۵ تا ۶۰)', $s['connect_timeout'], 5 );
		echo '</div></section>';

		echo '<section class="nby-card"><h2 class="nby-h2">تشخیص پاسخ سایت</h2><div class="nby-form-grid">';
		self::sarea( 'closed_keywords', 'عبارت‌های «بسته / پر» (هر خط یکی)', $s['closed_keywords'] );
		self::sarea( 'success_keywords', 'عبارت‌های «ثبت موفق» (هر خط یکی)', $s['success_keywords'] );
		echo '</div><p class="nby-hint">پیام فعلی سایت هنگام پر بودن «تاریخ پر است به مشهد» است و با «پر است» تشخیص داده می‌شود. اگر سایت پیام تازه‌ای نشان دهد، ربات آن محل را متوقف می‌کند تا عبارت را اینجا اضافه کنید.</p></section>';

		echo '<section class="nby-card"><h2 class="nby-h2">اعلان‌ها</h2><div class="nby-form-grid">';
		self::sfield( 'bale_token', 'توکن بازوی بله (از @botfather در بله)', $s['bale_token'], 'ltr' );
		self::sfield( 'bale_chat', 'شناسه گفتگو، گروه یا کانال (یا @نام‌کانال)', $s['bale_chat'], 'ltr' );
		self::sfield( 'bale_api', 'آدرس API بله', $s['bale_api'], 'ltr' );
		echo '<div class="nby-field is-wide"><span class="nby-label">شناسه گفتگو را نمی‌دانید؟</span><p class="nby-hint">توکن را ذخیره کنید، بعد از حساب بله خودتان یک پیام به بازو بفرستید (یا بازو را به گروه/کانال اضافه کنید و یک پیام بگذارید) و این دکمه را بزنید.</p><div class="nby-inline" style="margin-top:6px"><button type="button" class="nby-btn is-ghost" id="nby-bale-chats" data-nonce="' . esc_attr( wp_create_nonce( 'nby_bale_chats' ) ) . '">پیدا کردن شناسه گفتگو</button><span class="nby-hint" id="nby-bale-out"></span></div><div id="nby-bale-list"></div></div>';
		self::sfield( 'notify_email', 'ایمیل اعلان', $s['notify_email'], 'ltr' );
		echo '</div><h3 class="nby-h3">کدام رویدادها اعلان شوند؟</h3><div class="nby-form-grid">';
		$on = is_array( $s['notify_events'] ) ? $s['notify_events'] : array();
		foreach ( NBY_Notify::events() as $ek => $el ) {
			echo '<label class="nby-check"><input type="checkbox" name="s[notify_events][' . esc_attr( $ek ) . ']" value="1"' . checked( ! empty( $on[ $ek ] ), true, false ) . '><span>' . esc_html( $el ) . '</span></label>';
		}
		$last = get_option( 'nby_notify_last' );
		if ( $last ) {
			echo '</div><p class="nby-hint" style="margin-top:12px">آخرین ارسال به بله: ' . esc_html( NBY_Jalali::ts( (int) $last['time'] ) ) . ' — ' . ( $last['ok'] ? '<b style="color:var(--ok)">موفق</b>' : '<b style="color:var(--bad)">ناموفق</b> (' . esc_html( $last['error'] ) . ')' ) . '</p><div>';
		}
		echo '</div><div class="nby-inline"><button type="button" class="nby-btn is-ghost" id="nby-test-notify" data-nonce="' . esc_attr( wp_create_nonce( 'nby_test_notify' ) ) . '">ارسال پیام آزمایشی</button><span class="nby-hint" id="nby-test-out"></span></div></section>';

		echo '<section class="nby-card"><h2 class="nby-h2">اتصال، فایل‌ها و نگهداری</h2><div class="nby-form-grid">';
		self::sfield( 'base_url', 'آدرس سامانه NSIA', $s['base_url'], 'ltr' );
		self::sfield( 'user_agent', 'شناسه کلاینت (User-Agent)', $s['user_agent'], 'ltr' );
		self::snum( 'max_file_mb', 'حداکثر حجم فایل تذکره (مگابایت)', $s['max_file_mb'], 1 );
		self::snum( 'retention_days', 'نگهداری گزارش‌ها (روز)', $s['retention_days'], 1 );
		self::sfield( 'default_religion', 'پیش‌فرض «دین»', $s['default_religion'] );
		self::sfield( 'default_country', 'پیش‌فرض «کشور محل تولد»', $s['default_country'] );
		echo '</div>';
		self::sw( 'regen_key', 'ساخت کلید جدید برای آدرس کرون', 'بعد از ذخیره، دستور کرون سرور را با آدرس جدید به‌روز کنید.', 0 );
		self::sw( 'delete_on_uninstall', 'پاک شدن همه داده‌ها هنگام حذف افزونه', 'متقاضیان، فایل‌ها، گزارش‌ها و حساب‌های پنل.', $s['delete_on_uninstall'] );
		echo '</section>';

		echo '<div class="nby-savebar"><button class="nby-btn is-primary is-lg">ذخیره تنظیمات</button></div></form>';
		self::cron_box();
		echo '<script>(function(){var b=document.getElementById("nby-test-notify");if(!b)return;b.addEventListener("click",function(){var o=document.getElementById("nby-test-out");o.textContent="در حال ارسال…";var f=new FormData();f.append("action","nby_test_notify");f.append("nonce",b.dataset.nonce);fetch(ajaxurl,{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json()}).then(function(j){o.textContent=j&&j.data?j.data.message:"خطا"}).catch(function(){o.textContent="خطا در ارتباط"})});var bc=document.getElementById("nby-bale-chats");if(bc){bc.addEventListener("click",function(){var o=document.getElementById("nby-bale-out"),l=document.getElementById("nby-bale-list");o.textContent="در حال دریافت…";l.innerHTML="";var f=new FormData();f.append("action","nby_bale_chats");f.append("nonce",bc.dataset.nonce);fetch(ajaxurl,{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json()}).then(function(j){var d=j&&j.data||{};o.textContent=d.message||"خطا";(d.chats||[]).forEach(function(c){var b=document.createElement("button");b.type="button";b.className="nby-btn is-sm";b.style.margin="6px 0 0 6px";b.textContent=(c.title||c.user||"گفتگو")+" — "+c.id+(c.type?" ("+c.type+")":"");b.onclick=function(){var i=document.querySelector("[name=\"s[bale_chat]\"]");if(i){i.value=c.id;i.focus()}};l.appendChild(b)})}).catch(function(){o.textContent="ارتباط با سرور وردپرس قطع شد."})})}var n=document.getElementById("nby-netcheck");if(n){n.addEventListener("click",function(){var o=document.getElementById("nby-netcheck-out"),w=document.getElementById("nby-netcheck-busy");n.disabled=true;w.textContent="در حال تست از روی سرور… (تا یک دقیقه)";o.innerHTML="";var f=new FormData();f.append("action","nby_netcheck");f.append("nonce",n.dataset.nonce);fetch(ajaxurl,{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json()}).then(function(j){var d=j&&j.data;if(!d||!d.steps){o.textContent="خطا";return}var e=function(s){var x=document.createElement("span");x.textContent=s;return x.innerHTML};o.innerHTML="<ul class=\"nby-kv\" style=\"margin:14px 0\">"+d.steps.map(function(s){return "<li><span>"+(s.ok?"✅ ":"❌ ")+e(s.name)+"<br><small class=\"nby-hint\" dir=\"auto\">"+e(s.info)+"</small></span><b dir=\"ltr\">"+s.ms+" ms</b></li>"}).join("")+"</ul><div class=\"nby-banner "+(d.ok?"is-ok":"is-warn")+"\">"+e(d.verdict)+"</div>"+(d.server_ip?"<p class=\"nby-hint\">IP سرور: <b dir=\"ltr\">"+e(d.server_ip)+"</b></p>":"")}).catch(function(){o.textContent="ارتباط با سرور وردپرس قطع شد."}).then(function(){n.disabled=false;w.textContent=""})})}document.querySelectorAll("[data-confirm]").forEach(function(a){a.addEventListener("click",function(e){if(!confirm(a.dataset.confirm))e.preventDefault()})});})();</script>';
		self::close();
	}

	private static function sw( $k, $label, $hint, $val ) {
		echo '<label class="nby-switch"><input type="checkbox" name="s[' . esc_attr( $k ) . ']" value="1"' . checked( ! empty( $val ), true, false ) . '><span class="nby-switch-ui" aria-hidden="true"></span><span class="nby-switch-text"><b>' . esc_html( $label ) . '</b>' . ( $hint ? '<small>' . esc_html( $hint ) . '</small>' : '' ) . '</span></label>';
	}

	private static function snum( $k, $label, $val, $min ) {
		echo '<label class="nby-field"><span class="nby-label">' . esc_html( $label ) . '</span><input class="nby-input is-num" type="number" min="' . (int) $min . '" name="s[' . esc_attr( $k ) . ']" value="' . esc_attr( $val ) . '" dir="ltr"></label>';
	}

	private static function sfield( $k, $label, $val, $dir = '', $ph = '' ) {
		echo '<label class="nby-field"><span class="nby-label">' . esc_html( $label ) . '</span><input class="nby-input" type="text" name="s[' . esc_attr( $k ) . ']" value="' . esc_attr( $val ) . '"' . ( $dir ? ' dir="' . esc_attr( $dir ) . '"' : '' ) . ( $ph ? ' placeholder="' . esc_attr( $ph ) . '"' : '' ) . '></label>';
	}

	private static function sarea( $k, $label, $val ) {
		echo '<label class="nby-field is-wide"><span class="nby-label">' . esc_html( $label ) . '</span><textarea class="nby-input" rows="6" name="s[' . esc_attr( $k ) . ']">' . esc_textarea( $val ) . '</textarea></label>';
	}

	public static function h_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی ندارید.', 403 );
		}
		check_admin_referer( 'nby_save_settings' );
		$in    = isset( $_POST['s'] ) && is_array( $_POST['s'] ) ? wp_unslash( $_POST['s'] ) : array(); // phpcs:ignore -- sanitized per key below
		$def   = NBY_Settings::defaults();
		$bools = array( 'dry_run', 'team2_enabled', 'team3_enabled', 'delete_on_uninstall' );
		$out   = array();
		foreach ( $def as $k => $d ) {
			if ( 'cron_key' === $k ) {
				continue;
			}
			if ( in_array( $k, $bools, true ) ) {
				$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
			} elseif ( is_int( $d ) ) {
				$out[ $k ] = isset( $in[ $k ] ) ? max( 0, (int) $in[ $k ] ) : $d;
			} elseif ( in_array( $k, array( 'closed_keywords', 'success_keywords' ), true ) ) {
				$out[ $k ] = isset( $in[ $k ] ) ? sanitize_textarea_field( $in[ $k ] ) : $d;
			} elseif ( in_array( $k, array( 'base_url', 'bale_api' ), true ) ) {
				$out[ $k ] = isset( $in[ $k ] ) && '' !== trim( $in[ $k ] ) ? esc_url_raw( trim( $in[ $k ] ) ) : $d;
			} elseif ( 'notify_events' === $k ) {
				$out[ $k ] = array();
				foreach ( array_keys( NBY_Notify::events() ) as $ek ) {
					$out[ $k ][ $ek ] = empty( $in['notify_events'][ $ek ] ) ? 0 : 1;
				}
			} elseif ( 'panel_slug' === $k ) {
				$slug      = isset( $in[ $k ] ) ? sanitize_title( $in[ $k ] ) : '';
				$out[ $k ] = $slug ? $slug : $d;
			} else {
				$out[ $k ] = isset( $in[ $k ] ) ? sanitize_text_field( $in[ $k ] ) : $d;
			}
		}
		foreach ( array_keys( NBY_Settings::teams() ) as $t ) {
			$out[ $t . '_interval' ] = max( 20, $out[ $t . '_interval' ] );
			$out[ $t . '_burst' ]    = max( 1, $out[ $t . '_burst' ] );
		}
		if ( ! empty( $in['regen_key'] ) ) {
			$out['cron_key'] = wp_generate_password( 32, false, false );
		}
		if ( $out['panel_slug'] !== NBY_Settings::get( 'panel_slug' ) ) {
			update_option( 'nby_flush_rewrite', 1, false );
		}
		NBY_Settings::update( $out );
		self::notice( 'تنظیمات ذخیره شد.' . ( ! empty( $in['regen_key'] ) ? ' کلید کرون عوض شد؛ دستور کرون سرور را به‌روز کنید.' : '' ) );
		self::back( 'nobatyar-settings' );
	}

	public static function cron_box() {
		$url = NBY_Runner::cron_url();
		echo '<section class="nby-card nby-cron"><h2 class="nby-h2">کرون سرور</h2>';
		echo '<p class="nby-prose">در کنترل‌پنل هاست (DirectAdmin یا cPanel ← Cron Jobs) یک کرون بسازید، همه خانه‌های زمان‌بندی را <code>*</code> بگذارید و <b>فقط یکی</b> از این دستورها را در خانه «دستور» قرار دهید:</p>';
		echo '<ol class="nby-cron-list">';
		echo '<li><b>اجرای مستقیم با PHP (پیشنهادی)</b><pre class="nby-code" dir="ltr">/usr/local/bin/php ' . esc_html( NBY_DIR . 'cron.php' ) . ' &gt;/dev/null 2&gt;&amp;1</pre></li>';
		echo '<li><b>فراخوانی آدرس با curl</b><pre class="nby-code" dir="ltr">/usr/local/bin/curl --silent -L "' . esc_html( $url ) . '" &gt;/dev/null 2&gt;&amp;1</pre></li>';
		echo '<li><b>با wget</b><pre class="nby-code" dir="ltr">/usr/bin/wget -q -O /dev/null "' . esc_html( $url ) . '" &gt;/dev/null 2&gt;&amp;1</pre></li>';
		echo '</ol><p class="nby-hint">در cPanel اگر <code>/usr/local/bin/php</code> کار نکرد، <code>php</code> یا <code>/usr/bin/php</code> را امتحان کنید. آدرس curl کلید مخفی دارد؛ آن را منتشر نکنید.</p></section>';
	}

	public static function ajax_bale_chats() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'nby_bale_chats', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی ندارید.' ), 403 );
		}
		$r = NBY_Notify::bale_chats();
		if ( is_wp_error( $r ) ) {
			wp_send_json_error( array( 'message' => $r->get_error_message() ) );
		}
		wp_send_json_success( array( 'chats' => $r, 'message' => $r ? 'روی شناسه مورد نظر بزنید تا در فیلد قرار بگیرد، بعد «ذخیره تنظیمات».' : 'پیامی پیدا نشد. اول از بله یک پیام به بازو بفرستید و دوباره امتحان کنید.' ) );
	}

	public static function ajax_netcheck() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'nby_netcheck', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی ندارید.' ), 403 );
		}
		$r       = NBY_Runner::netcheck();
		$r['ok'] = 0 === strpos( $r['verdict'], '✅' );
		wp_send_json_success( $r );
	}

	public static function ajax_test_notify() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'nby_test_notify', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی ندارید.' ), 403 );
		}
		$r = NBY_Notify::test();
		if ( ! NBY_Settings::get( 'bale_token' ) || ! NBY_Settings::get( 'bale_chat' ) ) {
			wp_send_json_success( array( 'message' => 'توکن یا شناسه گفتگوی بله ذخیره نشده است. (اگر ایمیل تنظیم شده، به ایمیل فرستاده شد.)' ) );
		}
		wp_send_json_success( array( 'message' => $r && $r['ok'] ? '✅ پیام در بله رسید.' : '❌ ارسال به بله ناموفق بود: ' . ( $r ? $r['error'] : '' ) . ' — توکن و شناسه گفتگو را بررسی کنید؛ بازو باید در گروه/کانال عضو (و در کانال مدیر) باشد.' ) );
	}
}
