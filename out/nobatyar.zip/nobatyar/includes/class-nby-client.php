<?php
defined( 'ABSPATH' ) || exit;

/**
 * HTTP client for ivsf.nsia.gov.af — no browser needed (plain Laravel form, CSRF token + session cookie).
 * One instance = one site session.
 */
class NBY_Client {

	private $base;
	private $ua;
	private $cookies = array();
	private $asset_budget = 30;

	private static $curl_hooked = false;

	public function __construct() {
		$this->base = rtrim( (string) NBY_Settings::get( 'base_url' ), '/' );
		$this->ua   = (string) NBY_Settings::get( 'user_agent' );
		self::hook_curl();
	}

	/**
	 * WordPress/Requests uses a fixed 10 s connect timeout; NSIA (Afghanistan) is often slow to accept
	 * connections from Iranian datacenters, so allow a longer TCP connect for NSIA requests only.
	 */
	public static function hook_curl() {
		if ( self::$curl_hooked ) {
			return;
		}
		self::$curl_hooked = true;
		add_action(
			'http_api_curl',
			function ( $handle, $args, $url ) {
				$host = wp_parse_url( (string) NBY_Settings::get( 'base_url' ), PHP_URL_HOST );
				if ( $host && wp_parse_url( $url, PHP_URL_HOST ) === $host && defined( 'CURLOPT_CONNECTTIMEOUT' ) ) {
					curl_setopt( $handle, CURLOPT_CONNECTTIMEOUT, max( 5, min( 60, (int) NBY_Settings::get( 'connect_timeout' ) ) ) );
				}
			},
			10,
			3
		);
	}

	/** Turn raw cURL errors into something an operator understands. */
	public static function explain( $msg ) {
		$m = (string) $msg;
		if ( preg_match( '/cURL error 28: (Connection|Resolving) timed out/i', $m ) || preg_match( '/Connection timed out after|with 0 (out of \d+ )?bytes received/i', $m ) ) {
			return 'سرور هاست نتوانست به سرور NSIA وصل شود (مهلت اتصال تمام شد). یا مسیر شبکه هاست به NSIA بسته است، یا NSIA این سرور را نمی‌پذیرد. «تست شبکه سرور» را در تنظیمات اجرا کنید. [' . $m . ']';
		}
		if ( preg_match( '/cURL error 28/i', $m ) ) {
			return 'سرور NSIA در زمان مقرر جواب نداد (کند یا شلوغ است). [' . $m . ']';
		}
		if ( preg_match( '/cURL error 6|Could not resolve/i', $m ) ) {
			return 'سرور هاست نتوانست آدرس NSIA را پیدا کند (مشکل DNS هاست). [' . $m . ']';
		}
		if ( preg_match( '/cURL error 7|Connection refused|Failed to connect/i', $m ) ) {
			return 'اتصال سرور هاست به NSIA رد شد (فایروال هاست یا NSIA). [' . $m . ']';
		}
		return $m;
	}

	public function url( $path ) {
		return $this->base . '/' . ltrim( $path, '/' );
	}

	/* ------------------------------------------------------------------ transport */

	private function cookie_header() {
		$p = array();
		foreach ( $this->cookies as $k => $v ) {
			$p[] = $k . '=' . $v;
		}
		return implode( '; ', $p );
	}

	private function absorb( $resp ) {
		$set = wp_remote_retrieve_header( $resp, 'set-cookie' );
		foreach ( (array) $set as $h ) {
			if ( preg_match( '/^\s*([^=;\s]+)=([^;]*)/', (string) $h, $m ) ) {
				$this->cookies[ $m[1] ] = $m[2];
			}
		}
	}

	public function resolve( $from, $rel ) {
		$rel = trim( html_entity_decode( (string) $rel, ENT_QUOTES ) );
		$rel = str_replace( ' ', '%20', $rel );
		if ( preg_match( '#^https?://#i', $rel ) ) {
			return $rel;
		}
		$p      = wp_parse_url( $from );
		$scheme = isset( $p['scheme'] ) ? $p['scheme'] : 'http';
		if ( 0 === strpos( $rel, '//' ) ) {
			return $scheme . ':' . $rel;
		}
		$origin = $scheme . '://' . $p['host'] . ( isset( $p['port'] ) ? ':' . $p['port'] : '' );
		if ( 0 === strpos( $rel, '/' ) ) {
			return $origin . $rel;
		}
		$path = isset( $p['path'] ) ? $p['path'] : '/';
		$dir  = substr( $path, 0, strrpos( $path, '/' ) + 1 );
		return $origin . $dir . $rel;
	}

	/**
	 * Request with manual redirect handling (keeps cookies across hops, records final URL).
	 */
	public function request( $method, $url, $body = null, array $headers = array(), $timeout = 30 ) {
		$t0      = microtime( true );
		$hops    = 0;
		$orig    = $method;
		while ( true ) {
			$h = array_merge(
				array(
					'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
					'Accept-Language' => 'fa,en;q=0.8',
				),
				$headers
			);
			if ( $this->cookies ) {
				$h['Cookie'] = $this->cookie_header();
			}
			$args = array(
				'method'              => $method,
				'timeout'             => $timeout,
				'redirection'         => 0,
				'headers'             => $h,
				'user-agent'          => $this->ua,
				'limit_response_size' => 6 * MB_IN_BYTES,
			);
			if ( null !== $body ) {
				$args['body'] = $body;
			}
			$resp = wp_remote_request( $url, $args );
			$ms   = (int) round( ( microtime( true ) - $t0 ) * 1000 );
			if ( is_wp_error( $resp ) ) {
				return array(
					'ok'     => false,
					'error'  => $resp->get_error_message(),
					'code'   => 0,
					'body'   => '',
					'url'    => $url,
					'method' => $orig,
					'hops'   => $hops,
					'ms'     => $ms,
				);
			}
			$this->absorb( $resp );
			$code = (int) wp_remote_retrieve_response_code( $resp );
			$loc  = wp_remote_retrieve_header( $resp, 'location' );
			if ( is_array( $loc ) ) {
				$loc = end( $loc );
			}
			if ( $code >= 300 && $code < 400 && $loc && $hops < 6 ) {
				$referer = $url;
				$url     = $this->resolve( $url, $loc );
				$method  = 'GET';
				$body    = null;
				$headers = array( 'Referer' => $referer );
				$hops++;
				continue;
			}
			$ctype = wp_remote_retrieve_header( $resp, 'content-type' );
			return array(
				'ok'     => true,
				'code'   => $code,
				'body'   => (string) wp_remote_retrieve_body( $resp ),
				'url'    => $url,
				'ctype'  => is_array( $ctype ) ? end( $ctype ) : (string) $ctype,
				'method' => $orig,
				'hops'   => $hops,
				'ms'     => $ms,
			);
		}
	}

	/* ------------------------------------------------------------------ form */

	public static function strip_comments( $html ) {
		return preg_replace( '/<!--.*?-->/s', '', (string) $html );
	}

	public static function token_of( $html ) {
		if ( preg_match( '/name=["\']_token["\'][^>]*value=["\']([^"\']+)["\']/i', $html, $m )
			|| preg_match( '/value=["\']([^"\']+)["\'][^>]*name=["\']_token["\']/i', $html, $m ) ) {
			return $m[1];
		}
		return '';
	}

	public function get_form() {
		$r = $this->request( 'GET', $this->url( 'appointment_form' ), null, array(), (int) NBY_Settings::get( 'timeout_get' ) );
		if ( ! $r['ok'] ) {
			return array( 'ok' => false, 'error' => self::explain( $r['error'] ), 'code' => 0, 'ms' => $r['ms'] );
		}
		if ( preg_match( '#/closed\b#i', $r['url'] ) ) {
			return array( 'ok' => false, 'closed_all' => true, 'error' => 'سایت به صفحه «Registration Closed» هدایت کرد.', 'code' => $r['code'], 'ms' => $r['ms'], 'body' => $r['body'] );
		}
		if ( 200 !== $r['code'] ) {
			return array( 'ok' => false, 'error' => 'کد پاسخ سایت هنگام باز کردن فرم: ' . $r['code'], 'code' => $r['code'], 'ms' => $r['ms'], 'body' => $r['body'] );
		}
		$token = self::token_of( $r['body'] );
		if ( '' === $token ) {
			return array( 'ok' => false, 'unknown' => true, 'error' => 'توکن فرم در صفحه پیدا نشد.', 'code' => $r['code'], 'ms' => $r['ms'], 'body' => $r['body'] );
		}
		return array( 'ok' => true, 'token' => $token, 'html' => $r['body'], 'url' => $r['url'], 'code' => 200, 'ms' => $r['ms'] );
	}

	/**
	 * Check the live form still matches what we send. Returns array(ok, problems[]).
	 */
	public static function fingerprint( $html, $team ) {
		$h        = self::strip_comments( $html );
		$problems = array();
		foreach ( NBY_Fields::site_required_names() as $n ) {
			if ( ! preg_match( '/name=["\']' . preg_quote( $n, '/' ) . '["\']/', $h ) ) {
				$problems[] = 'فیلد «' . $n . '» در فرم سایت نیست';
			}
		}
		if ( ! preg_match( '/<option[^>]*value=["\']' . preg_quote( $team, '/' ) . '["\']/', $h ) ) {
			$problems[] = 'گزینه محل «' . $team . '» در فرم سایت نیست';
		}
		foreach ( NBY_Fields::schema() as $k => $f ) {
			if ( isset( $f['type'] ) && 'select' === $f['type'] && 'team' !== $k ) {
				foreach ( array_keys( $f['options'] ) as $ov ) {
					if ( ! preg_match( '/value=["\']' . preg_quote( $ov, '/' ) . '["\']/', $h ) ) {
						$problems[] = 'گزینه «' . $ov . '» برای «' . $k . '» در سایت نیست';
					}
				}
			}
		}
		$known = array_merge( NBY_Fields::site_required_names(), array( '_token' ) );
		if ( preg_match_all( '/<(?:input|select|textarea)\b[^>]*>/i', $h, $tags ) ) {
			foreach ( $tags[0] as $tag ) {
				if ( preg_match( '/\brequired\b/i', $tag ) && preg_match( '/name=["\']([^"\']+)["\']/', $tag, $nm ) && ! in_array( $nm[1], $known, true ) ) {
					$problems[] = 'فیلد اجباری جدید در سایت: «' . $nm[1] . '»';
				}
			}
		}
		return array( 'ok' => empty( $problems ), 'problems' => array_values( array_unique( $problems ) ) );
	}

	public function submit( $token, array $payload, $file_path, $file_name, $mime ) {
		$b    = '----NobatyarBoundary' . wp_generate_password( 20, false, false );
		$body = '';
		$all  = array_merge( array( array( '_token', $token ) ), $payload );
		foreach ( $all as $pair ) {
			list( $k, $v ) = $pair;
			if ( 'document_tazkira' === $k ) {
				$body .= "--$b\r\nContent-Disposition: form-data; name=\"document_tazkira\"; filename=\"" . str_replace( '"', '', $file_name ) . "\"\r\nContent-Type: $mime\r\n\r\n";
				$body .= file_get_contents( $file_path ) . "\r\n";
				continue;
			}
			$body .= "--$b\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n" . str_replace( array( "\r\n", "\r", "\n" ), "\r\n", (string) $v ) . "\r\n";
		}
		$body .= "--$b--\r\n";
		$headers = array(
			'Content-Type' => 'multipart/form-data; boundary=' . $b,
			'Origin'       => $this->base,
			'Referer'      => $this->url( 'appointment_form' ),
		);
		return $this->request( 'POST', $this->url( 'appointment_success' ), $body, $headers, (int) NBY_Settings::get( 'timeout_post' ) );
	}

	/* ------------------------------------------------------------------ analysis */

	public static function visible_text( $html ) {
		$h = self::strip_comments( $html );
		$h = preg_replace( '/<style\b.*?<\/style>/is', ' ', $h );
		$h = preg_replace( '/<(br|\/p|\/div|\/li|\/tr|\/h\d)\b[^>]*>/i', "\n", $h );
		$h = wp_strip_all_tags( preg_replace( '/<script\b[^>]*>(.*?)<\/script>/is', ' $1 ', $h ), false );
		$h = html_entity_decode( $h, ENT_QUOTES, 'UTF-8' );
		return trim( preg_replace( '/[ \t\x{00A0}]+/u', ' ', preg_replace( '/\s*\n\s*/', "\n", $h ) ) );
	}

	private static function clean_msg( $s ) {
		$s = html_entity_decode( wp_strip_all_tags( $s ), ENT_QUOTES, 'UTF-8' );
		return trim( preg_replace( '/\s+/u', ' ', $s ) );
	}

	/** Flash/alert/validation messages shown on the page. */
	public static function alerts( $html ) {
		$h    = self::strip_comments( $html );
		$msgs = array();
		// Only opening tags that themselves look like an alert, so an outer wrapper can't swallow the message.
		if ( preg_match_all( '/<(div|span|p|li|strong|small)\b([^>]*(?:f8d7da|842029|\balert\b|alert-|danger|error|invalid-feedback)[^>]*)>(.*?)<\/\1>/is', $h, $mm, PREG_SET_ORDER ) ) {
			foreach ( $mm as $m ) {
				$t = self::clean_msg( $m[3] );
				if ( mb_strlen( $t ) >= 3 && preg_match( '/[\p{L}]/u', $t ) ) {
					$msgs[] = $t;
				}
			}
		}
		if ( preg_match_all( '/\b(?:alert|Swal\.fire|swal|toastr\.\w+)\s*\(\s*(?:\{[^}]*?(?:title|text|html)\s*:\s*)?([\'"`])(.*?)\1/is', $h, $sm ) ) {
			foreach ( $sm[2] as $t ) {
				$t = self::clean_msg( $t );
				if ( mb_strlen( $t ) >= 3 ) {
					$msgs[] = $t;
				}
			}
		}
		return array_values( array_unique( $msgs ) );
	}

	private static function has_kw( $text, array $kws ) {
		foreach ( $kws as $k ) {
			if ( '' !== $k && false !== mb_stripos( $text, $k ) ) {
				return $k;
			}
		}
		return false;
	}

	public static function parse_ticket( $html ) {
		$t   = self::visible_text( $html );
		$out = array( 'no' => '', 'date' => '', 'place' => '' );
		if ( preg_match( '/Ticket\s*#\s*(\d{3,})/i', $t, $m ) || preg_match( '/شماره\s*(?:نوبت|تکت|ټکټ|تیکت)\s*[:#]?\s*(\d{3,})/u', $t, $m ) ) {
			$out['no'] = $m[1];
		}
		if ( preg_match( '/(\d{4}-\d{2}-\d{2})\s*\(\s*(\d{4}\/\d{2}\/\d{2})\s*\)(?:\s*-\s*([\p{Arabic}]+))?/u', $t, $m ) ) {
			$out['date'] = trim( $m[1] . ' (' . $m[2] . ')' . ( isset( $m[3] ) ? ' ' . $m[3] : '' ) );
		}
		if ( preg_match( '/Team\s*:\s*([^\s]+)/u', $t, $m ) ) {
			$out['place'] = $m[1];
		}
		return $out;
	}

	public static function is_form_page( $html ) {
		return false !== stripos( $html, 'appointment_success' ) && false !== stripos( $html, 'name="team"' );
	}

	/**
	 * Network-level failure → was the POST possibly processed?
	 */
	public static function error_kind( array $r ) {
		if ( 'POST' !== $r['method'] ) {
			return 'transient';
		}
		if ( $r['hops'] > 0 ) {
			return 'uncertain';
		}
		if ( preg_match( '/cURL error (6|7)\b|Could not resolve|resolve host|Failed to connect|Connection refused|Connection timed out after|Network is unreachable/i', $r['error'] ) ) {
			return 'transient';
		}
		return 'uncertain';
	}

	/**
	 * Classify the response to a form POST.
	 * result: success | closed | validation | transient | uncertain | unknown
	 */
	public static function classify( array $r ) {
		if ( ! $r['ok'] ) {
			$k = self::error_kind( $r );
			return array(
				'result'  => $k,
				'message' => ( 'uncertain' === $k ? 'ارتباط بعد از ارسال فرم قطع شد؛ ممکن است ثبت شده باشد. ' : '' ) . self::explain( $r['error'] ),
				'ticket'  => null,
			);
		}
		$code = (int) $r['code'];
		if ( 419 === $code ) {
			return array( 'result' => 'transient', 'message' => 'توکن فرم منقضی شد (419) — دوباره تلاش می‌شود.', 'ticket' => null );
		}
		if ( 429 === $code ) {
			return array( 'result' => 'transient', 'message' => 'سایت درخواست‌ها را محدود کرد (429).', 'ticket' => null, 'rate_limited' => true );
		}
		if ( 413 === $code ) {
			return array( 'result' => 'validation', 'message' => 'سایت فایل تذکره را به‌دلیل حجم زیاد نپذیرفت (413). فایل کوچک‌تری بارگذاری کنید.', 'ticket' => null );
		}
		if ( 503 === $code ) {
			return array( 'result' => 'transient', 'message' => 'سایت در دسترس نیست (503).', 'ticket' => null );
		}
		if ( $code >= 500 ) {
			return array( 'result' => 'uncertain', 'message' => 'خطای سرور سایت (' . $code . ') بعد از ارسال؛ ممکن است ثبت شده باشد.', 'ticket' => null );
		}

		$html   = $r['body'];
		$text   = self::visible_text( $html );
		$ticket = self::parse_ticket( $html );
		$succ   = self::has_kw( $text, NBY_Settings::keywords( 'success_keywords' ) );
		if ( $ticket['no'] && ( $succ || preg_match( '/teckit|ticket|success/i', $r['url'] ) ) ) {
			return array( 'result' => 'success', 'message' => 'نوبت ثبت شد. شماره: ' . $ticket['no'] . ( $ticket['date'] ? ' — تاریخ: ' . $ticket['date'] : '' ), 'ticket' => $ticket );
		}
		if ( $succ && ! self::is_form_page( $html ) ) {
			return array( 'result' => 'success', 'message' => 'سایت پیام موفقیت داد ولی شماره نوبت خوانده نشد — صفحه تیکت را بررسی کنید.', 'ticket' => $ticket );
		}

		$alerts = self::alerts( $html );
		$closed = NBY_Settings::keywords( 'closed_keywords' );
		$joined = implode( ' | ', $alerts );
		if ( ( $alerts && self::has_kw( $joined, $closed ) ) || ( ! $alerts && self::has_kw( $text, $closed ) ) || preg_match( '#/closed\b#i', $r['url'] ) ) {
			return array( 'result' => 'closed', 'message' => $joined ? $joined : 'ثبت‌نام بسته است.', 'ticket' => null );
		}
		if ( $code >= 400 ) {
			return array( 'result' => 'unknown', 'message' => 'کد پاسخ غیرمنتظره ' . $code . ': ' . mb_substr( $text, 0, 200 ), 'ticket' => null );
		}
		if ( self::is_form_page( $html ) && $alerts ) {
			return array( 'result' => 'validation', 'message' => $joined, 'ticket' => null );
		}
		return array(
			'result'  => 'unknown',
			'message' => ( self::is_form_page( $html ) ? 'فرم بدون پیام قابل تشخیص برگشت. ' : 'پاسخ ناشناخته. ' ) . mb_substr( $joined ? $joined : $text, 0, 300 ),
			'ticket'  => null,
		);
	}

	/* ------------------------------------------------------------------ lookup (read-only) */

	/**
	 * Look up an existing ticket via /retrive_ticket (never books anything).
	 * Returns array(found => true|false|null, ticket, html, url, message).
	 */
	public function lookup( $name, $surname, $phone ) {
		$g = $this->request( 'GET', $this->url( 'retrive_ticket' ), null, array(), (int) NBY_Settings::get( 'timeout_get' ) );
		if ( ! $g['ok'] || 200 !== $g['code'] ) {
			return array( 'found' => null, 'message' => 'صفحه جستجوی نوبت باز نشد. ' . ( $g['ok'] ? 'کد ' . $g['code'] : $g['error'] ), 'html' => '', 'url' => '' );
		}
		$token = self::token_of( $g['body'] );
		$body  = http_build_query(
			array(
				'_token'       => $token,
				'name'         => $name,
				'surname'      => $surname,
				'phone_number' => $phone,
			)
		);
		$r = $this->request(
			'POST',
			$this->url( 'retrived' ),
			$body,
			array(
				'Content-Type' => 'application/x-www-form-urlencoded',
				'Origin'       => $this->base,
				'Referer'      => $this->url( 'retrive_ticket' ),
			),
			(int) NBY_Settings::get( 'timeout_get' )
		);
		if ( ! $r['ok'] ) {
			return array( 'found' => null, 'message' => 'جستجو ناموفق: ' . $r['error'], 'html' => '', 'url' => '' );
		}
		$ticket = self::parse_ticket( $r['body'] );
		if ( $ticket['no'] ) {
			return array( 'found' => true, 'ticket' => $ticket, 'html' => $r['body'], 'url' => $r['url'], 'message' => 'نوبت در سایت پیدا شد: ' . $ticket['no'] );
		}
		$text   = self::visible_text( $r['body'] );
		$alerts = implode( ' | ', self::alerts( $r['body'] ) );
		if ( preg_match( '/not\s*found|no\s*record|یافت نشد|پیدا نشد|موجود نیست|وجود ندارد|ونه موندل|نشته/iu', $alerts . ' ' . $text ) ) {
			return array( 'found' => false, 'html' => $r['body'], 'url' => $r['url'], 'message' => 'در جستجوی سایت پیدا نشد. ' . $alerts );
		}
		return array( 'found' => null, 'html' => $r['body'], 'url' => $r['url'], 'message' => 'نتیجه جستجو قابل تشخیص نبود. ' . mb_substr( $alerts ? $alerts : $text, 0, 200 ) );
	}

	/* ------------------------------------------------------------------ ticket archive */

	private function fetch_asset( $url, $max_bytes ) {
		if ( $this->asset_budget-- <= 0 ) {
			return null;
		}
		$r = $this->request( 'GET', $url, null, array( 'Accept' => '*/*' ), 20 );
		if ( ! $r['ok'] || 200 !== $r['code'] || strlen( $r['body'] ) > $max_bytes || '' === $r['body'] ) {
			return null;
		}
		return $r;
	}

	/**
	 * Make the ticket page self-contained (inline CSS/JS/images) so it can be
	 * viewed/printed later even after the site session expires.
	 */
	public function archive( $html, $page_url ) {
		$self = $this;
		$h    = (string) $html;

		$h = preg_replace_callback(
			'/<link\b[^>]*rel=["\']?stylesheet["\']?[^>]*>/i',
			function ( $m ) use ( $self, $page_url ) {
				if ( ! preg_match( '/href=["\']([^"\']+)["\']/i', $m[0], $hm ) ) {
					return $m[0];
				}
				$u = $self->resolve( $page_url, $hm[1] );
				$r = $self->fetch_asset_public( $u, 800 * 1024 );
				if ( ! $r ) {
					return $m[0];
				}
				$css = preg_replace_callback(
					'/url\(\s*([\'"]?)([^\'")]+)\1\s*\)/i',
					function ( $um ) use ( $self, $u ) {
						if ( 0 === stripos( $um[2], 'data:' ) ) {
							return $um[0];
						}
						return 'url("' . $self->resolve( $u, $um[2] ) . '")';
					},
					$r['body']
				);
				return "<style>\n" . str_ireplace( '</style', '<\/style', $css ) . "\n</style>";
			},
			$h
		);

		$h = preg_replace_callback(
			'/<script\b([^>]*)\bsrc=["\']([^"\']+)["\']([^>]*)>\s*<\/script>/i',
			function ( $m ) use ( $self, $page_url ) {
				$u = $self->resolve( $page_url, $m[2] );
				$r = $self->fetch_asset_public( $u, 800 * 1024 );
				if ( ! $r ) {
					return $m[0];
				}
				return '<script>' . str_ireplace( '</script', '<\/script', $r['body'] ) . '</script>';
			},
			$h
		);

		$h = preg_replace_callback(
			'/(<img\b[^>]*\bsrc=)(["\'])([^"\']+)\2/i',
			function ( $m ) use ( $self, $page_url ) {
				if ( 0 === stripos( $m[3], 'data:' ) ) {
					return $m[0];
				}
				$u = $self->resolve( $page_url, $m[3] );
				$r = $self->fetch_asset_public( $u, 2 * MB_IN_BYTES );
				if ( ! $r ) {
					return $m[1] . $m[2] . esc_url( $u ) . $m[2];
				}
				$type = $r['ctype'] ? trim( explode( ';', $r['ctype'] )[0] ) : 'image/png';
				if ( 0 !== stripos( $type, 'image/' ) ) {
					$type = 'image/png';
				}
				return $m[1] . $m[2] . 'data:' . $type . ';base64,' . base64_encode( $r['body'] ) . $m[2];
			},
			$h
		);

		$base = '<base href="' . esc_url( $page_url ) . '">';
		if ( preg_match( '/<head\b[^>]*>/i', $h ) ) {
			$h = preg_replace( '/<head\b[^>]*>/i', '$0' . $base, $h, 1 );
		} else {
			$h = $base . $h;
		}
		return $h;
	}

	public function fetch_asset_public( $url, $max ) {
		return $this->fetch_asset( $url, $max );
	}

	/** If the ticket page links to a real PDF, download it. Returns bytes or ''. */
	public function find_pdf( $html, $page_url ) {
		if ( ! preg_match_all( '/<a\b[^>]*href=["\']([^"\'#]+)["\'][^>]*>(.*?)<\/a>/is', $html, $mm, PREG_SET_ORDER ) ) {
			return '';
		}
		foreach ( $mm as $m ) {
			if ( preg_match( '/pdf|download|print/i', $m[1] . ' ' . wp_strip_all_tags( $m[2] ) ) && ! preg_match( '/^(javascript|mailto):/i', $m[1] ) ) {
				$r = $this->fetch_asset( $this->resolve( $page_url, $m[1] ), 10 * MB_IN_BYTES );
				if ( $r && ( false !== stripos( $r['ctype'], 'pdf' ) || 0 === strpos( $r['body'], '%PDF' ) ) ) {
					return $r['body'];
				}
			}
		}
		return '';
	}
}
