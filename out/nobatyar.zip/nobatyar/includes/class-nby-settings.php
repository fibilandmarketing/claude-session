<?php
defined( 'ABSPATH' ) || exit;

class NBY_Settings {

	const OPT = 'nby_settings';

	private static $cache = null;

	public static function teams() {
		return array(
			'team3' => 'مشهد',
			'team2' => 'زاهدان',
		);
	}

	public static function defaults() {
		return array(
			'base_url'         => 'http://ivsf.nsia.gov.af',
			'team3_enabled'    => 1,
			'team3_interval'   => 60,
			'team3_burst'      => 5,
			'team3_open_gap'   => 0,
			'team2_enabled'    => 1,
			'team2_interval'   => 60,
			'team2_burst'      => 2,
			'team2_open_gap'   => 30,
			'timeout_get'      => 30,
			'timeout_post'     => 90,
			'connect_timeout'  => 20,
			'tick_budget'      => 50,
			'closed_keywords'  => implode( "\n", array( 'پر است', 'پر شده', 'پر میباشد', 'پر می‌باشد', 'بسته است', 'بسته میباشد', 'بسته می‌باشد', 'ظرفیت', 'تکمیل', 'Registration Closed', 'currently full', 'is full' ) ),
			'success_keywords' => implode( "\n", array( 'Appointment Confirmed', 'successfully scheduled', 'Ticket #' ) ),
			'dry_run'          => 1,
			'max_file_mb'      => 5,
			'user_agent'       => 'Nobatyar/1.0 (appointment assistant; WordPress)',
			'bale_token'       => '',
			'bale_chat'        => '',
			'bale_api'         => 'https://tapi.bale.ai',
			'notify_email'     => '',
			'cron_key'         => '',
			'retention_days'   => 30,
			'default_religion' => 'اسلام',
			'default_country'  => 'افغانستان',
			'delete_on_uninstall' => 0,
			'panel_slug'       => 'nobatyar',
			'notify_events'    => array( 'mashhad_open' => 1, 'booked' => 1, 'nsia' => 1, 'bot' => 1, 'login' => 1, 'logout' => 1, 'password' => 1, 'delete' => 1, 'security' => 1, 'uncertain' => 1 ),
		);
	}

	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPT, array() );
			self::$cache = array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );
		}
		return self::$cache;
	}

	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	public static function update( array $values ) {
		$all = array_merge( self::all(), $values );
		update_option( self::OPT, $all, false );
		self::$cache = $all;
	}

	public static function keywords( $key ) {
		$lines = preg_split( '/\r\n|\r|\n/', (string) self::get( $key ) );
		return array_values( array_filter( array_map( 'trim', $lines ), 'strlen' ) );
	}

	public static function team_cfg( $team ) {
		$s = self::all();
		return array(
			'enabled'  => ! empty( $s[ $team . '_enabled' ] ),
			'interval' => max( 20, (int) $s[ $team . '_interval' ] ),
			'burst'    => max( 1, min( 50, (int) $s[ $team . '_burst' ] ) ),
			'open_gap' => max( 0, (int) $s[ $team . '_open_gap' ] ),
		);
	}

	public static function ensure_cron_key() {
		if ( ! self::get( 'cron_key' ) ) {
			self::update( array( 'cron_key' => wp_generate_password( 32, false, false ) ) );
		}
	}
}
