<?php
defined( 'ABSPATH' ) || exit;

/**
 * Stand-alone front-end panel at /{panel_slug} (default /nobatyar), independent of the theme.
 */
class NBY_Panel {

	const QV = 'nby_panel';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'rewrite' ) );
		add_filter( 'query_vars', function ( $v ) {
			$v[] = self::QV;
			return $v;
		} );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render' ), 0 );
	}

	public static function slug() {
		$s = sanitize_title( (string) NBY_Settings::get( 'panel_slug' ) );
		return $s ? $s : 'nobatyar';
	}

	public static function rewrite() {
		add_rewrite_rule( '^' . preg_quote( self::slug(), '/' ) . '/?$', 'index.php?' . self::QV . '=1', 'top' );
		if ( get_option( 'nby_flush_rewrite' ) ) {
			delete_option( 'nby_flush_rewrite' );
			flush_rewrite_rules( false );
		}
	}

	public static function url() {
		if ( get_option( 'permalink_structure' ) ) {
			return home_url( '/' . self::slug() . '/' );
		}
		return add_query_arg( self::QV, 1, home_url( '/' ) );
	}

	/** Shared boot config for the JS app (panel mode and wp-admin embedded mode). */
	public static function boot( $mode ) {
		$fields = array();
		foreach ( NBY_Fields::schema() as $k => $f ) {
			$fields[] = array(
				'key'     => $k,
				'label'   => $f['label'],
				'group'   => $f['group'],
				'req'     => (bool) $f['req'],
				'type'    => isset( $f['type'] ) ? $f['type'] : 'text',
				'options' => isset( $f['options'] ) ? $f['options'] : null,
				'help'    => isset( $f['help'] ) ? $f['help'] : '',
				'default' => isset( $f['default'] ) ? $f['default'] : '',
			);
		}
		return array(
			'mode'      => $mode,
			'api'       => esc_url_raw( rest_url( NBY_API::NS . '/app/' ) ),
			'transports' => NBY_API::transports(),
			'minPass'   => NBY_Auth::MIN_PASS,
			'roles'     => NBY_Auth::roles(),
			'nonce'     => 'wp' === $mode ? wp_create_nonce( 'wp_rest' ) : '',
			'csrf'      => NBY_Auth::csrf(),
			'me'        => NBY_API::public_actor(),
			'teams'     => NBY_Settings::teams(),
			'statuses'  => NBY_DB::statuses(),
			'results'   => NBY_DB::results(),
			'fields'    => $fields,
			'groups'    => NBY_Fields::groups(),
			'docTypes'  => NBY_Fields::doc_types(),
			'maxFileMb' => (int) NBY_Settings::get( 'max_file_mb' ),
			'fileCol'   => NBY_Import::FILE_COL,
			'panelUrl'  => self::url(),
			'siteName'  => get_bloginfo( 'name' ),
			'version'   => NBY_VERSION,
		);
	}

	public static function favicon() {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="#0f6a61"/><path d="M8 11.5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2a2.5 2.5 0 0 0 0 5v2a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2v-2a2.5 2.5 0 0 0 0-5z" fill="none" stroke="#fffdfa" stroke-width="2"/><path d="M13 16.2l2 2 4-4.4" fill="none" stroke="#fffdfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
		return 'data:image/svg+xml,' . rawurlencode( $svg );
	}

	public static function maybe_render() {
		if ( ! get_query_var( self::QV ) && empty( $_GET[ self::QV ] ) ) { // phpcs:ignore
			return;
		}
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();
		header( 'X-LiteSpeed-Cache-Control: no-cache' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( "Content-Security-Policy: frame-ancestors 'self'" );
		header( 'Referrer-Policy: same-origin' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		status_header( 200 );

		NBY_Auth::$panel_only = true;
		$boot = self::boot( 'panel' );
		$css  = NBY_URL . 'assets/app.css?ver=' . NBY_VERSION;
		$js   = NBY_URL . 'assets/app.js?ver=' . NBY_VERSION;
		$font = NBY_URL . 'assets/fonts/vazirmatn-arabic-wght-normal.woff2';
		?><!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#f4f2ee">
<title>نوبت‌یار — <?php echo esc_html( get_bloginfo( 'name' ) ); ?></title>
<link rel="icon" href="<?php echo esc_attr( self::favicon() ); ?>">
<link rel="preload" href="<?php echo esc_url( $font ); ?>" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="<?php echo esc_url( $css ); ?>">
</head>
<body class="nby-app is-panel">
<a class="nby-skip" href="#nby-main">رفتن به محتوا</a>
<div id="nby-root" aria-live="polite"><div class="nby-boot"><span class="nby-boot-mark"></span></div></div>
<noscript><p class="nby-noscript">برای استفاده از پنل نوبت‌یار، جاوااسکریپت مرورگر را فعال کنید.</p></noscript>
<script>window.NBY_APP = <?php echo wp_json_encode( $boot, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;</script>
<script src="<?php echo esc_url( $js ); ?>" defer></script>
</body>
</html>
		<?php
		exit;
	}
}
