<?php
defined( 'ABSPATH' ) || exit;

/**
 * Audit trail of panel users (login/logout, created/edited/deleted applicants, prints, …)
 * and the per-user work report sent on logout.
 */
class NBY_Activity {

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'nby_activity';
	}

	public static function install( $cs ) {
		$t = self::table();
		dbDelta( "CREATE TABLE $t (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  actor varchar(40) NOT NULL DEFAULT '',
  actor_name varchar(100) NOT NULL DEFAULT '',
  action varchar(30) NOT NULL DEFAULT '',
  object_id bigint(20) unsigned NOT NULL DEFAULT 0,
  object_name varchar(191) NOT NULL DEFAULT '',
  details text NULL,
  ip varchar(45) NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY actor (actor,created_at),
  KEY action (action,created_at)
) $cs;" );
	}

	public static function labels() {
		return array(
			'login'          => 'ورود به پنل',
			'logout'         => 'خروج از پنل',
			'logout_auto'    => 'پایان خودکار نشست',
			'login_locked'   => 'قفل ورود (رمز اشتباه)',
			'create'         => 'افزودن متقاضی',
			'update'         => 'ویرایش متقاضی',
			'delete'         => 'حذف متقاضی',
			'try'            => 'ارسال فوری',
			'verify'         => 'جستجوی نوبت در سایت',
			'queue'          => 'افزودن به صف',
			'hold'           => 'خارج کردن از صف',
			'bulk'           => 'عملیات گروهی',
			'import'         => 'ورود گروهی',
			'print'          => 'چاپ / مشاهده تیکت',
			'password'       => 'تغییر رمز',
			'user_create'    => 'ساخت حساب',
			'user_update'    => 'ویرایش حساب',
			'bot'            => 'روشن/خاموش کردن ربات',
		);
	}

	private static function ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ), 0, 45 ) : '';
	}

	/**
	 * @param string $actor_key  'p:ID' | 'w:ID' | '' (defaults to the current actor)
	 */
	public static function log( $action, $object_id = 0, $object_name = '', array $details = array(), $actor_key = null, $actor_name = null ) {
		global $wpdb;
		$wpdb->insert(
			self::table(),
			array(
				'actor'       => null === $actor_key ? NBY_Auth::actor_key() : $actor_key,
				'actor_name'  => mb_substr( null === $actor_name ? NBY_Auth::actor_name() : $actor_name, 0, 100 ),
				'action'      => $action,
				'object_id'   => (int) $object_id,
				'object_name' => mb_substr( (string) $object_name, 0, 190 ),
				'details'     => $details ? wp_json_encode( $details, JSON_UNESCAPED_UNICODE ) : null,
				'ip'          => self::ip(),
				'created_at'  => current_time( 'mysql', true ),
			)
		);
	}

	/** UTC mysql datetime of today's 00:00 in the site timezone. */
	public static function today_start() {
		return get_gmt_from_date( wp_date( 'Y-m-d 00:00:00' ) );
	}

	public static function recent( $actor_key, $limit = 40 ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE actor = %s ORDER BY id DESC LIMIT %d', $actor_key, $limit ), ARRAY_A );
		$l    = self::labels();
		return array_map(
			function ( $r ) use ( $l ) {
				$d = $r['details'] ? json_decode( $r['details'], true ) : array();
				return array(
					'time'   => NBY_Jalali::dt( $r['created_at'] ),
					'action' => $r['action'],
					'label'  => isset( $l[ $r['action'] ] ) ? $l[ $r['action'] ] : $r['action'],
					'object' => $r['object_name'],
					'id'     => (int) $r['object_id'],
					'note'   => isset( $d['note'] ) ? (string) $d['note'] : '',
					'ip'     => $r['ip'],
				);
			},
			$rows
		);
	}

	/**
	 * Work done by one actor since $since (UTC mysql). Used by the team page and the logout report.
	 */
	public static function stats( $actor_key, $since ) {
		global $wpdb;
		$tc  = NBY_DB::t_citizens();
		$ta  = self::table();
		$out = array(
			'added'    => 0,
			'by_status' => array(),
			'updated'  => 0,
			'deleted'  => 0,
			'tries'    => 0,
			'imports'  => 0,
			'imported' => 0,
			'printed'  => array(),
			'deleted_names' => array(),
		);
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT status, COUNT(*) n FROM $tc WHERE owner = %s AND created_at >= %s GROUP BY status", $actor_key, $since ), ARRAY_A ) as $r ) {
			$out['by_status'][ $r['status'] ] = (int) $r['n'];
			$out['added'] += (int) $r['n'];
		}
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT action, object_name, details FROM $ta WHERE actor = %s AND created_at >= %s AND action IN ('update','delete','try','import','print')", $actor_key, $since ), ARRAY_A ) as $r ) {
			switch ( $r['action'] ) {
				case 'update':
					$out['updated']++;
					break;
				case 'delete':
					$out['deleted']++;
					$out['deleted_names'][] = $r['object_name'];
					break;
				case 'try':
					$out['tries']++;
					break;
				case 'import':
					$out['imports']++;
					$d = $r['details'] ? json_decode( $r['details'], true ) : array();
					$out['imported'] += isset( $d['imported'] ) ? (int) $d['imported'] : 0;
					break;
				case 'print':
					$out['printed'][ $r['object_name'] ] = true;
					break;
			}
		}
		$out['printed'] = array_keys( $out['printed'] );
		return $out;
	}

	/** Messenger-ready (Bale) work report lines for a finished session. */
	public static function report_lines( $actor_key, $since, $login_ts, $logout_ts ) {
		$s     = self::stats( $actor_key, $since );
		$names = NBY_DB::statuses();
		$lines = array();
		if ( $login_ts ) {
			$dur     = max( 0, $logout_ts - $login_ts );
			$lines[] = '🕒 ورود: ' . wp_date( 'H:i', $login_ts ) . ' — خروج: ' . wp_date( 'H:i', $logout_ts ) . ' (' . self::duration( $dur ) . ')';
		}
		$lines[] = '';
		$lines[] = '📋 کارکرد امروز:';
		$lines[] = '➕ متقاضی جدید: ' . $s['added'];
		$order = array( 'queued', 'draft', 'needs_fix', 'booked', 'uncertain', 'on_hold', 'processing' );
		foreach ( $order as $st ) {
			if ( ! empty( $s['by_status'][ $st ] ) ) {
				$label = 'draft' === $st ? 'ناقص (پیش‌نویس)' : ( 'needs_fix' === $st ? 'با مشکل (نیاز به اصلاح)' : $names[ $st ] );
				$lines[] = '     • ' . $label . ': ' . $s['by_status'][ $st ];
			}
		}
		$lines[] = '✏️ ویرایش: ' . $s['updated'];
		$lines[] = '🗑 حذف: ' . ( $s['deleted'] ? $s['deleted'] . ' (' . implode( '، ', array_slice( $s['deleted_names'], 0, 10 ) ) . ')' : 'نداشت' );
		if ( $s['tries'] ) {
			$lines[] = '⚡ ارسال فوری: ' . $s['tries'];
		}
		if ( $s['imports'] ) {
			$lines[] = '📥 ورود گروهی: ' . $s['imports'] . ' بار (' . $s['imported'] . ' نفر)';
		}
		$lines[] = '🖨 چاپ نوبت: ' . ( $s['printed'] ? implode( '، ', array_slice( $s['printed'], 0, 15 ) ) . ( count( $s['printed'] ) > 15 ? ' و ' . ( count( $s['printed'] ) - 15 ) . ' نفر دیگر' : '' ) : 'نداشت' );
		return $lines;
	}

	public static function duration( $sec ) {
		$h = intdiv( $sec, 3600 );
		$m = intdiv( $sec % 3600, 60 );
		if ( $h ) {
			return $h . ' ساعت' . ( $m ? ' و ' . $m . ' دقیقه' : '' );
		}
		return max( 1, $m ) . ' دقیقه';
	}

	public static function cleanup( $days ) {
		global $wpdb;
		$cut = gmdate( 'Y-m-d H:i:s', time() - max( 30, (int) $days ) * DAY_IN_SECONDS );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . ' WHERE created_at < %s', $cut ) );
	}
}
