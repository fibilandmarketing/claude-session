<?php
defined( 'ABSPATH' ) || exit;

/**
 * Private file storage (tazkira scans, site responses, ticket archives).
 * Lives in uploads/nobatyar-private with deny rules; served only through admin handlers.
 */
class NBY_Storage {

	const DIRNAME = 'nobatyar-private';

	public static function base() {
		$up = wp_upload_dir( null, false );
		return trailingslashit( $up['basedir'] ) . self::DIRNAME;
	}

	public static function ensure() {
		$base = self::base();
		foreach ( array( '', '/files', '/responses', '/tickets' ) as $sub ) {
			if ( ! is_dir( $base . $sub ) ) {
				wp_mkdir_p( $base . $sub );
			}
			if ( ! file_exists( $base . $sub . '/index.php' ) ) {
				@file_put_contents( $base . $sub . '/index.php', "<?php\n// Silence.\n" );
			}
		}
		if ( ! file_exists( $base . '/.htaccess' ) ) {
			@file_put_contents( $base . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
		}
		if ( ! file_exists( $base . '/web.config' ) ) {
			@file_put_contents( $base . '/web.config', '<?xml version="1.0"?><configuration><system.webServer><authorization><deny users="*" /></authorization></system.webServer></configuration>' );
		}
	}

	private static function rand_name( $ext ) {
		return gmdate( 'Ymd' ) . '-' . wp_generate_password( 20, false, false ) . '.' . preg_replace( '/[^a-z0-9]/', '', strtolower( $ext ) );
	}

	/** Returns relative path "sub/name". */
	public static function put( $sub, $content, $ext ) {
		self::ensure();
		$rel = $sub . '/' . self::rand_name( $ext );
		if ( false === @file_put_contents( self::base() . '/' . $rel, $content ) ) {
			return '';
		}
		return $rel;
	}

	public static function move_upload( $tmp, $ext ) {
		self::ensure();
		$rel = 'files/' . self::rand_name( $ext );
		$ok  = is_uploaded_file( $tmp ) ? @move_uploaded_file( $tmp, self::base() . '/' . $rel ) : @copy( $tmp, self::base() . '/' . $rel );
		return $ok ? $rel : '';
	}

	public static function path( $rel ) {
		if ( ! $rel || ! preg_match( '#^(files|responses|tickets)/[A-Za-z0-9\-]+\.[a-z0-9]+$#', $rel ) ) {
			return '';
		}
		return self::base() . '/' . $rel;
	}

	public static function get( $rel ) {
		$p = self::path( $rel );
		return ( $p && is_file( $p ) ) ? (string) file_get_contents( $p ) : '';
	}

	public static function exists( $rel ) {
		$p = self::path( $rel );
		return $p && is_file( $p );
	}

	public static function delete( $rel ) {
		$p = self::path( $rel );
		if ( $p && is_file( $p ) ) {
			@unlink( $p );
		}
	}

	public static function allowed_mimes() {
		return array(
			'jpg|jpeg' => 'image/jpeg',
			'png'      => 'image/png',
			'pdf'      => 'application/pdf',
			'webp'     => 'image/webp',
		);
	}

	/**
	 * Validate an uploaded/extracted file. Returns array(ext, mime) or WP_Error.
	 */
	public static function check_file( $path, $name ) {
		$max = max( 1, (int) NBY_Settings::get( 'max_file_mb' ) ) * MB_IN_BYTES;
		if ( ! is_file( $path ) || filesize( $path ) <= 0 ) {
			return new WP_Error( 'nby_file', 'فایل خالی یا نامعتبر است.' );
		}
		if ( filesize( $path ) > $max ) {
			return new WP_Error( 'nby_file', 'حجم فایل بیشتر از حد مجاز (' . NBY_Settings::get( 'max_file_mb' ) . ' مگابایت) است.' );
		}
		$ft = wp_check_filetype_and_ext( $path, $name, self::allowed_mimes() );
		if ( empty( $ft['ext'] ) || empty( $ft['type'] ) ) {
			return new WP_Error( 'nby_file', 'نوع فایل مجاز نیست (فقط JPG، PNG، WEBP یا PDF).' );
		}
		return array( $ft['ext'], $ft['type'] );
	}
}
