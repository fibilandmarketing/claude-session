<?php
defined( 'ABSPATH' ) || exit;

/**
 * The bot engine.
 *
 * Every "tick" (server cron each minute, or WP-Cron fallback):
 *  - Mashhad first, then Zahedan. For each team that is due, submit the head of its queue.
 *  - "closed"  → wait <interval> seconds and try again with the same applicant.
 *  - "success" → team is open: keep going with the next applicants (burst) right away.
 *  - "validation" → applicant goes to "needs fix", continue with the next one.
 *  - network errors → exponential backoff. Unknown response / changed form → auto-pause + alert.
 * A tick may sleep inside its time budget so intervals shorter than the cron period work.
 */
class NBY_Runner {

	const HOOK  = 'nby_tick_event';
	const DAILY = 'nby_daily_event';
	const LOCK  = 'nby_tick_lock';

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) );
		add_action( self::HOOK, function () {
			self::tick( 'wp-cron' );
		} );
		add_action( self::DAILY, array( __CLASS__, 'daily' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'rest' ) );
	}

	public static function cron_schedules( $s ) {
		$s['nby_minute'] = array( 'interval' => 60, 'display' => 'هر دقیقه (نوبت‌یار)' );
		return $s;
	}

	public static function schedule() {
		if ( ! has_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) ) ) {
			add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) );
		}
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 60, 'nby_minute', self::HOOK );
		}
		if ( ! wp_next_scheduled( self::DAILY ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::DAILY );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( self::HOOK );
		wp_clear_scheduled_hook( self::DAILY );
	}

	public static function rest() {
		register_rest_route(
			'nobatyar/v1',
			'/tick',
			array(
				'methods'             => array( 'GET', 'POST' ),
				'permission_callback' => '__return_true',
				'callback'            => function ( $req ) {
					$key = (string) $req->get_param( 'key' );
					$own = (string) NBY_Settings::get( 'cron_key' );
					if ( '' === $key || '' === $own || ! hash_equals( $own, $key ) ) {
						return new WP_REST_Response( array( 'error' => 'forbidden' ), 403 );
					}
					$r = self::tick( 'server-cron' );
					unset( $r['results'] );
					return rest_ensure_response( $r );
				},
			)
		);
	}

	private static function queued_count( $team ) {
		$c = NBY_DB::counts();
		return isset( $c['by_team'][ $team ]['queued'] ) ? (int) $c['by_team'][ $team ]['queued'] : 0;
	}

	public static function daily() {
		NBY_DB::cleanup( (int) NBY_Settings::get( 'retention_days' ) );
		NBY_Activity::cleanup( 365 );
	}

	public static function cron_url() {
		return add_query_arg( 'key', NBY_Settings::get( 'cron_key' ), rest_url( 'nobatyar/v1/tick' ) );
	}

	/* ------------------------------------------------------------------ state */

	private static function raw( $name ) {
		global $wpdb;
		$v = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name ) );
		return null === $v ? array() : maybe_unserialize( $v );
	}

	public static function control() {
		$c = self::raw( 'nby_control' );
		return array_merge( array( 'running' => 0, 'paused' => array(), 'stop_reason' => '' ), is_array( $c ) ? $c : array() );
	}

	public static function set_control( array $c ) {
		update_option( 'nby_control', $c, false );
	}

	public static function state() {
		$s     = self::raw( 'nby_state' );
		$s     = is_array( $s ) ? $s : array();
		$teams = array();
		foreach ( array_keys( NBY_Settings::teams() ) as $t ) {
			$teams[ $t ] = array_merge(
				array(
					'state'          => 'unknown',
					'next_at'        => 0,
					'last_at'        => 0,
					'last_result'    => '',
					'last_message'   => '',
					'errors'         => 0,
					'idle'           => 0,
					'last_open_at'   => 0,
					'last_closed_at' => 0,
				),
				isset( $s['teams'][ $t ] ) ? $s['teams'][ $t ] : array()
			);
		}
		$s          = array_merge( array( 'last_tick_at' => 0, 'last_tick_source' => '', 'last_closed_saved' => 0 ), $s );
		$s['teams'] = $teams;
		return $s;
	}

	public static function save_state( array $s ) {
		update_option( 'nby_state', $s, false );
	}

	private static function team_update( $team, array $upd ) {
		$st                   = self::state();
		$st['teams'][ $team ] = array_merge( $st['teams'][ $team ], $upd );
		self::save_state( $st );
	}

	/* ------------------------------------------------------------------ lock */

	private static function lock() {
		global $wpdb;
		$now = time();
		$ok  = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", self::LOCK, (string) $now ) );
		if ( $ok ) {
			return true;
		}
		$old = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::LOCK ) );
		if ( $old < $now - 600 ) {
			return (bool) $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s", (string) $now, self::LOCK, (string) $old ) );
		}
		return false;
	}

	private static function unlock() {
		global $wpdb;
		$wpdb->delete( $wpdb->options, array( 'option_name' => self::LOCK ) );
		wp_cache_delete( self::LOCK, 'options' );
	}

	public static function is_locked() {
		global $wpdb;
		$v = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::LOCK ) );
		return $v && $v > time() - 600;
	}

	/* ------------------------------------------------------------------ tick */

	private static function prepare_runtime() {
		$need = (int) NBY_Settings::get( 'tick_budget' ) + (int) NBY_Settings::get( 'timeout_post' ) + 180;
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( $need );
		}
		ignore_user_abort( true );
	}

	public static function tick( $source = 'manual' ) {
		self::prepare_runtime();
		if ( ! self::lock() ) {
			return array( 'status' => 'busy' );
		}
		$summary = array( 'status' => 'ok', 'source' => $source, 'attempts' => 0, 'booked' => 0, 'results' => array() );
		try {
			$st                     = self::state();
			$st['last_tick_at']     = time();
			$st['last_tick_source'] = $source;
			self::save_state( $st );
			NBY_DB::recover_stale( 15 );
			NBY_Auth::close_idle_sessions();

			$c = self::control();
			if ( empty( $c['running'] ) ) {
				$summary['status'] = 'stopped';
				return $summary;
			}
			$deadline = time() + max( 10, min( 240, (int) NBY_Settings::get( 'tick_budget' ) ) );

			self::verify_one( $source );

			while ( true ) {
				foreach ( array_keys( NBY_Settings::teams() ) as $team ) {
					$c = self::control();
					if ( empty( $c['running'] ) ) {
						break 2;
					}
					$cfg = NBY_Settings::team_cfg( $team );
					if ( ! $cfg['enabled'] || ! empty( $c['paused'][ $team ] ) ) {
						continue;
					}
					$ts = self::state()['teams'][ $team ];
					if ( $ts['next_at'] > time() + 2 ) {
						continue;
					}
					if ( $deadline - time() < 8 ) {
						break 2;
					}
					self::run_team( $team, $cfg, $deadline, $source, $summary );
				}
				$soon = self::soonest_due();
				if ( null === $soon ) {
					break;
				}
				$wait = $soon - time();
				if ( $wait <= 2 ) {
					if ( $deadline - time() < 8 ) {
						break;
					}
					continue;
				}
				if ( time() + $wait <= $deadline - 8 ) {
					sleep( $wait );
					continue;
				}
				break;
			}
		} finally {
			self::unlock();
		}
		return $summary;
	}

	private static function soonest_due() {
		$c    = self::control();
		$st   = self::state();
		$soon = null;
		if ( empty( $c['running'] ) ) {
			return null;
		}
		foreach ( array_keys( NBY_Settings::teams() ) as $team ) {
			$cfg = NBY_Settings::team_cfg( $team );
			if ( ! $cfg['enabled'] || ! empty( $c['paused'][ $team ] ) || ! empty( $st['teams'][ $team ]['idle'] ) ) {
				continue; // empty queue: no point keeping the PHP worker asleep, the next cron tick checks again
			}
			$n = (int) $st['teams'][ $team ]['next_at'];
			if ( null === $soon || $n < $soon ) {
				$soon = $n;
			}
		}
		return $soon;
	}

	private static function run_team( $team, array $cfg, $deadline, $source, array &$summary ) {
		$label = NBY_Settings::teams()[ $team ];
		$done  = 0;
		$tried = array();
		while ( true ) {
			if ( $deadline - time() < 8 ) {
				return;
			}
			$c = self::control();
			if ( empty( $c['running'] ) || ! empty( $c['paused'][ $team ] ) ) {
				return;
			}
			$cit = NBY_DB::claim_next( $team, $tried );
			if ( ! $cit ) {
				self::team_update( $team, array( 'next_at' => time() + $cfg['interval'], 'idle' => 1 ) );
				return;
			}
			$tried[] = (int) $cit['id'];
			$res     = self::attempt( $cit, $source );
			$summary['attempts']++;
			$summary['results'][] = $res['result'];
			$upd = array(
				'last_at'      => time(),
				'last_result'  => $res['result'],
				'last_message' => mb_substr( $res['message'], 0, 300 ),
				'idle'         => 0,
			);
			$prev_errors = (int) self::state()['teams'][ $team ]['errors'];
			if ( $prev_errors >= 3 && in_array( $res['result'], array( 'success', 'closed', 'validation', 'dry' ), true ) ) {
				NBY_Notify::event( 'nsia', array( 'NSIA', 'اتصال_برقرار_شد', $label ), '🟢 ارتباط با سامانه NSIA دوباره برقرار شد', array( '📍 محل: ' . $label, '🔁 بعد از ' . $prev_errors . ' خطای پیاپی' ) );
			}
			switch ( $res['result'] ) {
				case 'success':
					$summary['booked']++;
					$done++;
					$prev = self::state()['teams'][ $team ]['state'];
					$upd  = array_merge( $upd, array( 'state' => 'open', 'errors' => 0, 'last_open_at' => time() ) );
					if ( 'open' !== $prev ) {
						NBY_Notify::event( 'mashhad_open', array( $label . '_باز_شد', 'نوبت_باز' ), '🟢 نوبت ' . $label . ' باز شد', array( '👥 در صف ' . $label . ': ' . self::queued_count( $team ) . ' نفر', '⚡ ثبت خودکار صف شروع شد.' ) );
					}
					if ( $done >= $cfg['burst'] ) {
						$upd['next_at'] = time() + $cfg['open_gap'];
						self::team_update( $team, $upd );
						return;
					}
					self::team_update( $team, $upd );
					continue 2;

				case 'validation':
					$upd['errors'] = 0;
					self::team_update( $team, $upd );
					continue 2;

				case 'closed':
					$upd = array_merge( $upd, array( 'state' => 'closed', 'errors' => 0, 'next_at' => time() + $cfg['interval'], 'last_closed_at' => time() ) );
					self::team_update( $team, $upd );
					return;

				case 'dry':
					$upd['errors']  = 0;
					$upd['next_at'] = time() + $cfg['interval'];
					self::team_update( $team, $upd );
					return;

				case 'transient':
					$e    = $prev_errors + 1;
					$back = (int) min( 900, $cfg['interval'] * pow( 2, min( 5, $e - 1 ) ) );
					if ( ! empty( $res['rate_limited'] ) ) {
						$back = max( $back, 600 );
					}
					$upd = array_merge( $upd, array( 'errors' => $e, 'next_at' => time() + $back ) );
					self::team_update( $team, $upd );
					if ( 3 === $e ) {
						NBY_Notify::event( 'nsia', array( 'NSIA', 'قطعی_ارتباط', $label ), '🔴 ارتباط با سامانه NSIA برقرار نمی‌شود', array( '📍 محل: ' . $label, '🔁 خطای پیاپی: ' . $e, '⚠️ ' . $res['message'], '⏳ ربات با فاصله بیشتر دوباره تلاش می‌کند.' ) );
					} elseif ( $e >= 10 ) {
						NBY_Notify::event_once( 'transient-' . $team, 3 * HOUR_IN_SECONDS, 'nsia', array( 'NSIA', 'قطعی_طولانی', $label ), '🔴 سامانه NSIA همچنان در دسترس نیست', array( '📍 محل: ' . $label, '🔁 خطای پیاپی: ' . $e, '⚠️ ' . $res['message'] ) );
					}
					return;

				case 'uncertain':
					$upd['next_at'] = time() + $cfg['interval'];
					self::team_update( $team, $upd );
					NBY_Notify::event( 'uncertain', array( 'نتیجه_نامعلوم', $label ), '⚠️ نتیجه ارسال نامعلوم ماند', array( '👤 ' . $cit['full_name'], '🔎 ربات خودکار در جستجوی نوبت سایت بررسی می‌کند و تا روشن شدن، دوباره ارسال نمی‌کند.', 'ℹ️ ' . $res['message'] ) );
					return;

				case 'fingerprint':
					$c                = self::control();
					$c['running']     = 0;
					$c['stop_reason'] = 'فرم سایت تغییر کرده است: ' . $res['message'];
					self::set_control( $c );
					self::team_update( $team, $upd );
					NBY_Notify::event( 'bot', array( 'ربات_خاموش', 'NSIA', 'تغییر_فرم' ), '⛔ ربات خودکار متوقف شد', array( '🧩 فرم سایت NSIA تغییر کرده و ارسال با فرم قدیمی خطرناک است.', '⚠️ ' . $res['message'] ) );
					return;

				default: // unknown
					$c                    = self::control();
					$c['paused'][ $team ] = 'پاسخ ناشناخته از سایت. صفحه پاسخ را در «گزارش اجرا» ببینید؛ اگر پیام «بسته/پر» بود، متن آن را به کلمات کلیدی تنظیمات اضافه کنید و ادامه دهید.';
					self::set_control( $c );
					self::team_update( $team, $upd );
					NBY_Notify::event( 'nsia', array( 'NSIA', 'پاسخ_ناشناخته', $label ), '⏸ پایش ' . $label . ' متوقف شد', array( '❓ سامانه NSIA پاسخ ناشناخته‌ای داد.', 'ℹ️ ' . mb_substr( $res['message'], 0, 300 ), '👉 پاسخ را در «گزارش اجرا» ببینید و بعد «ادامه» را بزنید.' ) );
					return;
			}
		}
	}

	/* ------------------------------------------------------------------ one attempt */

	private static function should_store( $result ) {
		if ( 'closed' !== $result ) {
			return true;
		}
		$st = self::state();
		if ( time() - (int) $st['last_closed_saved'] > 6 * HOUR_IN_SECONDS ) {
			$st['last_closed_saved'] = time();
			self::save_state( $st );
			return true;
		}
		return false;
	}

	/**
	 * Submit one (already claimed → "processing") applicant. Always leaves a final status.
	 */
	public static function attempt( array $cit, $source ) {
		$t0     = microtime( true );
		$id     = (int) $cit['id'];
		$team   = $cit['team'];
		$fin    = function ( $status, $result, $message, array $extra = array(), $http = 0, $rel = '' ) use ( $id, $team, $t0, $source, $cit ) {
			NBY_DB::set_status(
				$id,
				$status,
				array_merge(
					array(
						'attempts'        => (int) $cit['attempts'] + 1,
						'last_attempt_at' => NBY_DB::now(),
						'last_result'     => $result,
						'last_message'    => mb_substr( $message, 0, 1000 ),
					),
					$extra
				)
			);
			NBY_DB::log_attempt(
				array(
					'citizen_id'   => $id,
					'team'         => $team,
					'kind'         => 'submit',
					'result'       => $result,
					'http_code'    => (int) $http,
					'message'      => $message,
					'duration_ms'  => (int) round( ( microtime( true ) - $t0 ) * 1000 ),
					'response_rel' => $rel,
					'source'       => $source,
				)
			);
			return array( 'result' => $result, 'message' => $message );
		};

		$has_file = NBY_Storage::exists( $cit['file_rel'] );
		list( $clean, $errors ) = NBY_Fields::validate( $cit['data'], $has_file );
		if ( $errors ) {
			return $fin( 'needs_fix', 'validation', 'اطلاعات ناقص یا نامعتبر: ' . implode( ' ', $errors ) );
		}

		$client = new NBY_Client();
		$form   = $client->get_form();
		if ( ! $form['ok'] ) {
			$rel = ! empty( $form['body'] ) ? NBY_Storage::put( 'responses', $form['body'], 'html' ) : '';
			if ( ! empty( $form['closed_all'] ) ) {
				return $fin( 'queued', 'closed', $form['error'], array(), $form['code'], $rel );
			}
			if ( ! empty( $form['unknown'] ) ) {
				return $fin( 'queued', 'unknown', $form['error'], array(), $form['code'], $rel );
			}
			return $fin( 'queued', 'transient', $form['error'], array(), $form['code'], $rel );
		}

		$fp = NBY_Client::fingerprint( $form['html'], $team );
		if ( ! $fp['ok'] ) {
			$rel = NBY_Storage::put( 'responses', $form['html'], 'html' );
			return $fin( 'queued', 'fingerprint', implode( '؛ ', $fp['problems'] ), array(), 200, $rel );
		}

		$payload = NBY_Fields::payload( $clean );
		if ( NBY_Settings::get( 'dry_run' ) ) {
			return $fin( 'queued', 'dry', 'حالت آزمایشی: فرم سایت باز شد، ساختار آن تأیید شد و ' . ( count( $payload ) + 1 ) . ' فیلد آماده ارسال بود؛ چیزی ارسال نشد.', array(), 200 );
		}

		$ext = pathinfo( $cit['file_name'], PATHINFO_EXTENSION );
		$ext = $ext ? strtolower( $ext ) : 'jpg';
		$r   = $client->submit( $form['token'], $payload, NBY_Storage::path( $cit['file_rel'] ), 'tazkira.' . $ext, $cit['file_mime'] ? $cit['file_mime'] : 'image/jpeg' );
		$cls = NBY_Client::classify( $r );
		$rel = ( $r['ok'] && '' !== $r['body'] && self::should_store( $cls['result'] ) ) ? NBY_Storage::put( 'responses', $r['body'], 'html' ) : '';
		$http = (int) $r['code'];

		switch ( $cls['result'] ) {
			case 'success':
				return self::finish_booked( $cit, $client, $r['body'], $r['url'], $cls['ticket'], $cls['message'], $fin, $http, $rel );
			case 'closed':
				return $fin( 'queued', 'closed', $cls['message'], array(), $http, $rel );
			case 'validation':
				return $fin( 'needs_fix', 'validation', 'سایت اطلاعات را نپذیرفت: ' . $cls['message'], array(), $http, $rel );
			case 'transient':
				$out = $fin( 'queued', 'transient', $cls['message'], array(), $http, $rel );
				if ( ! empty( $cls['rate_limited'] ) ) {
					$out['rate_limited'] = true;
				}
				return $out;
			case 'uncertain':
				return $fin( 'uncertain', 'uncertain', $cls['message'], array(), $http, $rel );
			default:
				return $fin( 'queued', 'unknown', $cls['message'], array(), $http, $rel );
		}
	}

	private static function finish_booked( array $cit, NBY_Client $client, $html, $url, $ticket, $message, $fin, $http, $rel ) {
		$archive = $client->archive( $html, $url );
		$trel    = NBY_Storage::put( 'tickets', $archive, 'html' );
		$pdf     = $client->find_pdf( $html, $url );
		$prel    = $pdf ? NBY_Storage::put( 'tickets', $pdf, 'pdf' ) : '';
		$ticket  = is_array( $ticket ) ? $ticket : array( 'no' => '', 'date' => '', 'place' => '' );
		$out     = $fin(
			'booked',
			'success',
			$message,
			array(
				'ticket_no'      => $ticket['no'],
				'ticket_date'    => $ticket['date'],
				'ticket_place'   => $ticket['place'] ? $ticket['place'] : NBY_Settings::teams()[ $cit['team'] ],
				'ticket_rel'     => $trel,
				'ticket_pdf_rel' => $prel,
				'booked_at'      => NBY_DB::now(),
			),
			$http,
			$rel
		);
		$team_label = NBY_Settings::teams()[ $cit['team'] ];
		NBY_Notify::event(
			'booked',
			array( 'نوبت_ثبت_شد', $team_label ),
			'✅ نوبت ثبت شد',
			array_values(
				array_filter(
					array(
						'👤 متقاضی: ' . $cit['full_name'],
						'📍 محل: ' . $team_label,
						$ticket['no'] ? '🎫 شماره نوبت: ' . $ticket['no'] : '',
						$ticket['date'] ? '📅 تاریخ نوبت: ' . $ticket['date'] : '',
						! empty( $cit['created_by_name'] ) ? '🧑‍💼 ثبت‌کننده پرونده: ' . $cit['created_by_name'] : '',
					)
				)
			),
			$archive,
			'ticket-' . ( $ticket['no'] ? $ticket['no'] : $cit['id'] ) . '.html'
		);
		return $out;
	}

	/* ------------------------------------------------------------------ verification of uncertain results */

	public static function verify( array $cit, $source ) {
		$t0     = microtime( true );
		$d      = $cit['data'];
		$client = new NBY_Client();
		$res    = $client->lookup( isset( $d['name'] ) ? $d['name'] : '', isset( $d['surname'] ) ? $d['surname'] : '', isset( $d['phone_number'] ) ? $d['phone_number'] : '' );
		$rel    = $res['html'] ? NBY_Storage::put( 'responses', $res['html'], 'html' ) : '';
		$result = true === $res['found'] ? 'found' : ( false === $res['found'] ? 'not_found' : 'uncertain' );
		NBY_DB::save( array( 'verified_at' => NBY_DB::now() ), (int) $cit['id'] );
		NBY_DB::log_attempt(
			array(
				'citizen_id'   => (int) $cit['id'],
				'team'         => $cit['team'],
				'kind'         => 'verify',
				'result'       => $result,
				'message'      => $res['message'],
				'duration_ms'  => (int) round( ( microtime( true ) - $t0 ) * 1000 ),
				'response_rel' => $rel,
				'source'       => $source,
			)
		);
		if ( true === $res['found'] ) {
			$archive = $client->archive( $res['html'], $res['url'] );
			$trel    = NBY_Storage::put( 'tickets', $archive, 'html' );
			NBY_DB::set_status(
				(int) $cit['id'],
				'booked',
				array(
					'last_result'  => 'success',
					'last_message' => $res['message'],
					'ticket_no'    => $res['ticket']['no'],
					'ticket_date'  => $res['ticket']['date'],
					'ticket_place' => $res['ticket']['place'] ? $res['ticket']['place'] : NBY_Settings::teams()[ $cit['team'] ],
					'ticket_rel'   => $trel,
					'booked_at'    => NBY_DB::now(),
				)
			);
			NBY_Notify::event( 'booked', array( 'نوبت_ثبت_شد', 'تأیید_از_جستجو' ), '✅ نوبت در جستجوی سایت پیدا شد', array( '👤 متقاضی: ' . $cit['full_name'], '🎫 شماره نوبت: ' . $res['ticket']['no'], 'ℹ️ نتیجه ارسال قبلاً نامعلوم بود.' ), $archive, 'ticket-' . $res['ticket']['no'] . '.html' );
		} else {
			NBY_DB::save( array( 'last_message' => $res['message'] . ' — اگر مطمئنید ثبت نشده، «بازگشت به صف» را بزنید.' ), (int) $cit['id'] );
		}
		return $res;
	}

	private static function verify_one( $source ) {
		$cit = NBY_DB::next_uncertain();
		if ( $cit ) {
			self::verify( $cit, $source );
		}
	}

	/* ------------------------------------------------------------------ manual actions (admin) */

	public static function try_now( $id ) {
		self::prepare_runtime();
		if ( ! self::lock() ) {
			return array( 'result' => 'busy', 'message' => 'ربات همین الان در حال اجراست؛ چند ثانیه دیگر دوباره امتحان کنید.' );
		}
		try {
			$cit = NBY_DB::claim( (int) $id );
			if ( ! $cit ) {
				return array( 'result' => 'skip', 'message' => 'این متقاضی در وضعیتی نیست که بتوان ارسالش کرد (نوبت گرفته، نامعلوم یا در حال ارسال).' );
			}
			$res = self::attempt( $cit, 'manual' );
			$upd = array( 'last_at' => time(), 'last_result' => $res['result'], 'last_message' => mb_substr( $res['message'], 0, 300 ) );
			if ( 'closed' === $res['result'] ) {
				$upd['state']          = 'closed';
				$upd['last_closed_at'] = time();
			} elseif ( 'success' === $res['result'] ) {
				$upd['state']        = 'open';
				$upd['last_open_at'] = time();
			} elseif ( 'fingerprint' === $res['result'] ) {
				$c                = self::control();
				$c['running']     = 0;
				$c['stop_reason'] = 'فرم سایت تغییر کرده است: ' . $res['message'];
				self::set_control( $c );
				NBY_Notify::event( 'bot', array( 'ربات_خاموش', 'NSIA', 'تغییر_فرم' ), '⛔ ربات خودکار متوقف شد', array( '🧩 فرم سایت NSIA تغییر کرده است.', '⚠️ ' . $res['message'] ) );
			} elseif ( 'unknown' === $res['result'] ) {
				$c                          = self::control();
				$c['paused'][ $cit['team'] ] = 'پاسخ ناشناخته از سایت (در تلاش دستی). صفحه پاسخ را در «گزارش اجرا» ببینید.';
				self::set_control( $c );
			}
			self::team_update( $cit['team'], $upd );
			return $res;
		} finally {
			self::unlock();
		}
	}

	public static function verify_now( $id ) {
		self::prepare_runtime();
		$cit = NBY_DB::get( (int) $id );
		if ( ! $cit ) {
			return array( 'found' => null, 'message' => 'یافت نشد.' );
		}
		return self::verify( $cit, 'manual' );
	}

	/**
	 * Network diagnosis FROM THE HOSTING SERVER (the browser's own connectivity is irrelevant to the bot).
	 * Returns array( steps[], verdict ).
	 */
	public static function netcheck() {
		@set_time_limit( 150 );
		$base  = (string) NBY_Settings::get( 'base_url' );
		$host  = (string) wp_parse_url( $base, PHP_URL_HOST );
		$port  = 'https' === wp_parse_url( $base, PHP_URL_SCHEME ) ? 443 : 80;
		$steps = array();
		$ms    = function ( $t0 ) {
			return (int) round( ( microtime( true ) - $t0 ) * 1000 );
		};

		// 1. DNS
		$t0  = microtime( true );
		$ip  = filter_var( $host, FILTER_VALIDATE_IP ) ? $host : gethostbyname( $host );
		$dns = $ip && ( $ip !== $host || filter_var( $host, FILTER_VALIDATE_IP ) );
		$steps[] = array( 'name' => 'پیدا کردن آدرس NSIA (DNS)', 'ok' => $dns, 'info' => $dns ? $host . ' → ' . $ip : 'پیدا نشد', 'ms' => $ms( $t0 ) );

		// 2. raw TCP connect
		$tcp = false;
		if ( $dns && function_exists( 'fsockopen' ) ) {
			$t0  = microtime( true );
			$err = '';
			$eno = 0;
			$fp  = @fsockopen( ( 443 === $port ? 'ssl://' : '' ) . $ip, $port, $eno, $err, 20 );
			$tcp = (bool) $fp;
			if ( $fp ) {
				fclose( $fp );
			}
			$steps[] = array( 'name' => 'اتصال مستقیم به سرور NSIA (پورت ' . $port . ')', 'ok' => $tcp, 'info' => $tcp ? 'وصل شد' : ( $err ? $err : 'بدون پاسخ' ), 'ms' => $ms( $t0 ) );
		}

		// 3. real form page
		$t0   = microtime( true );
		$c    = new NBY_Client();
		$form = $c->get_form();
		$steps[] = array( 'name' => 'باز کردن فرم نوبت NSIA', 'ok' => ! empty( $form['ok'] ), 'info' => ! empty( $form['ok'] ) ? 'فرم دریافت شد' : $form['error'], 'ms' => $ms( $t0 ) );

		// 4. reference sites: is it only NSIA, or all international traffic?
		$refs = array(
			'اینترنت بین‌الملل (wordpress.org)' => 'https://api.wordpress.org/core/version-check/1.7/',
			'اینترنت داخلی (aparat.com)'        => 'https://www.aparat.com/',
		);
		$intl = null;
		foreach ( $refs as $label => $u ) {
			$t0 = microtime( true );
			$r  = wp_remote_head( $u, array( 'timeout' => 15, 'redirection' => 2 ) );
			$ok = ! is_wp_error( $r ) && wp_remote_retrieve_response_code( $r ) > 0;
			if ( null === $intl ) {
				$intl = $ok;
			}
			$steps[] = array( 'name' => $label, 'ok' => $ok, 'info' => $ok ? 'HTTP ' . wp_remote_retrieve_response_code( $r ) : ( is_wp_error( $r ) ? $r->get_error_message() : 'خطا' ), 'ms' => $ms( $t0 ) );
		}

		$server_ip = isset( $_SERVER['SERVER_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) ) : '';
		if ( ! empty( $form['ok'] ) ) {
			$verdict = '✅ سرور هاست به NSIA دسترسی دارد و فرم را می‌گیرد. اگر قبلاً خطا بود، قطعی موقت بوده است.';
		} elseif ( ! $dns ) {
			$verdict = '❌ DNS هاست آدرس NSIA را پیدا نمی‌کند. از پشتیبانی هاست بخواهید DNS سرور را بررسی کند.';
		} elseif ( ! $intl ) {
			$verdict = '❌ سرور هاست به اینترنت بین‌الملل دسترسی ندارد (نه فقط NSIA). این محدودیت دیتاسنتر/هاست است؛ از پشتیبانی هاست بپرسید یا ربات را روی هاستی با دسترسی بین‌الملل اجرا کنید.';
		} else {
			$verdict = '❌ سرور هاست به اینترنت بین‌الملل دسترسی دارد ولی به NSIA (' . $ip . ') وصل نمی‌شود. یعنی یا مسیر دیتاسنتر به افغانستان بسته است، یا NSIA این سرور (IP ' . ( $server_ip ? $server_ip : 'هاست' ) . ') را نمی‌پذیرد. این نتیجه را برای پشتیبانی هاست بفرستید تا دستور curl -v ' . $base . ' را از روی سرور تست کنند.';
		}
		return array( 'steps' => $steps, 'verdict' => $verdict, 'server_ip' => $server_ip );
	}

	/** Probe the form only (no submission): connectivity + structure check. */
	public static function probe() {
		$c = new NBY_Client();
		$f = $c->get_form();
		if ( ! $f['ok'] ) {
			return array( 'ok' => false, 'message' => $f['error'], 'ms' => isset( $f['ms'] ) ? $f['ms'] : 0 );
		}
		$msgs = array();
		$ok   = true;
		foreach ( array_keys( NBY_Settings::teams() ) as $t ) {
			$fp = NBY_Client::fingerprint( $f['html'], $t );
			if ( ! $fp['ok'] ) {
				$ok     = false;
				$msgs[] = NBY_Settings::teams()[ $t ] . ': ' . implode( '؛ ', $fp['problems'] );
			}
		}
		return array(
			'ok'      => $ok,
			'message' => $ok ? 'اتصال برقرار است و ساختار فرم سایت با ربات سازگار است.' : 'اتصال برقرار است اما فرم تغییر کرده: ' . implode( ' | ', $msgs ),
			'ms'      => $f['ms'],
		);
	}
}
