<?php
defined( 'ABSPATH' ) || exit;

/**
 * Jalali <-> Gregorian conversion and date parsing helpers.
 */
class NBY_Jalali {

	public static function digits( $s ) {
		$fa = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' );
		$en = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
		return str_replace( $fa, $en, (string) $s );
	}

	public static function g2j( $gy, $gm, $gd ) {
		$g_d_m = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );
		$gy2   = ( $gm > 2 ) ? ( $gy + 1 ) : $gy;
		$days  = 355666 + ( 365 * $gy ) + intdiv( $gy2 + 3, 4 ) - intdiv( $gy2 + 99, 100 ) + intdiv( $gy2 + 399, 400 ) + $gd + $g_d_m[ $gm - 1 ];
		$jy    = -1595 + ( 33 * intdiv( $days, 12053 ) );
		$days %= 12053;
		$jy   += 4 * intdiv( $days, 1461 );
		$days %= 1461;
		if ( $days > 365 ) {
			$jy  += intdiv( $days - 1, 365 );
			$days = ( $days - 1 ) % 365;
		}
		if ( $days < 186 ) {
			$jm = 1 + intdiv( $days, 31 );
			$jd = 1 + ( $days % 31 );
		} else {
			$jm = 7 + intdiv( $days - 186, 30 );
			$jd = 1 + ( ( $days - 186 ) % 30 );
		}
		return array( $jy, $jm, $jd );
	}

	public static function j2g( $jy, $jm, $jd ) {
		$jy  += 1595;
		$days = -355668 + ( 365 * $jy ) + ( intdiv( $jy, 33 ) * 8 ) + intdiv( ( $jy % 33 ) + 3, 4 ) + $jd + ( ( $jm < 7 ) ? ( $jm - 1 ) * 31 : ( ( $jm - 7 ) * 30 ) + 186 );
		$gy   = 400 * intdiv( $days, 146097 );
		$days %= 146097;
		if ( $days > 36524 ) {
			$days--;
			$gy  += 100 * intdiv( $days, 36524 );
			$days %= 36524;
			if ( $days >= 365 ) {
				$days++;
			}
		}
		$gy  += 4 * intdiv( $days, 1461 );
		$days %= 1461;
		if ( $days > 365 ) {
			$gy  += intdiv( $days - 1, 365 );
			$days = ( $days - 1 ) % 365;
		}
		$gd   = $days + 1;
		$leap = ( ( 0 === $gy % 4 && 0 !== $gy % 100 ) || 0 === $gy % 400 );
		$ml   = array( 0, 31, $leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );
		for ( $gm = 0; $gm < 13 && $gd > $ml[ $gm ]; $gm++ ) {
			$gd -= $ml[ $gm ];
		}
		return array( $gy, $gm, $gd );
	}

	/**
	 * Parse a user-entered date (Jalali or Gregorian, Persian or Latin digits).
	 * Returns Gregorian array(y, m, d) or null.
	 */
	public static function parse( $s ) {
		$s = trim( self::digits( $s ) );
		if ( '' === $s ) {
			return null;
		}
		$p = preg_split( '/[\/\-\.\s]+/', $s );
		if ( 3 !== count( $p ) ) {
			return null;
		}
		foreach ( $p as $x ) {
			if ( ! ctype_digit( $x ) ) {
				return null;
			}
		}
		if ( strlen( $p[0] ) === 4 ) {
			list( $y, $m, $d ) = array( (int) $p[0], (int) $p[1], (int) $p[2] );
		} elseif ( strlen( $p[2] ) === 4 ) {
			list( $d, $m, $y ) = array( (int) $p[0], (int) $p[1], (int) $p[2] );
		} else {
			return null;
		}
		if ( $y < 1700 ) {
			if ( $y < 1200 || $m < 1 || $m > 12 || $d < 1 || $d > 31 || ( $m > 6 && $d > 30 ) ) {
				return null;
			}
			list( $y, $m, $d ) = self::j2g( $y, $m, $d );
		}
		if ( ! checkdate( $m, $d, $y ) ) {
			return null;
		}
		return array( $y, $m, $d );
	}

	public static function fmt( $ymd, $sep = '/' ) {
		return sprintf( '%04d%s%02d%s%02d', $ymd[0], $sep, $ymd[1], $sep, $ymd[2] );
	}

	/** Gregorian Y/m/d (or Y-m-d) string -> Jalali Y/m/d string. */
	public static function to_jalali_str( $greg ) {
		$g = self::parse( $greg );
		if ( ! $g ) {
			return '';
		}
		return self::fmt( self::g2j( $g[0], $g[1], $g[2] ) );
	}

	/** UTC mysql datetime -> Jalali "Y/m/d H:i" in site timezone. */
	public static function dt( $mysql_utc, $with_time = true ) {
		if ( empty( $mysql_utc ) || '0000-00-00 00:00:00' === $mysql_utc ) {
			return '—';
		}
		$ts = strtotime( $mysql_utc . ' UTC' );
		return self::ts( $ts, $with_time );
	}

	public static function ts( $ts, $with_time = true ) {
		if ( ! $ts ) {
			return '—';
		}
		$y = (int) wp_date( 'Y', $ts );
		$m = (int) wp_date( 'n', $ts );
		$d = (int) wp_date( 'j', $ts );
		$j = self::g2j( $y, $m, $d );
		$s = self::fmt( $j );
		if ( $with_time ) {
			$s .= ' ' . wp_date( 'H:i:s', $ts );
		}
		return $s;
	}

	public static function ago( $ts ) {
		if ( ! $ts ) {
			return 'هرگز';
		}
		$diff = time() - (int) $ts;
		if ( $diff < 0 ) {
			$diff = 0;
		}
		if ( $diff < 60 ) {
			return $diff . ' ثانیه پیش';
		}
		if ( $diff < 3600 ) {
			return intdiv( $diff, 60 ) . ' دقیقه پیش';
		}
		if ( $diff < 86400 ) {
			return intdiv( $diff, 3600 ) . ' ساعت پیش';
		}
		return intdiv( $diff, 86400 ) . ' روز پیش';
	}
}
