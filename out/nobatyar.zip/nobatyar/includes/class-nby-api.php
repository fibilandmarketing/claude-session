<?php
defined( 'ABSPATH' ) || exit;

/**
 * JSON API for the Nobatyar app (front-end panel and the same app embedded in wp-admin).
 * Namespace: nobatyar/v1/app
 */
class NBY_API {

	const NS = 'nobatyar/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'wp_ajax_nby_api', array( __CLASS__, 'ajax_bridge' ) );
		add_action( 'wp_ajax_nopriv_nby_api', array( __CLASS__, 'ajax_bridge' ) );
	}

	/**
	 * Same-origin URL templates the panel tries in order. When /wp-json/ is blocked by a firewall,
	 * CDN or security plugin, the app falls back to ?rest_route= and then to admin-ajax.php.
	 */
	public static function transports() {
		$home = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$home = $home ? trailingslashit( $home ) : '/';
		$out  = array();
		if ( get_option( 'permalink_structure' ) ) {
			$out[] = array( 'id' => 'rest', 'base' => wp_parse_url( rest_url( self::NS . '/app/' ), PHP_URL_PATH ) );
		}
		$out[] = array( 'id' => 'rq', 'base' => $home . 'index.php?rest_route=' . rawurlencode( '/' . self::NS . '/app/' ) );
		$out[] = array( 'id' => 'ajax', 'base' => wp_parse_url( admin_url( 'admin-ajax.php' ), PHP_URL_PATH ) . '?action=nby_api&route=' );
		return $out;
	}

	/**
	 * admin-ajax.php → internal REST dispatch (same routes, same permission checks).
	 * Panel-session only: a WordPress login is never used here.
	 */
	public static function ajax_bridge() {
		NBY_Auth::$panel_only = true;
		nocache_headers();
		header( 'X-LiteSpeed-Cache-Control: no-cache' );
		$route = isset( $_GET['route'] ) ? (string) wp_unslash( $_GET['route'] ) : ''; // phpcs:ignore
		$route = preg_replace( '#[^A-Za-z0-9/_\-]#', '', $route );
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_key( $_SERVER['REQUEST_METHOD'] ) ) : 'GET';
		$req    = new WP_REST_Request( $method, '/' . self::NS . '/app/' . ltrim( $route, '/' ) );
		$q      = wp_unslash( $_GET ); // phpcs:ignore
		unset( $q['action'], $q['route'] );
		$req->set_query_params( $q );
		$csrf = isset( $_SERVER['HTTP_X_NBY_CSRF'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_NBY_CSRF'] ) ) : '';
		if ( $csrf ) {
			$req->set_header( 'x-nby-csrf', $csrf );
		}
		if ( 'POST' === $method ) {
			$ctype = isset( $_SERVER['CONTENT_TYPE'] ) ? (string) $_SERVER['CONTENT_TYPE'] : '';
			$req->set_header( 'content-type', $ctype );
			if ( false !== stripos( $ctype, 'application/json' ) ) {
				$req->set_body( (string) file_get_contents( 'php://input' ) );
			} else {
				$p = wp_unslash( $_POST ); // phpcs:ignore -- sanitized per route
				unset( $p['action'], $p['route'] );
				$req->set_body_params( $p );
				$req->set_file_params( $_FILES );
			}
		}
		$res    = rest_do_request( $req );
		$server = rest_get_server();
		$data   = $server->response_to_data( $res, false );
		wp_send_json( $data, $res->get_status() );
	}

	/* ================================================================== plumbing */

	private static function perm( $cap ) {
		return function ( WP_REST_Request $req ) use ( $cap ) {
			$a = NBY_Auth::actor();
			if ( ! $a ) {
				return new WP_Error( 'nby_auth', 'نشست شما تمام شده؛ دوباره وارد شوید.', array( 'status' => 401 ) );
			}
			if ( 'GET' !== $req->get_method() && 'panel' === $a['type'] && ! NBY_Auth::check_csrf( $req->get_header( 'x-nby-csrf' ) ? $req->get_header( 'x-nby-csrf' ) : (string) $req->get_param( '_nbycsrf' ) ) ) {
				return new WP_Error( 'nby_csrf', 'اعتبار صفحه تمام شده؛ صفحه را تازه کنید.', array( 'status' => 403 ) );
			}
			if ( $cap && ! NBY_Auth::can( $cap ) ) {
				return new WP_Error( 'nby_forbidden', 'نقش کاربری شما اجازه این کار را ندارد.', array( 'status' => 403 ) );
			}
			return true;
		};
	}

	private static function route( $path, $methods, $cb, $cap ) {
		register_rest_route(
			self::NS,
			'/app/' . $path,
			array(
				'methods'             => $methods,
				'callback'            => function ( $req ) use ( $cb ) {
					nocache_headers();
					$r = call_user_func( $cb, $req );
					if ( is_wp_error( $r ) ) {
						return $r;
					}
					$res = rest_ensure_response( $r );
					$res->header( 'Cache-Control', 'no-store, private' );
					$res->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
					return $res;
				},
				'permission_callback' => null === $cap ? '__return_true' : self::perm( $cap ),
			)
		);
	}

	private static function err( $msg, $status = 400, $extra = array() ) {
		return new WP_Error( 'nby_error', $msg, array_merge( array( 'status' => $status ), $extra ) );
	}

	public static function routes() {
		self::route( 'login', 'POST', array( __CLASS__, 'login' ), null );
		self::route( 'logout', 'POST', array( __CLASS__, 'logout' ), null );
		self::route( 'me', 'GET', array( __CLASS__, 'me' ), null );
		self::route( 'me/password', 'POST', array( __CLASS__, 'my_password' ), 'view' );
		self::route( 'team', 'GET', array( __CLASS__, 'team' ), 'team' );
		self::route( 'team', 'POST', array( __CLASS__, 'team_save' ), 'team' );
		self::route( 'team/(?P<id>\d+)', 'GET', array( __CLASS__, 'team_member' ), 'team' );
		self::route( 'team/(?P<id>\d+)', 'POST', array( __CLASS__, 'team_save' ), 'team' );
		self::route( 'status', 'GET', array( __CLASS__, 'status' ), 'view' );
		self::route( 'control', 'POST', array( __CLASS__, 'control' ), 'control' );
		self::route( 'tick', 'POST', array( __CLASS__, 'tick' ), 'try' );
		self::route( 'probe', 'POST', array( __CLASS__, 'probe' ), 'try' );
		self::route( 'citizens', 'GET', array( __CLASS__, 'citizens' ), 'view' );
		self::route( 'citizens', 'POST', array( __CLASS__, 'save' ), 'edit' );
		self::route( 'citizens/bulk', 'POST', array( __CLASS__, 'bulk' ), 'edit' );
		self::route( 'citizens/(?P<id>\d+)', 'GET', array( __CLASS__, 'citizen' ), 'view' );
		self::route( 'citizens/(?P<id>\d+)', 'POST', array( __CLASS__, 'save' ), 'edit' );
		self::route( 'citizens/(?P<id>\d+)/action', 'POST', array( __CLASS__, 'action' ), 'view' );
		self::route( 'attempts', 'GET', array( __CLASS__, 'attempts' ), 'view' );
		self::route( 'import', 'POST', array( __CLASS__, 'import' ), 'import' );
		self::route( 'raw/(?P<kind>ticket|pdf|file|response|template)/(?P<id>\d+)', 'GET', array( __CLASS__, 'raw' ), 'view' );
	}

	/* ================================================================== formatting */

	private static function label( $map, $k ) {
		return isset( $map[ $k ] ) ? $map[ $k ] : (string) $k;
	}

	public static function fmt_citizen( array $r ) {
		return array(
			'id'           => (int) $r['id'],
			'status'       => $r['status'],
			'status_label' => self::label( NBY_DB::statuses(), $r['status'] ),
			'team'         => $r['team'],
			'team_label'   => self::label( NBY_Settings::teams(), $r['team'] ),
			'priority'     => (int) $r['priority'],
			'full_name'    => $r['full_name'],
			'phone'        => $r['phone'],
			'attempts'     => (int) $r['attempts'],
			'last_result'  => $r['last_result'],
			'result_label' => '' !== $r['last_result'] ? self::label( NBY_DB::results(), $r['last_result'] ) : '',
			'last_message' => (string) $r['last_message'],
			'last_attempt' => isset( $r['last_attempt_at'] ) ? NBY_Jalali::dt( $r['last_attempt_at'] ) : '',
			'ticket_no'    => $r['ticket_no'],
			'ticket_date'  => $r['ticket_date'],
			'ticket_place' => $r['ticket_place'],
			'has_ticket'   => ! empty( $r['ticket_rel'] ),
			'has_pdf'      => ! empty( $r['ticket_pdf_rel'] ),
			'booked_at'    => $r['booked_at'] ? NBY_Jalali::dt( $r['booked_at'] ) : '',
			'created_at'   => NBY_Jalali::dt( $r['created_at'], false ),
			'created_by'   => isset( $r['created_by_name'] ) ? (string) $r['created_by_name'] : '',
		);
	}

	private static function fmt_attempt( array $r ) {
		$kinds = array( 'submit' => 'ارسال فرم', 'verify' => 'جستجوی نوبت' );
		return array(
			'id'           => (int) $r['id'],
			'time'         => NBY_Jalali::dt( $r['created_at'] ),
			'ago'          => NBY_Jalali::ago( strtotime( $r['created_at'] . ' UTC' ) ),
			'citizen_id'   => (int) $r['citizen_id'],
			'full_name'    => isset( $r['full_name'] ) ? (string) $r['full_name'] : '',
			'team_label'   => self::label( NBY_Settings::teams(), $r['team'] ),
			'kind_label'   => self::label( $kinds, $r['kind'] ),
			'result'       => $r['result'],
			'result_label' => self::label( NBY_DB::results(), $r['result'] ),
			'http_code'    => (int) $r['http_code'],
			'message'      => (string) $r['message'],
			'seconds'      => round( $r['duration_ms'] / 1000, 1 ),
			'has_response' => '' !== $r['response_rel'],
		);
	}

	public static function public_actor() {
		$a = NBY_Auth::actor();
		if ( ! $a ) {
			return null;
		}
		return array(
			'name'      => $a['name'],
			'username'  => $a['username'],
			'role'      => $a['role'],
			'role_name' => $a['role_name'],
			'caps'      => $a['caps'],
			'type'      => $a['type'],
		);
	}

	/* ================================================================== auth */

	public static function login( WP_REST_Request $req ) {
		$u = NBY_Auth::login( (string) $req->get_param( 'username' ), (string) $req->get_param( 'password' ), (bool) $req->get_param( 'remember' ) );
		if ( is_wp_error( $u ) ) {
			return self::err( $u->get_error_message(), 'nby_locked' === $u->get_error_code() ? 429 : 401 );
		}
		return array( 'me' => self::public_actor(), 'csrf' => NBY_Auth::csrf() );
	}

	public static function logout() {
		NBY_Auth::logout();
		return array( 'ok' => true );
	}

	public static function me() {
		return array( 'me' => self::public_actor(), 'csrf' => NBY_Auth::csrf() );
	}

	/* ================================================================== dashboard */

	public static function status() {
		$c      = NBY_Runner::control();
		$st     = NBY_Runner::state();
		$scope  = NBY_Auth::scope();
		$counts = NBY_DB::counts( $scope );
		$all    = null === $scope ? $counts : NBY_DB::counts(); // team queue sizes stay global (no names)
		$ago    = $st['last_tick_at'] ? time() - (int) $st['last_tick_at'] : -1;
		$srcs   = array( 'server-cron' => 'کرون سرور', 'wp-cron' => 'WP-Cron', 'manual' => 'دستی', 'cli' => 'WP-CLI', 'test' => 'آزمایشی' );
		$names  = array( 'open' => 'باز است', 'closed' => 'بسته / پر', 'unknown' => 'هنوز بررسی نشده', 'paused' => 'متوقف', 'disabled' => 'غیرفعال' );
		$teams  = array();
		foreach ( NBY_Settings::teams() as $team => $label ) {
			$t      = $st['teams'][ $team ];
			$cfg    = NBY_Settings::team_cfg( $team );
			$paused = ! empty( $c['paused'][ $team ] );
			$state  = ! $cfg['enabled'] ? 'disabled' : ( $paused ? 'paused' : $t['state'] );
			$queued = isset( $all['by_team'][ $team ]['queued'] ) ? (int) $all['by_team'][ $team ]['queued'] : 0;
			$teams[] = array(
				'key'           => $team,
				'label'         => $label,
				'state'         => $state,
				'state_label'   => $names[ $state ],
				'paused_reason' => $paused ? $c['paused'][ $team ] : '',
				'queued'        => $queued,
				'booked_today'  => NBY_DB::booked_today( $team ),
				'last_ago'      => NBY_Jalali::ago( $t['last_at'] ),
				'last_result'   => $t['last_result'],
				'result_label'  => '' !== $t['last_result'] ? self::label( NBY_DB::results(), $t['last_result'] ) : '',
				'last_message'  => $t['last_message'],
				'last_open'     => $t['last_open_at'] ? NBY_Jalali::ts( $t['last_open_at'] ) : '',
				'next_in'       => ( $c['running'] && $cfg['enabled'] && ! $paused && $queued ) ? max( 0, (int) $t['next_at'] - time() ) : null,
				'interval'      => $cfg['interval'],
			);
		}
		$recent = NBY_DB::attempts( array( 'per_page' => 12, 'owner' => $scope ) );
		return array(
			'running'     => (bool) $c['running'],
			'stop_reason' => $c['stop_reason'],
			'dry_run'     => (bool) NBY_Settings::get( 'dry_run' ),
			'busy'        => NBY_Runner::is_locked(),
			'tick'        => array(
				'ago'    => NBY_Jalali::ago( $st['last_tick_at'] ),
				'source' => isset( $srcs[ $st['last_tick_source'] ] ) ? $srcs[ $st['last_tick_source'] ] : $st['last_tick_source'],
				'stale'  => $c['running'] && ( $ago < 0 || $ago > 180 ),
			),
			'teams'       => $teams,
			'counts'      => $counts['by_status'],
			'total'       => $counts['total'],
			'recent'      => array_map( array( __CLASS__, 'fmt_attempt' ), $recent['rows'] ),
		);
	}

	public static function control( WP_REST_Request $req ) {
		$op   = sanitize_key( (string) $req->get_param( 'op' ) );
		$team = sanitize_key( (string) $req->get_param( 'team' ) );
		$c    = NBY_Runner::control();
		$msg  = '';
		if ( 'start' === $op ) {
			$c['running']     = 1;
			$c['stop_reason'] = '';
			$msg              = 'ربات روشن شد؛ اولین اجرا حداکثر تا یک دقیقه دیگر.';
		} elseif ( 'stop' === $op ) {
			$c['running'] = 0;
			$msg          = 'ربات متوقف شد.';
		} elseif ( 'pause' === $op && isset( NBY_Settings::teams()[ $team ] ) ) {
			$c['paused'][ $team ] = 'به‌صورت دستی متوقف شد.';
			$msg                  = NBY_Settings::teams()[ $team ] . ' متوقف شد.';
		} elseif ( 'resume' === $op && isset( NBY_Settings::teams()[ $team ] ) ) {
			unset( $c['paused'][ $team ] );
			$st                              = NBY_Runner::state();
			$st['teams'][ $team ]['next_at'] = 0;
			$st['teams'][ $team ]['errors']  = 0;
			NBY_Runner::save_state( $st );
			$msg = NBY_Settings::teams()[ $team ] . ' دوباره فعال شد.';
		} else {
			return self::err( 'عملیات نامعتبر.' );
		}
		NBY_Runner::set_control( $c );
		NBY_Activity::log( 'bot', 0, $msg, array( 'note' => $op . ( $team ? ':' . $team : '' ) ) );
		$by = '🛠 توسط: ' . NBY_Auth::who();
		if ( 'start' === $op ) {
			NBY_Notify::event( 'bot', array( 'ربات_روشن' ), '▶️ ربات روشن شد', array( $by, NBY_Settings::get( 'dry_run' ) ? '🧪 حالت آزمایشی روشن است؛ فرمی ارسال نمی‌شود.' : '🚀 ثبت واقعی فعال است.' ) );
		} elseif ( 'stop' === $op ) {
			NBY_Notify::event( 'bot', array( 'ربات_خاموش' ), '⏹ ربات خاموش شد', array( $by, '⚠️ تا روشن شدن دوباره، هیچ فرمی ارسال نمی‌شود.' ) );
		} else {
			NBY_Notify::event( 'bot', array( 'pause' === $op ? 'توقف_' . NBY_Settings::teams()[ $team ] : 'ادامه_' . NBY_Settings::teams()[ $team ] ), ( 'pause' === $op ? '⏸ ' : '▶️ ' ) . $msg, array( $by ) );
		}
		return array( 'message' => $msg );
	}

	public static function tick() {
		$r = NBY_Runner::tick( 'manual' );
		if ( 'busy' === $r['status'] ) {
			return array( 'message' => 'ربات همین الان در حال اجراست.' );
		}
		if ( 'stopped' === $r['status'] ) {
			return array( 'message' => 'ربات خاموش است؛ اول آن را روشن کنید.', 'tone' => 'warn' );
		}
		return array( 'message' => 'یک دور اجرا شد: ' . (int) $r['attempts'] . ' تلاش، ' . (int) $r['booked'] . ' نوبت.' );
	}

	public static function probe() {
		$r = NBY_Runner::probe();
		if ( ! $r['ok'] && false === strpos( $r['message'], 'فرم تغییر کرده' ) ) {
			$n = NBY_Runner::netcheck();
			return array( 'message' => $n['verdict'], 'tone' => 'warn' );
		}
		return array( 'message' => $r['message'] . ' (' . number_format( $r['ms'] / 1000, 1 ) . ' ثانیه)', 'tone' => $r['ok'] ? 'ok' : 'warn' );
	}

	/* ================================================================== citizens */

	public static function citizens( WP_REST_Request $req ) {
		$status = sanitize_key( (string) $req->get_param( 'status' ) );
		$q      = NBY_DB::query(
			array(
				'status'   => $status,
				'team'     => sanitize_key( (string) $req->get_param( 'team' ) ),
				's'        => sanitize_text_field( (string) $req->get_param( 's' ) ),
				'paged'    => max( 1, (int) $req->get_param( 'paged' ) ),
				'per_page' => min( 100, max( 10, (int) ( $req->get_param( 'per_page' ) ? $req->get_param( 'per_page' ) : 30 ) ) ),
				'orderby'  => 'booked' === $req->get_param( 'orderby' ) ? 'booked' : '',
				'owner'    => NBY_Auth::scope(),
			)
		);
		$counts = NBY_DB::counts( NBY_Auth::scope() );
		return array(
			'rows'   => array_map( array( __CLASS__, 'fmt_citizen' ), $q['rows'] ),
			'total'  => $q['total'],
			'pages'  => $q['pages'],
			'counts' => $counts['by_status'],
			'all'    => $counts['total'],
		);
	}

	public static function citizen( WP_REST_Request $req ) {
		$row = NBY_DB::get( (int) $req['id'] );
		if ( ! $row || ! NBY_Auth::owns( $row ) ) {
			return self::err( 'متقاضی پیدا نشد.', 404 );
		}
		$out          = self::fmt_citizen( $row );
		$out['data']  = $row['data'];
		$out['notes'] = NBY_Auth::can( 'priority' ) ? (string) $row['notes'] : '';
		$out['file']  = NBY_Storage::exists( $row['file_rel'] ) ? array( 'name' => $row['file_name'], 'mime' => $row['file_mime'] ) : null;
		$a            = NBY_DB::attempts( array( 'citizen_id' => (int) $row['id'], 'per_page' => 40 ) );
		$out['history'] = array_map( array( __CLASS__, 'fmt_attempt' ), $a['rows'] );
		$out['jalali']  = array(
			'date_of_birth'                   => NBY_Jalali::to_jalali_str( isset( $row['data']['date_of_birth'] ) ? $row['data']['date_of_birth'] : '' ),
			'last_return_date_to_afghanistan' => NBY_Jalali::to_jalali_str( isset( $row['data']['last_return_date_to_afghanistan'] ) ? $row['data']['last_return_date_to_afghanistan'] : '' ),
		);
		return $out;
	}

	/** Create (no id) or update. Multipart: f[...], tazkira, priority, notes, do=queue|draft|try|keep. */
	public static function save( WP_REST_Request $req ) {
		$id  = isset( $req['id'] ) ? (int) $req['id'] : 0;
		$row = $id ? NBY_DB::get( $id ) : null;
		if ( $id && ( ! $row || ! NBY_Auth::owns( $row ) ) ) {
			return self::err( 'متقاضی پیدا نشد.', 404 );
		}
		if ( $row && 'processing' === $row['status'] ) {
			return self::err( 'این متقاضی همین الان در حال ارسال است؛ چند ثانیه دیگر دوباره امتحان کنید.', 409 );
		}
		$idem = preg_replace( '/[^A-Za-z0-9]/', '', (string) $req->get_param( '_idem' ) );
		if ( ! $id && $idem && ( $prev = get_transient( 'nby_idem_' . $idem ) ) ) {
			return $prev; // same create request retried over another transport
		}
		$do = sanitize_key( (string) $req->get_param( 'do' ) );
		$f  = $req->get_param( 'f' );
		$in = is_array( $f ) ? $f : array();

		$files = $req->get_file_params();
		$file  = array();
		$ferr  = '';
		if ( ! empty( $files['tazkira']['name'] ) ) {
			if ( UPLOAD_ERR_OK !== (int) $files['tazkira']['error'] ) {
				$ferr = 'بارگذاری فایل ناموفق بود (کد ' . (int) $files['tazkira']['error'] . ').';
			} else {
				$name = sanitize_file_name( $files['tazkira']['name'] );
				$chk  = NBY_Storage::check_file( $files['tazkira']['tmp_name'], $name );
				if ( is_wp_error( $chk ) ) {
					$ferr = $chk->get_error_message();
				} else {
					$rel = NBY_Storage::move_upload( $files['tazkira']['tmp_name'], $chk[0] );
					if ( $rel ) {
						$file = array( 'file_rel' => $rel, 'file_name' => $name, 'file_mime' => $chk[1] );
						if ( $row && $row['file_rel'] ) {
							NBY_Storage::delete( $row['file_rel'] );
						}
					} else {
						$ferr = 'ذخیره فایل روی سرور ممکن نشد.';
					}
				}
			}
		}
		$has_file               = ! empty( $file ) || ( $row && NBY_Storage::exists( $row['file_rel'] ) );
		list( $clean, $errors ) = NBY_Fields::validate( $in, $has_file );
		if ( $ferr ) {
			$errors['document_tazkira'] = $ferr;
		}

		if ( $row && 'booked' === $row['status'] ) {
			$status = 'booked';
		} elseif ( $row && 'uncertain' === $row['status'] ) {
			$status = 'uncertain'; // never silently re-queue a possibly-booked applicant
		} elseif ( 'draft' === $do || $errors ) {
			$status = 'draft';
		} else {
			$status = 'queued';
		}
		$fields = array_merge(
			array(
				'data'     => $clean,
				'status'   => $status,
				// priority + operator notes are a manager decision; operators can't set or change them
				'priority' => NBY_Auth::can( 'priority' ) ? max( 0, min( 9, (int) $req->get_param( 'priority' ) ) ) : ( $row ? (int) $row['priority'] : 0 ),
				'notes'    => NBY_Auth::can( 'priority' ) ? sanitize_textarea_field( (string) $req->get_param( 'notes' ) ) : ( $row ? (string) $row['notes'] : '' ),
			),
			$file
		);
		if ( 'queued' === $status ) {
			$fields['last_message'] = '';
		}
		$is_new = ! $id;
		$id     = NBY_DB::save( $fields, $id );
		NBY_Activity::log( $is_new ? 'create' : 'update', $id, NBY_Fields::full_name( $clean ), array( 'note' => NBY_DB::statuses()[ $status ] ) );
		if ( $is_new && $idem ) {
			set_transient( 'nby_idem_' . $idem, array( 'id' => $id, 'status' => $status, 'errors' => $errors, 'message' => 'ذخیره شد.', 'tone' => 'ok' ), 15 * MINUTE_IN_SECONDS );
		}

		$out = array( 'id' => $id, 'status' => $status, 'errors' => $errors );
		if ( $errors && 'draft' !== $do ) {
			$out['message'] = 'ذخیره شد، اما چون اطلاعات کامل نیست به‌صورت «پیش‌نویس» ماند.';
			$out['tone']    = 'warn';
			return $out;
		}
		if ( 'try' === $do && 'queued' === $status ) {
			if ( ! NBY_Auth::can( 'try' ) ) {
				return self::err( 'اجازه ارسال فوری ندارید.', 403 );
			}
			$res            = NBY_Runner::try_now( $id );
			$out['message'] = 'تلاش فوری: ' . self::label( NBY_DB::results(), $res['result'] ) . ' — ' . $res['message'];
			$out['tone']    = 'success' === $res['result'] ? 'ok' : ( in_array( $res['result'], array( 'closed', 'dry' ), true ) ? 'info' : 'warn' );
			return $out;
		}
		$out['message'] = 'draft' === $status ? 'به‌صورت پیش‌نویس ذخیره شد.' : ( 'queued' === $status ? 'ذخیره شد و به صف اضافه شد.' : 'تغییرات ذخیره شد.' );
		$out['tone']    = 'ok';
		return $out;
	}

	public static function action( WP_REST_Request $req ) {
		$id  = (int) $req['id'];
		$op  = sanitize_key( (string) $req->get_param( 'op' ) );
		$row = NBY_DB::get( $id );
		if ( ! $row || ! NBY_Auth::owns( $row ) ) {
			return self::err( 'متقاضی پیدا نشد.', 404 );
		}
		$need = array( 'delete' => 'delete', 'try' => 'try', 'verify' => 'try', 'queue' => 'edit', 'hold' => 'edit' );
		if ( ! isset( $need[ $op ] ) ) {
			return self::err( 'عملیات نامعتبر.' );
		}
		if ( ! NBY_Auth::can( $need[ $op ] ) ) {
			return self::err( 'نقش کاربری شما اجازه این کار را ندارد.', 403 );
		}
		switch ( $op ) {
			case 'delete':
				if ( 'processing' === $row['status'] ) {
					return self::err( 'در حال ارسال است؛ بعداً حذف کنید.', 409 );
				}
				NBY_DB::delete( $id );
				self::deleted_notice( array( $row ) );
				return array( 'message' => 'حذف شد.', 'deleted' => true );
			case 'queue':
				if ( in_array( $row['status'], array( 'processing', 'booked' ), true ) ) {
					return self::err( 'این متقاضی را نمی‌توان دوباره به صف برد.', 409 );
				}
				list( , $errors ) = NBY_Fields::validate( $row['data'], NBY_Storage::exists( $row['file_rel'] ) );
				if ( $errors ) {
					return self::err( 'اطلاعات کامل نیست: ' . implode( ' ', $errors ), 422 );
				}
				NBY_DB::set_status( $id, 'queued', array( 'last_message' => '' ) );
				NBY_Activity::log( 'queue', $id, $row['full_name'] );
				return array( 'message' => 'به صف اضافه شد.' );
			case 'hold':
				if ( 'queued' !== $row['status'] ) {
					return self::err( 'فقط افراد داخل صف را می‌توان متوقف کرد.', 409 );
				}
				NBY_DB::set_status( $id, 'on_hold' );
				NBY_Activity::log( 'hold', $id, $row['full_name'] );
				return array( 'message' => 'از صف خارج شد.' );
			case 'try':
				NBY_Activity::log( 'try', $id, $row['full_name'] );
				$res = NBY_Runner::try_now( $id );
				return array(
					'message' => self::label( NBY_DB::results(), $res['result'] ) . ' — ' . $res['message'],
					'tone'    => 'success' === $res['result'] ? 'ok' : ( in_array( $res['result'], array( 'closed', 'dry' ), true ) ? 'info' : 'warn' ),
				);
			case 'verify':
				NBY_Activity::log( 'verify', $id, $row['full_name'] );
				$res = NBY_Runner::verify_now( $id );
				return array( 'message' => $res['message'], 'tone' => true === $res['found'] ? 'ok' : 'info' );
		}
		return self::err( 'عملیات نامعتبر.' );
	}

	public static function bulk( WP_REST_Request $req ) {
		$op  = sanitize_key( (string) $req->get_param( 'op' ) );
		$ids = array_map( 'intval', (array) $req->get_param( 'ids' ) );
		if ( 'delete' === $op && ! NBY_Auth::can( 'delete' ) ) {
			return self::err( 'نقش کاربری شما اجازه حذف ندارد.', 403 );
		}
		if ( in_array( $op, array( 'prio', 'unprio' ), true ) && ! NBY_Auth::can( 'priority' ) ) {
			return self::err( 'تعیین اولویت فقط با مدیر است.', 403 );
		}
		$n    = 0;
		$gone = array();
		foreach ( $ids as $id ) {
			$row = NBY_DB::get( $id );
			if ( ! $row || 'processing' === $row['status'] || ! NBY_Auth::owns( $row ) ) {
				continue;
			}
			if ( 'delete' === $op ) {
				NBY_DB::delete( $id );
				$gone[] = $row;
				$n++;
			} elseif ( 'queue' === $op && in_array( $row['status'], array( 'draft', 'on_hold', 'needs_fix' ), true ) ) {
				list( , $errors ) = NBY_Fields::validate( $row['data'], NBY_Storage::exists( $row['file_rel'] ) );
				if ( ! $errors ) {
					NBY_DB::set_status( $id, 'queued', array( 'last_message' => '' ) );
					$n++;
				}
			} elseif ( 'hold' === $op && 'queued' === $row['status'] ) {
				NBY_DB::set_status( $id, 'on_hold' );
				$n++;
			} elseif ( 'prio' === $op || 'unprio' === $op ) {
				NBY_DB::save( array( 'priority' => 'prio' === $op ? 5 : 0 ), $id );
				$n++;
			}
		}
		if ( $gone ) {
			self::deleted_notice( $gone );
		}
		if ( 'delete' !== $op && $n ) {
			NBY_Activity::log( 'bulk', 0, $op . ' × ' . $n );
		}
		$skipped = count( $ids ) - $n;
		return array( 'message' => $n . ' مورد انجام شد.' . ( $skipped ? ' ' . $skipped . ' مورد قابل تغییر نبود.' : '' ) );
	}

	private static function deleted_notice( array $rows ) {
		$names = array();
		foreach ( $rows as $r ) {
			NBY_Activity::log( 'delete', (int) $r['id'], $r['full_name'], array( 'note' => NBY_DB::statuses()[ $r['status'] ] ) );
			$names[] = '• ' . ( $r['full_name'] ? $r['full_name'] : '#' . $r['id'] ) . ' — ' . self::label( NBY_Settings::teams(), $r['team'] ) . ' — ' . self::label( NBY_DB::statuses(), $r['status'] ) . ( $r['ticket_no'] ? ' (نوبت ' . $r['ticket_no'] . ')' : '' );
		}
		NBY_Notify::event(
			'delete',
			array( 'حذف_متقاضی' ),
			'🗑 ' . ( count( $rows ) > 1 ? count( $rows ) . ' متقاضی حذف شد' : 'متقاضی حذف شد' ),
			array_merge( array_slice( $names, 0, 30 ), array( '🛠 توسط: ' . NBY_Auth::who() ) )
		);
	}

	/* ================================================================== own password */

	public static function my_password( WP_REST_Request $req ) {
		$r = NBY_Auth::change_own_password( (string) $req->get_param( 'current' ), (string) $req->get_param( 'password' ) );
		if ( is_wp_error( $r ) ) {
			return self::err( $r->get_error_message(), 422 );
		}
		return array( 'message' => 'رمز عبور عوض شد. نشست‌های دیگر شما بسته شد.' );
	}

	/* ================================================================== team (managers manage operators) */

	private static function fmt_user( array $u, array $online ) {
		$st = NBY_Activity::stats( 'p:' . $u['id'], NBY_Activity::today_start() );
		return array(
			'id'           => (int) $u['id'],
			'username'     => $u['username'],
			'display_name' => $u['display_name'],
			'role'         => $u['role'],
			'role_name'    => NBY_Auth::roles()[ $u['role'] ],
			'active'       => (bool) (int) $u['active'],
			'online'       => in_array( (int) $u['id'], $online, true ),
			'last_login'   => $u['last_login'] ? NBY_Jalali::dt( $u['last_login'] ) : '',
			'today'        => array(
				'added'     => $st['added'],
				'incomplete' => ( isset( $st['by_status']['draft'] ) ? $st['by_status']['draft'] : 0 ) + ( isset( $st['by_status']['needs_fix'] ) ? $st['by_status']['needs_fix'] : 0 ),
				'deleted'   => $st['deleted'],
				'printed'   => count( $st['printed'] ),
				'updated'   => $st['updated'],
			),
			'editable'     => 'operator' === $u['role'],
		);
	}

	public static function team() {
		$online = NBY_Auth::online_ids();
		$a      = NBY_Auth::actor();
		$users  = array_map(
			function ( $u ) use ( $online, $a ) {
				$o         = self::fmt_user( $u, $online );
				$o['self'] = $a && 'panel' === $a['type'] && (int) $a['id'] === (int) $u['id'];
				return $o;
			},
			NBY_Auth::list_users()
		);
		return array( 'users' => $users, 'min_pass' => NBY_Auth::MIN_PASS );
	}

	public static function team_member( WP_REST_Request $req ) {
		$u = NBY_Auth::get_user( (int) $req['id'] );
		if ( ! $u ) {
			return self::err( 'حساب پیدا نشد.', 404 );
		}
		$out             = self::fmt_user( $u, NBY_Auth::online_ids() );
		$st              = NBY_Activity::stats( 'p:' . $u['id'], NBY_Activity::today_start() );
		$out['by_status'] = array();
		foreach ( $st['by_status'] as $k => $n ) {
			$out['by_status'][] = array( 'status' => $k, 'label' => self::label( NBY_DB::statuses(), $k ), 'n' => $n );
		}
		$out['printed']  = $st['printed'];
		$out['sessions'] = NBY_Auth::sessions_of( (int) $u['id'], 15 );
		$out['activity'] = NBY_Activity::recent( 'p:' . $u['id'], 40 );
		return $out;
	}

	/** Managers create / edit OPERATOR accounts only (managers are created by the WordPress admin). */
	public static function team_save( WP_REST_Request $req ) {
		$id   = isset( $req['id'] ) ? (int) $req['id'] : 0;
		$disp = sanitize_text_field( (string) $req->get_param( 'display_name' ) );
		$pass = (string) $req->get_param( 'password' );
		if ( ! $id ) {
			$r = NBY_Auth::create_user( sanitize_user( (string) $req->get_param( 'username' ), true ), $pass, $disp, 'operator' );
			if ( is_wp_error( $r ) ) {
				return self::err( $r->get_error_message(), 422 );
			}
			return array( 'id' => $r, 'message' => 'حساب اپراتور ساخته شد.' );
		}
		$u = NBY_Auth::get_user( $id );
		if ( ! $u ) {
			return self::err( 'حساب پیدا نشد.', 404 );
		}
		if ( 'operator' !== $u['role'] ) {
			return self::err( 'حساب مدیران فقط از پیشخوان وردپرس قابل تغییر است.', 403 );
		}
		$fields = array( 'display_name' => $disp, 'password' => $pass );
		if ( null !== $req->get_param( 'active' ) ) {
			$fields['active'] = rest_sanitize_boolean( $req->get_param( 'active' ) );
		}
		$r = NBY_Auth::update_user( $id, $fields );
		if ( is_wp_error( $r ) ) {
			return self::err( $r->get_error_message(), 422 );
		}
		return array( 'message' => 'حساب به‌روز شد.' . ( '' !== $pass ? ' نشست‌های قبلی این اپراتور بسته شد.' : '' ) );
	}

	/* ================================================================== logs & import */

	public static function attempts( WP_REST_Request $req ) {
		$q = NBY_DB::attempts(
			array(
				'result' => sanitize_key( (string) $req->get_param( 'result' ) ),
				'team'   => sanitize_key( (string) $req->get_param( 'team' ) ),
				'paged'  => max( 1, (int) $req->get_param( 'paged' ) ),
				'owner'  => NBY_Auth::scope(),
			)
		);
		return array(
			'rows'  => array_map( array( __CLASS__, 'fmt_attempt' ), $q['rows'] ),
			'total' => $q['total'],
			'pages' => $q['pages'],
		);
	}

	public static function import( WP_REST_Request $req ) {
		$files = $req->get_file_params();
		if ( empty( $files['csv']['tmp_name'] ) || UPLOAD_ERR_OK !== (int) $files['csv']['error'] ) {
			return self::err( 'فایل CSV بارگذاری نشد.' );
		}
		@set_time_limit( 600 );
		$zip = ( ! empty( $files['zip']['tmp_name'] ) && UPLOAD_ERR_OK === (int) $files['zip']['error'] ) ? $files['zip']['tmp_name'] : '';
		$rep = NBY_Import::run( $files['csv']['tmp_name'], $zip );
		NBY_Activity::log( 'import', 0, $files['csv']['name'], array( 'imported' => $rep['imported'], 'queued' => $rep['queued'], 'drafts' => $rep['drafts'] ) );
		return $rep;
	}

	/* ================================================================== raw files (ticket, pdf, tazkira, site response, csv template) */

	private static function sandbox_headers( $scripts ) {
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: no-referrer' );
		// Opaque origin: archived third-party HTML can never reach the panel/admin session.
		header( 'Content-Security-Policy: sandbox' . ( $scripts ? ' allow-scripts allow-modals' : '' ) );
	}

	public static function raw( WP_REST_Request $req ) {
		$kind = $req['kind'];
		$id   = (int) $req['id'];
		nocache_headers();
		if ( 'template' === $kind ) {
			header( 'Content-Type: text/csv; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename="nobatyar-template.csv"' );
			echo NBY_Import::template_csv(); // phpcs:ignore
			exit;
		}
		if ( 'response' === $kind ) {
			$a     = NBY_DB::get_attempt( $id );
			$owner = $a && $a['citizen_id'] ? NBY_DB::get( (int) $a['citizen_id'] ) : null;
			if ( $a && null !== NBY_Auth::scope() && ( ! $owner || ! NBY_Auth::owns( $owner ) ) ) {
				$a = null;
			}
			if ( ! $a || ! $a['response_rel'] ) {
				return self::err( 'پاسخی ذخیره نشده است.', 404 );
			}
			$html = NBY_Storage::get( $a['response_rel'] );
			$base = '<base href="' . esc_url( NBY_Settings::get( 'base_url' ) ) . '/">';
			$bar  = '<div style="background:#f6ecd9;color:#5c3d0a;padding:10px 16px;font:13px Tahoma,sans-serif;direction:rtl;border-bottom:2px solid #a86b12"><b>پاسخ ذخیره‌شده سایت</b> — ' . esc_html( NBY_Jalali::dt( $a['created_at'] ) ) . ' — ' . esc_html( self::label( NBY_DB::results(), $a['result'] ) ) . ' — ' . esc_html( $a['message'] ) . '</div>';
			$html = preg_match( '/<head\b[^>]*>/i', $html ) ? preg_replace( '/<head\b[^>]*>/i', '$0' . $base, $html, 1 ) : $base . $html;
			$html = preg_match( '/<body\b[^>]*>/i', $html ) ? preg_replace( '/<body\b[^>]*>/i', '$0' . $bar, $html, 1 ) : $bar . $html;
			self::sandbox_headers( false );
			echo $html; // phpcs:ignore -- stored site response under CSP sandbox
			exit;
		}
		$row = NBY_DB::get( $id );
		if ( ! $row || ! NBY_Auth::owns( $row ) ) {
			return self::err( 'پیدا نشد.', 404 );
		}
		if ( 'ticket' === $kind || 'pdf' === $kind ) {
			NBY_Activity::log( 'print', $id, $row['full_name'], array( 'note' => $row['ticket_no'] ) );
		}
		if ( 'ticket' === $kind ) {
			if ( ! $row['ticket_rel'] ) {
				return self::err( 'تیکت ذخیره نشده است.', 404 );
			}
			$html = NBY_Storage::get( $row['ticket_rel'] );
			$bar  = '<div id="nby-print-bar" style="position:sticky;top:0;z-index:50;background:#1d1b18;color:#fffdfa;padding:10px 16px;font:14px Tahoma,sans-serif;display:flex;gap:12px;align-items:center;direction:rtl">'
				. '<b>نوبت‌یار</b><span>' . esc_html( $row['full_name'] ) . ' — نوبت ' . esc_html( $row['ticket_no'] ) . '</span>'
				. '<button onclick="window.print()" style="margin-right:auto;background:#0f6a61;color:#fff;border:0;border-radius:8px;padding:8px 16px;font:inherit;cursor:pointer">چاپ / ذخیره PDF</button></div>'
				. '<style>@media print{#nby-print-bar{display:none!important}}</style>';
			$html = preg_match( '/<body\b[^>]*>/i', $html ) ? preg_replace( '/<body\b[^>]*>/i', '$0' . $bar, $html, 1 ) : $bar . $html;
			self::sandbox_headers( true );
			echo $html; // phpcs:ignore -- archived ticket under CSP sandbox
			exit;
		}
		$rel  = 'pdf' === $kind ? $row['ticket_pdf_rel'] : $row['file_rel'];
		$path = NBY_Storage::path( $rel );
		if ( ! $path || ! is_file( $path ) ) {
			return self::err( 'فایل موجود نیست.', 404 );
		}
		if ( 'pdf' === $kind ) {
			header( 'Content-Type: application/pdf' );
			header( 'Content-Disposition: attachment; filename="ticket-' . preg_replace( '/[^0-9A-Za-z]/', '', $row['ticket_no'] ) . '.pdf"' );
		} else {
			$mime   = $row['file_mime'] ? $row['file_mime'] : 'application/octet-stream';
			$inline = in_array( $mime, array( 'image/jpeg', 'image/png', 'image/webp' ), true ) && $req->get_param( 'inline' );
			header( 'Content-Type: ' . $mime );
			header( 'Content-Disposition: ' . ( $inline ? 'inline' : 'attachment' ) . '; filename="' . sanitize_file_name( $row['file_name'] ? $row['file_name'] : 'tazkira' ) . '"' );
		}
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Content-Length: ' . filesize( $path ) );
		readfile( $path );
		exit;
	}
}
